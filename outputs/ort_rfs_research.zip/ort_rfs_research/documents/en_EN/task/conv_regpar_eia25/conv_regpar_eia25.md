# Converting a claim from regular to parental benefits while the client is referred under EIA 25 — Continuing claim

Source map: `en_EN/task/conv_regpar_eia25/conv_regpar_eia25.ditamap`

## Summary

Source topic: `en_EN/task/conv_regpar_eia25/summary.dita`

Summary: After receiving regular benefits, clients can request a conversion to parental benefits while also being referred under EIA 25. 

## What you need to know

Source topic: `en_EN/task/conv_regpar_eia25/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/conv_regpar_eia25/untitled_section.dita`

Parental benefits can be paid at either the standard parental benefits rate, or at the extended parental benefits rate. The maximum number of parental entitlement weeks for a birth or adoption varies depending on the type of parental benefits the client receives and whether benefits are shared with other legally recognized parents. 

### Type of parental benefits

Source topic: `en_EN/task/conv_regpar_eia25/type_of_parental_benefits.dita`

Parental benefits can be paid at either the standard parental benefits rate, or at the extended parental benefits rate. The maximum number of parental entitlement weeks for a birth or adoption varies depending on the type of parental benefits the client receives and whether benefits are shared with other legally recognized parents. 

### Weeks of entitlement

Source topic: `en_EN/task/conv_regpar_eia25/weeks_of_entitlement.dita`

A client is entitled to a maximum of 35 weeks of standard parental benefits or 61 weeks of extended parental benefits per birth or placement for adoption. The maximum parental entitlement is also the maximum number of parental entitlement weeks that can be paid in a benefit period (BP). The parental benefits can be paid over 2 BPs, but cannot be paid outside of the parental window (PW). The number of weeks of parental benefits a client is entitled to receive is not affected by the number of children born at the same time (twins, triplets, etc.) or by the number of children adopted at the same time. 

### Sharing parental benefits

Source topic: `en_EN/task/conv_regpar_eia25/sharing_parental_benefits.dita`

Parents can share parental benefits. For more information and definitions, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

The type of parental benefits requested by the first parent to apply determines the type of parental benefits all parents are entitled to receive for the same birth, adoption or placement, regardless of which parent is paid first. When fact-finding with parents who applied for benefits after the first parent, the officer informs the other parents of this. Once at least one week of parental benefits has been paid to any parent, all parents requesting parental benefits for the same birth, adoption or placement are only entitled to receive the type of parental benefits selected by the first parent who applied for benefits.

The maximum shareable entitlement is 40 weeks of standard parental benefits or 69 weeks of extended parental benefits for children born or placed for adoption on or after March 17, 2019. For children born or placed for adoption before this date, the maximum shareable entitlement is 35 weeks of standard parental benefits or 61 weeks of extended parental benefits. The maximum entitlement for one client remains at 35 weeks of standard or 61 weeks of extended benefits. Clients can change the number of weeks that each parent receives at any time before all benefits are paid. When clients cannot agree on the number of weeks they will each receive, the officer reassigns the issue to a Level 2 officer who adjudicates the division of the remaining weeks.

Clients who apply for parental benefits must provide the name and SIN of the other parent for control purposes. If the client does not provide the name and the SIN of the other parent, or in the case of a single parent or a parent whose family situation is such that information on the child’s other parent cannot be obtained, the officer can still allow the claim. 

### Qualifying for parental benefits

Source topic: `en_EN/task/conv_regpar_eia25/qualifying_for_parental_benefits.dita`

Parental benefits can be paid if one of the following conditions is met:

- The client is major attached (has accumulated at least 600 hours of insurable employment).

- The BPC is between w/c 2310 and w/c 2361 and the client has at least 420 hours of insurable employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2774.dita) 

### Qualifying for benefits with the common entrance requirement (CER) (from w/c 2310 to w/c 2361)

Source topic: `en_EN/task/conv_regpar_eia25/qualifying_for_benefits_with_the_common_772f2c7f.dita`

As part of Budget 2021, the Government of Canada announced that a national CER of 420 hours of insurable employment applies to establish a claim for regular or special benefits. If the client has a violation on file, the increased entrance requirements may apply. The CER applies to claims with a BPC between September 26, 2021 (w/c 2310), and September 18, 2022 (w/c 2361). During this period, the definitions for major attached and minor attached clients in EIA 6(1) are repealed. Clients whose claims are established with 420 hours of insurable employment qualify for special benefits regardless of the conversion date. The officer ensures that all other qualifying and entitlement conditions are met.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

### Entitlement to parental benefits

Source topic: `en_EN/task/conv_regpar_eia25/entitlement_to_parental_benefits.dita`

Parental benefits are payable during the PW to parents providing care for a child. To be entitled to parental benefits, the client must provide proof of birth, adoption or placement. Once entitlement has been established, a client can receive up to the maximum number of parental weeks per birth, adoption or placement. A client does not have to collect all of the weeks of parental benefits successively. Payments of parental benefits can alternate with the payment of another type of benefits, or with a return to work (RTW). The payment of parental benefits can occur in one BP or over 2 BPs, as long as the maximum number of parental weeks is not exceeded and the end of the PW has not been reached. 

### Proof of birth, adoption or placement

Source topic: `en_EN/task/conv_regpar_eia25/proof_of_birth_adoption_or_placement.dita`

Parents must supply proof of birth, adoption or placement depending on their relationship to the child or children. For more information, the officer can refer to Parents: Definition — Table .
       [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml) 

### Extending the benefit period (BP)

Source topic: `en_EN/task/conv_regpar_eia25/extending_the_benefit_period_bp.dita`

Under certain conditions, the BP can be extended to allow clients more time to receive the benefits to which they are entitled. The BP can be extended for a maximum of 104 weeks to pay additional weeks of benefits when all of the conditions are met before the BP ends. The officer refers to Extension of the Benefit period for more information.
       [Extension of the Benefit period](/en/procedure/activity/extension_benefit_period.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2712.dita) 

### Parental window (PW)

Source topic: `en_EN/task/conv_regpar_eia25/parental_window_pw.dita`

The PW is the period during which parental benefits can be paid. The PW starts and ends as follows:

- Start week:

- The arrival or placement week (APW) is determined by the parent’s relationship to the child. For more information, the officer can refer to Parents: Definition — Table .
             [Parents: Definition — Table](/en/procedure/generic/parents_definition_table.shtml)

- End week:

- For standard parental benefits, the end week is 52 weeks after the APW (APW + 52).

- For extended parental benefits, the end week is 78 weeks after the APW (APW + 78).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2719.dita) 

### Extending the benefit period (BP) and parental window (PW)

Source topic: `en_EN/task/conv_regpar_eia25/extending_the_benefit_period_bp_and_par_bc66fc4a.dita`

Hospitalization of the child for whom parental benefits are being claimed is grounds to extend the BP and PW. The BP and PW can also be extended for personnel of the Canadian military who are unable to collect their parental benefits because of an imperative military requirement. For more information, the officer can refer to Extension of the benefit period.
       [Extension of the benefit period.](/en/procedure/activity/extension_benefit_period.shtml)

The PW is also extended when a client entitled to parental benefits is entitled to a BP extension for special benefits. When this occurs, the BP and PW are both extended. For more information, the officer can refer to Benefit period extension for special benefits .
       [Benefit period extension for special benefits](/en/procedure/generic/additionalresources/eiortjobaid_bp_chart.shtml) 

### Terminating parental benefits during the parental window (PW) — Entitlement conditions are no longer met

Source topic: `en_EN/task/conv_regpar_eia25/terminating_parental_benefits_during_th_507d8ff1.dita`

A client must meet the entitlement conditions for each week of parental benefits claimed. If the officer is informed that the client is no longer caring for the child during the PW, the officer imposes a definite or indefinite 34 - Parental benefits entitlement conditions not met disentitlement (D34) starting the Monday after the week in which the client is no longer entitled to benefits. For more information, the officer refers to Determining entitlement to parental benefits when the client is no longer caring for the child .
       [Determining entitlement to parental benefits when the client is no longer caring for the child](/en/procedure/task/determining_entitlement_parental_benefit_no_longer_caring_child.shtml) 

### Imposing disentitlements

Source topic: `en_EN/task/conv_regpar_eia25/imposing_disentitlements.dita`

The following disentitlements related to parental benefits are imposed when the client does not meet the entitlement conditions:

- A D34 is imposed when a client does not meet the entitlement conditions for one of the following reasons:

- The child’s date of birth (DOB) or date of placement is not indicated.

- There is no proof of placement for the purposes of adoption.

- There is no statement of the intent to care for the child.

- The client stops caring for the child during the PW.

- A 35 - Parental benefits - Qualifying Conditions Not Met disentitlement (D35) is imposed for one of the following reasons:

- The client is minor attached (less than 600 hours of insurable employment during the qualifying period [QP]).

- Parental benefits are exhausted.

- The maximum combination of special benefits has been paid.
             [maximum combination of special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#special)

- The maximum combination of regular and special benefits has been paid.
             [maximum combination of regular and special benefits](/en/procedure/generic/additionalresources/max_ent_ben.shtml#combine)

- The claim was not made during the PW.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2720.dita) 

### Outstanding disentitlements

Source topic: `en_EN/task/conv_regpar_eia25/outstanding_disentitlements.dita`

If there is an outstanding disentitlement on the claim, the disentitlement must be reviewed to determine if it still applies to the conversion. A Level 1 officer can terminate or rescind the disentitlement if it meets the conditions specified in the National Policy on Levels of Decision . If the information on file allows for the disentitlement to be terminated, it is terminated on the Friday of the week before the conversion week.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml)

If the outstanding disentitlement is a 15 - Claim procedure disentitlement (D15) imposed by Integrity and related to a missed client information session, the Level 1 officer refers the D15 issue to Level 2.

If Integrity imposed the D15 for any other reason, the Level 1 officer always refers the D15 issue to Integrity. For more information, the officer can refer to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

Based on the letter that was sent, the officer can determine the reason the D15 is imposed:

- For client information sessions, a letter beginning with C-73 is sent.

- For direction to report to a fact-finding interview or to reply to a request for information, a letter beginning with C-72 or C-88 is sent. 

### Allocation of separation monies

Source topic: `en_EN/task/conv_regpar_eia25/allocation_of_separation_monies.dita`

If clients lose their employment after the start of the BP and receive separation monies, the officer must allocate the separation monies.

For more information about allocating separation monies, the officer refers to Allocating separation monies and Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation .
       [Allocating separation monies](/en/procedure/task/all_monies_sep.shtml) 
       [Digest 5.12 — Moneys paid or payable by reason of a lay-off or separation](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-5/moneys-paid-layoff-separation.html#a5_12) 

### Effective date of a renewal or conversion

Source topic: `en_EN/task/conv_regpar_eia25/effective_date_of_a_renewal_or_conversion.dita`

When a client wishes to renew or convert a claim, the officer must determine the effective date. For more information, the officer can refer to Determining the effective date of a renewal or a conversion .
       [Determining the effective date of a renewal or a conversion](/en/procedure/task/deter_date_ren_conv.shtml) 

### Return to work (RTW)

Source topic: `en_EN/task/conv_regpar_eia25/return_to_work_rtw.dita`

If there is an RTW on the claim that is on or after the renewal or conversion date, it prevents the payment of benefits even if the officer inputs a renewal or conversion week. The Level 1 officer refers to the National Policy on Levels of Decision and Correcting a found work or return to work input in error to determine if the conditions are met to rescind or modify the RTW. The Level 1 officer rescinds the RTW when converting the claim. If the decision on the RTW is not within Level 1 authority, the Level 1 officer reassigns the issue to Level 2.
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [Correcting a found work or return to work input in error](/en/procedure/task/actioning_error_claimant_report.shtml) 

### Maximum combination of regular and special benefits

Source topic: `en_EN/task/conv_regpar_eia25/maximum_combination_of_regular_and_spec_7bee3d77.dita`

When regular and special benefits are combined, the maximum number of weeks payable is the equivalent of 50 weeks paid or deemed paid at the basic benefit rate.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2653.dita) 

When the client has received both extended parental benefits and regular benefits, weeks in which no benefits are paid to the client are deemed to be weeks for which benefits were paid at the basic benefit rate. 

### Conversion from regular benefits to extended parental benefits

Source topic: `en_EN/task/conv_regpar_eia25/conversion_from_regular_benefits_to_ext_b6aa6cad.dita`

The officer inputs the conversion transactions directly in FTS without any action from IPOC as long as CPS has paid fewer than 50 weeks of benefits. When 50 weeks of combined regular and special benefits are paid through CPS, an error is generated. The officer actioning the error refers to Actioning a rejected transaction — Error codes C725 and C726 and manually calculates the number of weeks that may still be payable to the client along with any necessary extension of the BP. IPOC processes any remaining weeks of entitlement in MPS.
       [Actioning a rejected transaction — Error codes C725 and C726](/en/procedure/task/actioning_rt_c725_c726.shtml) 

### Conversion from regular benefits on a continuing claim

Source topic: `en_EN/task/conv_regpar_eia25/conversion_from_regular_benefits_on_a_c_75d1747a.dita`

**Processing claimant’s reports**

Before the officer can input the conversion transactions, the last week of regular benefits must be paid. If claimant’s reports have not been processed for the regular benefits period, they must be processed before inputting the conversion. This requires a 2-day input.

**Adjudicating new contentious issues**

When converting a continuing claim, a client may report a new contentious issue (e.g. reason for separation [RFS], farming or availability) that must be adjudicated. If there is no existing WI for this issue, the Level 1 officer creates a Claim Review (CR) WI for each contentious issue and attempts to adjudicate the issue according to the National Policy on Levels of Decision. If it is not possible to adjudicate the issue at Level 1, the Level 1 officer reassigns the CR WI for the contentious issue to Level 2 for adjudication. The Level 1 officer completes the conversion inputs and imposes a 1 - General suspension of benefits (stop payment) manual action (MA1) to prevent payment of benefits until the contentious issue is adjudicated. 

### Selecting the appropriate benefit type (BT)

Source topic: `en_EN/task/conv_regpar_eia25/selecting_the_appropriate_benefit_type_bt.dita`

When the registration of a claim automatically creates a CR WI, in NWS, the Benefit type field in the CR WI is prefilled with Regular . The officer manually updates this field by choosing the appropriate BT. For an initial or renewal claim, the officer selects the BT indicated in the EI application. For a conversion request on continuing claims or any other conversion request, the officer selects the new requested BT.

When creating an Action Item (AI), Call Back (CB), Assessment Issue (ASMT) or Reminder (REM) WI, the officer selects the BT indicated in the EI application. If the BT has changed since the client applied for benefits, the officer selects the BT indicated in FTS. 

### ACS letters

Source topic: `en_EN/task/conv_regpar_eia25/acs_letters.dita`

Communication of the conversion decision is not necessary when the only transaction input is the conversion transaction. When another decision is input at the time of the conversion (disentitlement, disqualification or allocation of earnings), communication of the decision is necessary.

Written communication of the decision is usually done by officers who are responsible for sending the appropriate letter. 

### Client referred under EIA 25

Source topic: `en_EN/task/conv_regpar_eia25/client_referred_under_eia_25.dita`

Generally, it is assumed that clients who are receiving special benefits are on a leave of absence and would not be referred to training under EIA 25 as they have a job to return to. However, regardless of an individual’s attachment to the labour force, it is the referring authority’s decision to refer a client. If a referral is made for a client claiming special benefits, as long as the eligible client meets the entitlement conditions for the type of benefits claimed, special benefits can be paid. The claim type must not be changed to regular benefits. However, the claim is processed in MPS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2775.dita) 

If there is a 3 - Not available disentitlement (D3) imposed on the claim because the client did not prove availability while attending a course of instruction, and the client is referred to training under EIA 25, this disentitlement is terminated on the day before the training begins. If the client did not obtain approval before the training course start date, the D3 is terminated on the day before the approval date.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2776.dita) 

### Authorization to voluntarily leave employment for referred training

Source topic: `en_EN/task/conv_regpar_eia25/authorization_to_voluntarily_leave_empl_2a0344fd.dita`

If the client is referred to training by a designated authority before voluntarily leaving a job, the officer must follow the Adjudicating voluntary leaving (Level 1) — Course of instruction procedure to determine if the voluntary leaving is authorized. The voluntary leaving and the confirmation of the referred training are separate issues.
       [Adjudicating voluntary leaving (Level 1) — Course of instruction](/en/procedure/activity/voluntary_leaving.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2774.dita`

Note:

If a client has been found responsible for a violation for an earlier claim, an increased number of hours may be needed to qualify for parental benefits. 

### Note

Source topic: `en_EN/common_notes/note_c_2712.dita`

Note:

For special benefits, when the renewal week to be entered or the conversion week is after the original last renewable week (LRW) and the BP is extended for combined special benefits, the officer enters the code E - Accept a renewal week effective after the last renewable week of the benefit period in the Notify system to field of the Renewal/Revised (M106) transaction to force the system to adjust the new LRW. 

### Note

Source topic: `en_EN/common_notes/note_c_2719.dita`

Note:

Under certain conditions, the PW may be extended to allow clients more time to receive the benefits to which they are entitled. 

### Note

Source topic: `en_EN/common_notes/note_c_2720.dita`

Note:

A temporary Budget 2021 measure applies to claims for regular and special benefits with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, all claims established with 420 hours of insurable employment or more qualify for special benefits. The definitions of major and minor attached do not apply for the duration of the measure. As a result, the officer does not impose a D35 on claims with a BPC between w/c 2310 and w/c 2361 when the client has accumulated the required number of hours in the QP. However, the officer still determines if a D35 should be imposed for any other reason listed above. 

### Note

Source topic: `en_EN/common_notes/note_c_2653.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

The client can receive combined benefits up to the maximum of 70 weeks or until the LRW is reached, whichever comes first. During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum.

For more information, the officer refers to Updated: Pilot Project No. 24 — Additional weeks .
       [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml)

     [Updated: Pilot Project No. 24 — Additional weeks](/en/site/dossier/miseajour_projet_24_travailleur-update_project_24_worker.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_2775.dita`

Note:

As long as the client’s reason for not working is to care for the child, entitlement to these types of benefits is not questioned. 

### Note

Source topic: `en_EN/common_notes/note_c_2776.dita`

Note:

For more information and instructions on conversions to special benefits and referred training, refer to Confirming referred training: Conversion from regular to special benefits — Continuing claim. 

## Regional considerations

Source topic: `en_EN/task/conv_regpar_eia25/regional_considerations.dita`

**Quebec region**

Clients who live in Quebec and who request benefits due to a pregnancy, birth or adoption must apply to QPIP . The Quebec government pays these benefits to Quebec residents. In some cases, the Quebec government also pays QPIP benefits to a parent living outside of Quebec if both parents lived in Quebec when the initial claim for maternity or parental benefits for the birth or adoption of the same child was made. When a client applying for EI benefits lives in Quebec or indicates that the other parent is entitled to QPIP benefits, the officer on the specialized team that is responsible for liaising with QPIP determines whether the client is entitled to the requested EI benefits.
       [QPIP](/en/procedure/generic/additionalresources/qpip_knowledge.shtml)

When a client living in Quebec is entitled to receive QPIP benefits, an officer from the specialized QPIP team imposes an indefinite 57 - E.I. Maternity or Parental benefits denied, benefits are payable by the province disentitlement (D57). 

## What you need to look for

Source topic: `en_EN/task/conv_regpar_eia25/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/conv_regpar_eia25/in_nws.dita`

- What type of parental benefits and how many weeks of parental benefits is the client requesting?

- Has the client worked since the last week paid?

- Is there an ROE on file? If no, is there employment information on file?

- Are there earnings, separation monies, workers’ compensation benefits (WCB), motor vehicle accident compensation or wage loss insurance (WLI) payments to consider or allocate?

- Is there an Adjudication Issue (ADJ) WI?

- If yes, for what issue?

- Is the DOB, arrival or placement provided?

- Is the SIN of the other parent provided?

- Are the parents sharing parental benefits?

- Is there information about referred training on file?

- Is the number of requested parental weeks indicated? 

### In FTS:

Source topic: `en_EN/task/conv_regpar_eia25/in_fts.dita`

- Are there entitlement weeks remaining to be paid?

- How many weeks of benefits have already been paid to the client?

- Has the last renewable week (LRW) been reached?

- Is there an existing disentitlement?

- Is there an existing disqualification?

- Is there an RTW on the claim?

- Are there any pending claimant’s reports or claimant’s reports to be processed before the conversion?

- Is there a registration number?

- Is there information about referred training on file?

- Has referred training information been input on the Project tab for the training period (codes 9, 35, 53, 95, 97 and 98)?

- Is the client exempt from completing claimant’s reports? 

### In RCM:

Source topic: `en_EN/task/conv_regpar_eia25/in_rcm.dita`

- Has an ROE been submitted?

- Are there earnings, separation monies, WCB, motor vehicle accident compensation or WLI payments to consider or allocate? 

### In Imaging:

Source topic: `en_EN/task/conv_regpar_eia25/in_imaging.dita`

- Is there any referred training information from the client, the province or territory, or another designated authority?

- Is there any other documentation which may impact the conversion claim? 

## Step by step

Source topic: `en_EN/task/conv_regpar_eia25/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/conv_regpar_eia25/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/conv_regpar_eia25/reviewing_the_file_level_1.dita`

- Determine if the training information is on file:

- If no, refer to Confirming referred training — Conversion to special benefits on a continuing claim .
               [Confirming referred training — Conversion to special benefits on a continuing claim](/en/procedure/task/training_cc_rsb.shtml)

- If yes, go to step 2.

- Determine if one of the following situations applies:

- In FTS, the client’s residential address is in Quebec and no EI maternity or parental benefits have been paid for the same BPC.

- The client indicated on the EI application, on the Maternity or Parental: INS5168 Annex 3 ― Form or in the details on file one of the following:

- The client received QPIP benefits in the last 2 years or will receive QPIP benefits.

- The other parent has received, is receiving or will receive QPIP benefits.

- If no, go to step 3.

- If yes, to Reassigning the WI .
               [Reassigning the WI](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#level1_item_6)

- In FTS, determine if a registration number related to the conversion is on file:

- If yes, go to step 4.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Go to step 4.

- Determine if the maximum combination of regular and special benefits has been paid:

- If yes, go to Maximum combination of regular and special benefits already paid .
               [Maximum combination of regular and special benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#maxcomb)

- If no, determine if the maximum number of parental benefits has been paid for the birth or placement:

- If no, go to step 5.

- If yes, go to Maximum parental benefits already paid .
                   [Maximum parental benefits already paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#maxpar)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2713.dita)

- In FTS, on the Rate/Duration tab, determine if the client is minor attached:

- If the BPC is between w/c 2310 and w/c 2361 and the Major Attached box is checked, go to step 6.

- If the client has 600 hours or more , or the Major Attached box is checked, go to step 6.

- If the client has fewer than 600 hours and the Major Attached box is not checked, go to Client is minor attached .
               [Client is minor attached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#minorattached)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2757.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2758.dita)

- Determine if the client reports having received monies and whether they have been allocated:

- If the client reports having received monies and the monies have not been allocated, refer to Earnings and go to step 7.
               [Earnings](/en/procedure/activity/earnings.shtml)

- If the client reports having received monies and the monies have been allocated, go to step 7.

- If no monies were received, go to step 7.

- In NWS and in FTS, determine if one of the following conditions to extend the BP is met:

- The client was incarcerated and has since been tried and has not been found guilty.

- The client received workers’ compensation payments and allocation prevented benefits from being paid.

- The client received preventive withdrawal payments and allocation prevented benefits from being paid.

- The client received separation monies for a definite job loss and allocation prevented benefits from being paid.

- The child for whom parental benefits are claimed was hospitalized during the PW.

- If one of the conditions is met, refer to Extension of the benefit period and go to step 8.
                   [Extension of the benefit period](/en/procedure/activity/extension_benefit_period.shtml)

- If none of the conditions is met, go to step 8.

- Based on the Claim duration section of the Rate/Duration tab in FTS, determine if one of the following conditions is met:

- The client is requesting benefits before the end of the week displayed in the Latest renewable week field.

- The client is requesting special benefits before the end of the week displayed in the End of the initial benefit period field.

- The client is requesting special benefits after the end of the week displayed in the End of the initial benefit period field, but is entitled to an automatic extension of the BP and is requesting special benefits before the end of the extended BP.

- If any condition is met, go to step 9.

- If none of the conditions is met, go to Last renewable week (LRW) has been reached .
                   [Last renewable week (LRW) has been reached](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#lrw)

               [extension of the BP](/en/procedure/activity/extension_benefit_period.shtml)

- Determine if the client has provided all of the following:

- A signed statement attesting to the parental situation (the attestation at the end of the AW application is acceptable).

- All of the necessary information (e.g. child’s DOB, adoption details, nature of the relationship, type of parental benefits requested).

- If the client is a legally recognized parent, confirmation that the client is a legally recognized parent on the child’s birth certificate (a verbal statement from the client documented to the client’s file is acceptable).

- If the adoption or placement raises doubt, written proof of the adoption or placement.

- If no, go to step 10.

- If yes, go to step 16. 

#### Fact-finding

Source topic: `en_EN/task/conv_regpar_eia25/fact-finding_level_1.dita`

- Fact-find with the client as follows:

- If there is no signed statement or INS5168 on file, fact-find using the INS5168 form.
               [INS5168](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/checklists/Maternity_Parental-INS5168_Annex_3_transcript-Form.doc)

- If the type of parental benefits requested is not indicated, what type of parental benefits does the client want to receive? Make sure the client is aware that the type of parental benefits first requested by one of the parents cannot be changed, even if the parental benefits can be shared.

- If the client is a legally recognized parent, is the client legally recognized on the child’s birth certificate?

- If an adoption or placement raises doubt, request written proof of the adoption or placement.

- If the client is not a biological parent, an adoptive parent, a legally recognized parent on the child’s birth certificate, or caring for a child with the intention to adopt, what is the nature of the client’s relationship to the child?

- If the client’s statement does not include all of the necessary information, obtain the necessary information.

- Determine if the client was reached during fact-finding or if the client responded to the N-10-00-00 letter:

- If the client was reached, go to step 12.

- If the client was not reached or did or did not reply to the N-10-00-00 letter, go to step 13.

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Issue: Select Conversion .

- Comments: Type “Parental benefits requested”.

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy . If used during fact-finding, copy and paste the INS5168 form. If the parental benefits are requested for an adoption, type “I attest that the child was placed with me by a recognized authority. I further attest that I consider the placement to be permanent and that it is my intention to adopt the child placed with me since [YYYY-MM-DD]. I understand that the information provided is subject to verification and that making a false statement is subject to an administrative penalty or criminal proceedings for knowingly making this false or misleading statement.”
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the officers is awaiting documentation from the client:

- If the client was contacted and the officer is awaiting documentation, go to step 14.

- If the client was contacted and the officer is not awaiting documentation, go to step 16.

- If the client was not contacted and did not respond to the N-10-00-00 ACS letter, go to Proof of birth, adoption or placement not provided .
               [Proof of birth, adoption or placement not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#proof)

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Fact-finding client .

- Comments: Type “Awaiting documentation for parental benefits.”

- Bring forward date: Enter the current date + 10 business days.

- When the WI moves to the current workload, determine if the information has been received:

- If yes, go to step 16.

- If no, determine if the INS5168 form is required:

- If no, go to step 16.

- If yes, go to Proof of birth, adoption or placement not provided .
                   [Proof of birth, adoption or placement not provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#proof) 

#### Adjudicating entitlement to parental benefits

Source topic: `en_EN/task/conv_regpar_eia25/adjudicating_entitlement_to_parental_benefits_level_1.dita`

- Determine if adjudication of entitlement to parental benefits is required (e.g. the nature of the relationship to the child is not clear, the parents are disputing the type of parental benefits they want to receive, the parents are disputing how they want to share the parental benefits):

- If adjudication is required, go to step 17.

- If adjudication is not required, go to step 19.

- Determine if the conversion is on a continuing or a renewal claim:

- If the conversion is on a continuing claim, in NWS, create a CR WI for Level 2 as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the Service Canada Centre (SCC) as shown in FTS.

- End User: Select Next available user .

- Issue: Select the appropriate option.

- Details: Type “Level 2 adjudication of entitlement to parental benefits is required.”

- Select Save .

- Go to step 18.

- If the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next available user .

- Issue: Select the appropriate issue option.

- Complete the mandatory fields required for the issue.

- Details: Indicate the reason the WI is being created.

- Go to step 19.

- Determine if a D3 has been imposed as a result of the client not being available while attending a course of instruction:

- If no , go to step 19.

- If yes, note that the D3 must be terminated on the day before the referred training begins and go to step 19.

- Determine if there is an outstanding D15 imposed by Integrity:

- If yes, go to step 20.

- If no, go to step 22.

- Determine if the D15 was imposed due to a missed client information session:

- If yes, go to step 21.

- If no, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 22.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- Determine the claim type:

- If it is a conversion on a continuing claim, the issue is sent to Integrity. Refer to Creating or reassigning a WI — Integrity and go to step 22.
               [Creating or reassigning a WI — Integrity](/en/procedure/task/referral_integrity_create_reassign_wi.shtml)

- If it is a conversion on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 2 .

- Language: Select the appropriate option.

- Destination - SCC: Enter the SCC as shown in FTS.

- End User: Select Next Available User .

- Issue: Select Availability .

- Details: Type “Outstanding D15 for a missed client information session, Level 2 review required.”

- Select Save .

- Go to step 22.

- Determine if there are any other outstanding disentitlements on file:

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 23.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate option.

- Details: Type “Outstanding [type of disentitlement] disentitlement.”

- Select Save .

- Refer to the appropriate procedure and go to step 23.

- If no, go to step 24.

- Determine if the conditions are met to terminate or rescind the disentitlement at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 24.

- If yes, terminate or rescind the disentitlement and go to step 24.

- Determine if there are any outstanding issues that require adjudication:

- If yes and the conversion is on a continuing claim, in NWS, create a CR WI as follows:

- Type: Select Revised .

- Issue: Select the appropriate option.

- Registration number: Enter the registration number that was obtained for the conversion. Do not obtain a new registration number.

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Select the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

- Refer to the appropriate procedure and go to step 25.

- If yes and the conversion is on a renewal claim, in NWS, create an ADJ WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Destination — SCC: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Issue: Select the appropriate option.

- Details: Indicate the reason the WI is being created.

- Select Save .

- Refer to the appropriate procedure and go to step 25.

- If no, go to step 26.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- Determine if the conditions are met to adjudicate the issue at Level 1 according to the National Policy on Levels of Decision :

- If no, reassign the WI to Level 2 and go to step 26.

- If yes, complete the steps from the appropriate procedure and go to step 26.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- Determine the conversion week. If necessary, refer to Determining the effective date of a renewal or a conversion .

- Determine if the Level 2 officer is adjudicating entitlement to parental benefits:

- If yes, go to step 28.

- If no, go to step 30.

- In NWS, move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “Awaiting adjudication of entitlement to parental benefits”

- Bring forward date: Enter [10 days from the day the client was contacted].

- When the WI moves to the current workload, determine if the issue has been adjudicated:

- If no, return to step 28.

- If yes, go to step 30.

- Determine the parental start week, the type and the number of parental weeks the client is entitled to.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2722.dita)

- Determine if the client is requesting the conversion during the parental window:

- If yes, go to step 32.

- If no , go to Benefits requested outside of the parental window .
               [Benefits requested outside of the parental window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/conv_regpar_eia25#outsideparentalwindow)

- Determine if there is a pending electronic claimant’s report on the E-Report tab for the period before the conversion:

- If there is no pending electronic claimant’s report, go to step 33.

- If there is a pending electronic claimant’s report, refer to Actioning a pending claimant’s report and go to step 33.
               [Actioning a pending claimant’s report](/en/procedure/task/pending_cr.shtml)

- Determine if there are any rejected electronic claimant’s reports on the Pending/Reject tab for the period before the conversion:

- If no, go to step 34.

- If yes, re-input the claimant’s reports. Refer to Actioning a rejected claimant’s report and go to step 34.
               [Actioning a rejected claimant’s report](/en/procedure/task/rejected_cr.shtml) 

#### Inputs

Source topic: `en_EN/task/conv_regpar_eia25/inputs_level_1.dita`

- In FTS, select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- Determine if the referred training information is displayed on the Project tab:

- If yes, go to step 36.

- If no, go to step 37.

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on Fishing claims or other complex claim conditions .

- Remarks Line 1: Type “EIA 25 — Special benefits.”

- Remarks Line 2: Type “CT [XX], REN WK [XXXX], APW [XXXX], PSW [XXXX], ENT WKS [XX], SEX [XX], SCI 99 (if applicable for extended parental benefits).”
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2777.dita)

- Remarks Line 3: If applicable, type “[NO-CR]”, [claimant’s report information], [MA rescind information], or [D3 termination information].”

- Remarks Line 4: Enter the appropriate information.

- Remarks Line 5: Enter your first name and last name.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 38.

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work type: Select 36 - Special benefits on Fishing claims or other complex claim conditions .

- Remarks Line 1: Type “EIA 25 — Special benefits.”

- Remarks Line 2: Type “CT [XX], REN WK [XXXX], APW [XXXX], PSW [XXXX], ENT WKS [XX], SEX [XX], SCI 99 (if applicable for extended parental benefits).”

- Remarks Line 3: If applicable, type “[NO-CR]”, [claimant’s report information], [MA rescind information], or [D3 termination information].”

- Remarks Line 4: Type “T171 — — STRT-WK/DY [the course start w/c], END-WK-DY [the course end w/c], PROJ-HRRC [the Responsibility Centre code or institution code, if applicable], PROJ-NO [the 10-digit agreement number; use preceding zeros if the number is less than 10 digits], TRAIN-ID [the training ID code], BREAK START/END WK [the w/c code, of any break weeks].”

- Remarks Line 5: Type “[decision maker].”

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction to transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- Determine if any of the following decisions must be communicated to the client:

- There is an allocation of earnings.

- There is a denied antedate.

- A disentitlement is being imposed.

- If yes, go to step 40.

- If no, go to step 41.

- In ACS, create and save or add details to the saved N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- If an antedate has been denied, select Antedate denied or postdate Message - Initial/renewal/continuing claim (2481) .

- Special benefits approved (3046): Select Maternity and/or parental benefits (standard/extended) approved or denied with sickness options (3054) .

- If there is an allocation, select Allocation of Earnings (2516) .

- Waiting period messages (2445) .

- Determine if Level 2 adjudication is required:

- If yes, in NWS, create a client Note and type “Send the N-00-00-00 letter.” Go to step 42.

- If no, send the saved N-00-00-00 letter and go to step 43.

- In NWS, reassign any CR WI for the contentious issue to Level 2 as follows:

- Destination — SCC: Select the SCC as shown in FTS.

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Unable to complete at Level 1.”

- Go to step 43.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2721.dita)

- In NWS, complete the CR Conversion WI. 

#### Maximum combination of regular and special benefits already paid

Source topic: `en_EN/task/conv_regpar_eia25/maximum_combination_of_regular_and_spec_5cf2309f_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “D35 imposed — maximum combination of benefits paid.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as no hours were accumulated after the BPC. D35 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client has received the maximum combination of regular and special benefits. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065): Select:

- Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074) .

- Text - Explain why Parental benefits not payable .

- Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Text - Insert appropriate reason(s) (1618): Type
                   [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2778.dita)

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Maximum parental benefits already paid

Source topic: `en_EN/task/conv_regpar_eia25/maximum_parental_benefits_already_paid_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed — parental benefits exhausted.”

- Details: Select the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the maximum amount of parental benefits has been paid. The client does not qualify for a new claim as no hours were accumulated after the BPC. D35 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the maximum amount of parental benefits has been paid. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Select the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) :

- Select Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074) :

- Select D35 - Not qualified or entitled (various reasons) (3077) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Client is minor attached

Source topic: `en_EN/task/conv_regpar_eia25/client_is_minor_attached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed. Parental benefits — qualifying conditions not met.”

- Details: Type the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the client is minor attached. The client does not qualify for a new claim as no hours were accumulated after the BPC. D35 imposed.”

- If the client has worked since the BPC , type “No conversion is possible as the client is minor attached. The client does not qualify for a new claim as [number of hours] were accumulated after the BPC and the client needed [number of hours] to qualify. D35 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Enter the disentitlement start date.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction : Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) :

- Select Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074):

- Select D35 - Not qualified or entitled (various reasons) (3077) .

- Select D35 - Not qualified - Not enough insurable hours .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, complete the WI. 

#### Last renewable week (LRW) has been reached

Source topic: `en_EN/task/conv_regpar_eia25/last_renewable_week_lrw_has_been_reached_level_1.dita`

- In NWS and FTS, determine if the client has worked since the BPC:

- If yes, go to step 2.

- If no, go to step 3.

- Determine if the client qualifies for a new claim (refer to Calculating or recalculating a claim for parental benefits ):

- If no, go to step 3.

- If yes, continue with the calculation procedure.

- In NWS, create a ROD as follows:

- Comments: Type “Last renewable week reached — parental benefits requested.”

- Details: Type the appropriate option:

- If the client has not worked since the BPC , type “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as no hours were accumulated after the BPC.”

- If the client has worked since the BPC , type “No conversion is possible as the last renewable week has been reached and no benefit period extension is possible. The client does not qualify for a new claim as [hours] were accumulated after the BPC and the client needed [hours] to qualify.”

- In ACS, create and send the F-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Free text (1612) : Type
               [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2779.dita)

- Right to Request a Reconsideration (4169): Select Right to Request Reconsideration .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim denied: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI. 

#### Proof of birth, adoption or placement not provided

Source topic: `en_EN/task/conv_regpar_eia25/proof_of_birth_adoption_or_placement_no_f03d3aa2_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “D34 imposed: proof of birth, adoption or placement not provided.”

- Details: Type “The client was advised to provide [required information]. As of today, the proof of birth, adoption or placement has not been provided. Indefinite D34 imposed.”

- In FTS, select the Renewal / Revised (M106) transaction and impose the D34 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Revival: Select the appropriate Sunday.

- Earnings week 1: Enter the amount (if applicable).

- Claim Type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 34 - Parental benefits entitlement conditions not met .

- Start: Enter the Monday of the week during which the client wants the parental benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Determine if the referred training information is displayed on the Project tab:

- If no, go to step 4.

- If yes, go to step 5.

- Select the Project Data - Training (M171, M107) transaction and enter the following training information as indicated on the referred training documentation or as instructed by your business expertise advisor:

- Start date: Enter the course start week.

- End date: Enter the course end week.

- Project SCC: Enter the appropriate code.

- Project number: Enter the agreement number with preceding zeroes so that there is a total of 10 numeric digits (e.g. agreement number 123456 must be entered as 0000123456).

- Training identification: Select the appropriate code (9, 35, 53, 95, 97 or 98).

- Break Period: Enter the start and end dates, if provided by the referring authority.

- Institution code: Enter the appropriate code.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) .

- Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074): Select D34 - no proof provided (various reasons) (3076) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Benefits requested outside of the parental window (PW)

Source topic: `en_EN/task/conv_regpar_eia25/benefits_requested_outside_of_the_paren_72cc13a6_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “D35 imposed. Parental benefits — qualifying conditions not met.”

- Details: Type “The client requests that parental benefits outside of the parental window. D35 imposed.”

- In FTS, select the Renewal/Revised (M106) transaction and input the D35 and the conversion as follows:

- Registration number: Select the appropriate registration number.

- Renewal: Select the Sunday of the week in which the client wants the parental benefits to start being paid.

- Earnings week 1: Enter the amount (if applicable).

- Claim type: Select 2 - Regular .

- Action: Select Add .

- Disentitlement: Select 35 - Parental Benefits - Qualifying Conditions Not Met .

- Start: Enter the Monday of the week during which the client wants the parental benefits to start being paid.

- End: Select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non fraud - Other .

- Message: Select 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 1 - No .

- Complete: Select C - Yes to clear the registration number.

- Select Update .

- Determine if the referred training is displayed on the Project tab:

- If no, go to step 4.

- If yes, go to step 5.

- Select the Project Data - Training (M171, M107) transaction and enter the following training information as indicated on the referred training documentation or as instructed by your business expertise advisor:

- Start date: Enter the course start week.

- End date: Enter the course end week.

- Project SCC: Enter the appropriate code.

- Project number: Enter the agreement number with preceding zeroes so that there is a total of 10 numeric digits (e.g. agreement number 123456 must be entered as 0000123456).

- Training identification: Select the appropriate code (9, 35, 53, 95, 97 or 98).

- Break Period: Enter the start and end dates, if provided by the referring authority.

- Institution code: Enter the appropriate code.

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065) .

- Parental benefits denied or suspended: D34/D35/D56/D57/Free text (3074) .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request Reconsideration .

- In NWS, complete the WI. 

#### Reassigning the WI

Source topic: `en_EN/task/conv_regpar_eia25/reassigning_the_wi_level_1.dita`

- In NWS, reassign the WI related to the conversion and the following related WIs, if necessary (CB, AI and REM), as follows:

- Destination: Select Level 1 - Natl Processing & Payment Svcs (PPS) / Specialized EI Processing / Specialized EI Processing - QC/QPIP .

- Reason: Select Unable to complete .

- Details: Type “Decision required to determine whether EI or QPIP applies.”

- Select OK .

- No further action is required. 

#### Note

Source topic: `en_EN/common_notes/note_c_2713.dita`

Note:

Under Pilot Project No. 24, the maximum combination of regular and special benefits increases to 70 weeks for long-tenured workers. This measure applies to claims in which at least one week of regular benefits has been paid and the BPC is between w/c 2504 and w/c 2572 (June 15, 2025, to October 10 , 2026).

During these 70 weeks, any combination of regular and special benefits is payable up to each benefit type’s respective maximum. 

#### Note

Source topic: `en_EN/common_notes/note_c_2757.dita`

Note:

For claims with a BPC between w/c 2310 and w/c 2361, 420 hours of insurable employment is required to establish a claim for regular or special benefits, regardless of the conversion date. If the client has 420 or more insurable hours, select the major attached option. 

#### Note

Source topic: `en_EN/common_notes/note_c_2758.dita`

Note:

The system codes claims with a BPC from September 27, 2020 to September 19, 2021 that received a credit of 300 insurable hours as major attached. This means that clients transitioning from the EI Emergency Response Benefit (EI ERB) who have fewer than 600 hours may also qualify for special benefits. 

#### Note

Source topic: `en_EN/common_notes/note_c_2721.dita`

Note:

When an issue cannot be adjudicated at Level 1 or an existing disentitlement cannot be rescinded or terminated at Level 1, reassign the CR WI for the contentious issue to Level 2. Do not reassign the CR Conversion WI. Complete the conversion inputs and impose an MA1 to stop payment. 

#### Note

Source topic: `en_EN/common_notes/note_c_2722.dita`

Note:

In order to determine the number of parental weeks the client is entitled to, consider the following:

- number of weeks requested

- type of parental benefits the client is entitled to

- PW

- BP

- return to work date (if available)

- WP (if one will be served)

- number of weeks the other parent is entitled to (if available) 

#### Note

Source topic: `en_EN/common_notes/note_c_2777.dita`

Note:

If the client is a legally recognized parent on the child’s birth certificate, select the applicable natural parent sex code options. 

#### Callout

Source topic: `en_EN/common_notes/note_c_2778.dita`

“you have received the maximum number of benefits weeks payable to you during this benefit period. The maximum number of benefit weeks paid on this claim cannot exceed a total of [the maximum number of regular and special benefit weeks that can be paid] weeks.

To receive benefits, you must work the required minimum number of insurable employment hours. If you want to receive benefits in the future, you must apply for a new claim.” 

#### Callout

Source topic: `en_EN/common_notes/note_c_2779.dita`

“We cannot reactivate your claim for Employment Insurance benefits starting [renewal week - Sunday’s date] . Please note that we are required to advise you of all decisions made on your claim.

No parental benefits are payable to you on this claim because the last renewable week has been reached on this benefit period.

To receive parental benefits, you must work the required minimum number of insurable employment hours. If you want to receive parental benefits in the future, you must apply for a new claim.” 

## Policy reference

Source topic: `en_EN/task/conv_regpar_eia25/policy_reference.dita`

- BE 2015-05—Section 25 training while in receipt of Special Benefits
         [BE 2015-05—Section 25 training while in receipt of Special Benefits](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2016-05.shtml)

- EIA 12(6)
         [EIA 12(6)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-12.html)

- EIA 22(1)
         [EIA 22(1)](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-22.html) 
