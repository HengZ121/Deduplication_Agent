# Post-EI ERB: Completing an Assessment Issue ROE Comments WI — Fishing ROE

Source map: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/post_eierb_completing_assessment_issue__cfd4df03.ditamap`

## Summary

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/summary.dita`

Summary: ACP creates an Assessment Issue (ASMT) ROE Comments WI in the specialized ACP process when the comments on a fishing ROE require review to determine if they impact claim calculation or entitlement.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2628.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_2628.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP no longer creates WIs based on specialized processing. However, the agent continues to complete outstanding WIs that were created by the specialized process before August 16, 2021 using specialized procedures. 

## What you need to know

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4042.dita) 

ROE comments appear in block 12 for fishing ROEs. The intended use of the Comments block is for the employer to clarify or provide additional information. 

### Comment types

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/comment_types.dita`

Comments generally fall into one of 3 categories:

- No impact: information that is not relevant to claim calculation or entitlement, e.g. a personal note to the employee such as “Best of luck in the future.”

- Repetitive information: information already indicated elsewhere, e.g. comments indicate “end of season”, “quota reached” or “shortage of work” and block 11 displays A - End of Fishing .

- Possible impact: information that is relevant to claim calculation or entitlement, e.g. additional details about separation monies or the reason for separation (RFS), additional trip dates. 

### Creating a WI

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/creating_a_wi.dita`

An artificial intelligence model attempts to address comments before the ROE enters the ACP specialized process. During the ACP specialized process, the system creates an ASMT ROE Comments WI for the last ROE only if the artificial intelligence model was unable to address the comments on the ROE. The system assigns these WIs to Non-complex agents.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4043.dita) 

### Impact on calculation

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/impact_on_calculation.dita`

The agent reviews comments that could impact claim calculation or entitlement and modifies the ROE in RCM accordingly. The agent copies these comments to the Additional information field in RCM before removing them from block 12 .

Comments that have no impact or contain repetitive information are removed from block 12 at the Non-complex level. If the comments cannot be removed based on the procedure, the agent reassigns the ASMT ROE Comments WI to Level 1.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4044.dita) 

### ROE errors found during validation

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/roe_errors_found_during_validation.dita`

ROEs are automatically validated by the system. In some situations, this validation can be performed only when a change is made in RCM, such as deleting a comment. If an error is detected during validation, the agent corrects the ROE to allow automation. If the error cannot be corrected at the Non-complex level, the agent reassigns the ASMT ROE Comments WI to Level 1. 

### Note

Source topic: `en_EN/common_notes/note_c_4042.dita`

Note:

This task applies only to ASMT WIs that were created to address comments on an ROE in the specialized ACP process before its end date of August 16, 2021. For comments on an ROE in the normal ACP process, the agent refers to Completing an ROE Comments WI — Fishing ROE .
       [Completing an ROE Comments WI — Fishing ROE](/en/procedure/task/roe_comments_sef.shtml)

     [Completing an ROE Comments WI — Fishing ROE](/en/procedure/task/roe_comments_sef.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_4043.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP no longer creates WIs based on specialized processing. However, the agent continues to use this task to process outstanding WIs that were created before August 16, 2021. 

### Note

Source topic: `en_EN/common_notes/note_c_4044.dita`

Note:

Comments about the Coronavirus, COVID-19 or the client being in quarantine do not have an impact on calculation and should be actioned at the Non-complex level. 

## Regional considerations

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/in_nws.dita`

- Why was the WI reassigned to Level 1?

- Is there an ASMT ROE Correction WI for the same ROE? 

### In RCM:

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/in_rcm.dita`

- Are there comments displayed in block 12 of the ROE?

- Which error messages are displayed when validating the ROE? 

## Step by step

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/step_by_step.dita`

### Non-complex

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/non-complex.dita`

#### Reviewing the conditions to allow at Non-complex level

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/reviewing_the_conditions_to_allow_at_no_73969f75_non-complex.dita`

- Determine if the comments can be removed from block 12 according to the table below and complete the necessary actions.

```text
| Conditions present on the ROE. Both conditions must be present to make changes. | In RCM, complete the following fields: |

| Block 12 comments indicate: | Other conditions: | Block 12 | Other changes required |

| any non-contentious RFS (e.g. end of season or quota reached) | Block 11: RFS is B - Other | Move the comments to the Additional information field. | Block 11: Select A - End of Fishing . |

| requested by fisher or requested by employee | Block 11: RFS is B - Other | Move the comments to the Additional information field. | Block 11: Select A - Requested by Fisher . |

| contentious RFS (e.g. labour dispute) | Block 11: RFS is B - Other | Move the comments to the Additional information field. | No change required. |

| amended ROE (including original ROE serial number) | | Delete the comments. | Block 2 : Serial No. of ROE amended or replaced : Type the original ROE serial number |

| comments that have no impact on calculation or entitlement (e.g. personal comments | | Delete the comments. | |
```

- If the comments could be removed from block 12 , go to step 2.

- If the comments could not be removed, go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__cfd4df03#nc_item_4) 

#### Inputs

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/inputs_non-complex.dita`

- In RCM, select Validate and do the following:

- If errors are displayed for any block, go to step 3.

- If no error is found, select Submit and go to step 5.

- In NWS, determine if an ASMT ROE Correction WI exists for this ROE:

- If no , go to step 4.

- If yes, go to step 5. 

#### Correcting ROE errors

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/correcting_roe_errors_non-complex.dita`

- Determine if the ROE can be corrected according to Post-EI ERB: Completing an Assessment Issue (ASMT) ROE Correction WI — Fishing ROE :

- If yes, correct the ROE and go to step 5.

- If no , go to Reassigning the WI to Level 1 .
               [Reassigning the WI to Level 1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/post_eierb_completing_assessment_issue__cfd4df03#nc_item_4)

- Complete the ASMT ROE Comments WI. 

#### Reassigning the WI to Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/reassigning_the_wi_to_level_1_non-complex.dita`

- In NWS, reassign the ASMT ROE Comments WI to Level 1 as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 1 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate option:

- “According to the procedure, comments cannot be removed — Level 1 to review.”

- “Unable to correct ROE at Non-complex level.” 

### Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/reviewing_the_file_level_1.dita`

- In NWS, determine why the WI was reassigned to Level 1:

- If there are comments in block 12 to be reviewed, go to step 2 .

- If another agent removed the comments but an ROE error requires correction, go to Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Fishing ROE .
               [Post-EI ERB: Completing an Assessment Issue ROE Correction WI — Fishing ROE](/en/procedure/task/Post_eierb_completing_assessment_issue_roe_correction_wi_fishing_roe.shtml) 

#### Reviewing the conditions to allow at Level 1

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/reviewing_the_conditions_to_allow_at_level_1_level_1.dita`

- Determine if the comments in block 12 can be actioned without clarification from the employer (e.g. lobsters not sold yet):

- If no , go to step 3.

- If yes , go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/fact-finding_level_1.dita`

- Fact-find with the employer by phone.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4045.dita)

- Determine if clarification has been obtained:

- If no , go to step 5.

- If yes, go to step 7. 

#### Required information has not been obtained

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/required_information_has_not_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE as necessary based on the comments in block 12 .

- Comments: Remove the text.

- Additional information: Copy the comments from block 12 and type: “Changes made with information available on file, as unable to confirm with the employer.”

- In ACS, create and send the Z-02-00-00 letter. Unless specified, select the most appropriate option for each of the following attributes:

- Employer or Third Party Name (1334)

- Employer or Third Party Address 1 (1336)

- Opening Sentence to ER re: Request or Clarify ROE/RFS (2794)

- Request ROE Opening Sentence - claimant

- Notification of Changes to a ROE (2805): Select one of the following:

- Multiple Changes to ROE

- A Single Change to ROE

- List of the change

- Attached INS 3413

- Go to step 8. 

#### Required information has been obtained

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/required_information_has_been_obtained_level_1.dita`

- In RCM, change the ROE as follows:

- Correct the ROE based on the information obtained from either the fact-finding or the Comments field.

- Comments: Remove the text.

- Additional information: Copy the comments from block 12 and do the following:

- If the comments were removed from block 12 after clarification from the employer, type “Changes confirmed with [full name and position title]” and include details for any unchanged blocks confirmed by the employer.

- If the comments were removed from block 12 with no clarification from the employer, type “Changes made to blocks [X] in accordance with the EI ORT.”

- In RCM, select Validate and do the following:

- If errors are displayed for any block, go to step 9.

- If no errors are displayed, select Submit and go to step 10.

- Correct the ROE to fix the validation error and go to step 10. For procedures on correcting an ROE, refer to Post-EI ERB: Completing an Assessment Issue ROE Correction WI – Fishing ROE .

- In NWS, complete the ASMT ROE Comments WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_4045.dita`

Note:

If the employer cannot be reached on the first attempt, leave a message. If unable to leave a message on the first attempt or if the employer does not call back within 24 hours, make one more attempt by phone but do not leave a message on the second attempt. Document the attempts in a draft SROC per usual procedures.

If the employer provides details specific to the RFS, create an SROC to document the information. Document all other changes in RCM. 

## Policy reference

Source topic: `en_EN/task/post_eierb_completing_assessment_issue__cfd4df03/policy_reference.dita`

 
