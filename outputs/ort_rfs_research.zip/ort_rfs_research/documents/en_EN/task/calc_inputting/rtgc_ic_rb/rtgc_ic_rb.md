# Reviewing the transactions generated during the calculation of a claim

Source map: `en_EN/task/calc_inputting/rtgc_ic_rb/rtgc_ic_rb.ditamap`

## Summary

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/summary.dita`

Summary: The transactions generated during the calculation of a claim must be reviewed and, if necessary, modified. 

## What you need to know

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

### Reviewing the transactions generated

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/reviewing_the_transactions_generated.dita`

Once the calculation result is accepted, SSO generates the transactions required to finalize the calculation decision. The transactions generated must be reviewed and, if necessary, modified. The actions required will depend on if this is an initial calculation or a recalculation.

**Initial calculations**

If the benefit period (BP) can be established, the transactions include the information required to establish:

- the qualifying and entitlement conditions;

- the rate and duration for benefits.

If the BP cannot be established, the transactions generated are used to identify which qualifying conditions were not met (BPNE type).

While the transactions are normally correct, modifications are sometimes required. This could be due to a warning message displayed during calculation of the claim or a known system bug (SRMIS) as found on the UIC/SSA Anomalies and Enhancements list. The officer calculating the claim must ensure the transactions are accurate and must make any required adjustments before input in BPS. This ensures the client’s claim contains the correct qualifying and entitlement information.
       [UIC/SSA Anomalies and Enhancements](https://esdc.prv/en/service-canada/ei/technologies/uic-ssa/bugs_enhancements_uic_ssa.shtml)

If modifications to transactions or additional transactions are required, the officer must ensure the last transaction completes the registration number. Otherwise, the claim registration number remains outstanding and affects the speed of service statistics.

**Recalculations**

A Recalculation Input Guide has been developed to provide officers with the data entry requirements to recalculate established and not established claims. When recalculating a claim, the officer must refer to the input guide to determine if the transactions have been properly generated. If any of the inputs do not work as described in the guide, consult with a business expertise advisor for actions required.
       [Recalculation Input Guide](https://esdc.prv/en/service-canada/ei/technologies/bps/index.shtml)

If the BP to be recalculated is displayed on the Dormant tab in FTS and no active claim is displayed on the Summary screen in FTS, the officer must reactivate the terminated BP before the recalculation can be transmitted.

Once all of the required transactions have been reviewed for input, the officer reviews the client’s file to determine if claimant’s reports must be input along with the transactions (e.g. calculation has resulted in an antedated BPC). The officer calculating the claim determines if claimant’s reports are required and obtains them when necessary. When claimant’s reports are required for an antedated BPC, they must cover the complete period from the new BPC to the old BPC. When claimant’s reports are not obtained, the officer recalculates the claim without changing the BPC.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2358.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

### Note

Source topic: `en_EN/common_notes/note_c_2358.dita`

Note:

If the client worked during the period for which the claimant’s reports are required, the earnings are coded on the claimant’s reports without a found work code. If earnings were input for the BPC week of the previous calculation, the officer determines if the claimant’s report for the BPC week has been processed. If so, the officer enters the amended earnings on a M175 - Allocation Set-up ( M175) transaction. If the claimant’s report for the BPC week has not been processed, the officer transmits a M106 - Subsequent decision (M106) transaction with 0000 in the Earnings week 1 field before transmitting the antedate of the claimant’s report for the BPC week. 

## Regional considerations

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/what_you_need_to_look_for.dita`

### In SSO:

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/in_sso.dita`

- What transactions were generated when the claim calculation was accepted? 

### In NWS:

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/in_nws.dita`

- Is this an initial calculation or a recalculation?

- If this is a recalculation and the BPC is antedated or if a previously BPNE claim is established, are claimant’s reports on file for the period from the new BPC to the old BPC? 

### In FTS:

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/in_fts.dita`

- If this is a recalculation, is the BP displayed on the Dormant tab?

- If yes, is there is an active claim displayed on the Summary screen? 

## Step by step

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/level_1.dita`

#### Reviewing the transactions generated

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/reviewing_the_transactions_generated_level_1.dita`

- Determine if this is an initial calculation or a recalculation:

- If this is an initial calculation, go to Initial calculation .
               [Initial calculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_inputting/rtgc_ic_rb#initial)

- If this is a recalculation, go to Recalculation .
               [Recalculation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/calc_inputting/rtgc_ic_rb#recalcs) 

#### Initial calculation

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/initial_calculation_level_1.dita`

- In SSO, review the transaction currently on screen and determine if one of the conditions below applies:

```text
| Transaction number | Conditions present | Changes required | Additional actions |

| 103 | A claim is being incorrectly calculated as N2 due to one period of employment declared on the application and one deleted or voided ROE in RCM (SRMIS 4024528). | Complete the following field (delete any other content): - Date field in the BPC section: Enter the BPC w/c. - Gender: Select the appropriate option. - Pending review: Select P - Benefit period not established 1 or 7 . - Last job: Enter the National Occupational Classification code of the last job (should be prefilled correctly). - Employer: Enter the last employer’s Canada Revenue Agency business number (should be prefilled correctly). - Cut off date: Enter the cut-off date. - Economic region: Select the economic region code of the client’s residence (should be prefilled correctly). - Reason for separation: Select the reason for separation code of the last employment. - Tax credit: Select the tax credit option (should be prefilled correctly). - Registration number: Enter the Document Control System registration number (should be prefilled correctly). - Decision type: Select 1 - Initial (should be prefilled correctly). - BPNE: Select 1 - Insufficient insured hours . - Contentious: Select 1 - No for not contentious and 2 - Yes for contentious (should be prefilled correctly). - Complete: Select C - Yes (should be prefilled correctly). | None |

| 103 | The Wage loss insurance field displays 1 - WLI or paid sick leave in the waiting period - continuing WP may be waived instead of an allocation for wage loss insurance (WLI) or paid sick leave (PSL) which has a known end date that goes beyond the waiting period (WP) (SRMIS 1176809). | - Complete the following field: - Wage loss insurance: Delete contents. - Select Next to page through the transactions and determine if a M175 - Allocation Set-up (M175) transaction has been created: - If no, select Previous to page through the transactions, return to the M103 - Initial Decision (M103) transaction and follow the actions indicated in Additional actions to create the M175 - Allocation Set-up (M175) transaction. - If yes, go to step 3. - Do the following to modify the M175 - Allocation Set-up (M175) transaction and add a new allocation as follows: - If SSO has not allocated the WLI, do the following: - Allocation type: Select F - Wage loss insurance . - Amount: Enter the amount of earnings to allocate for each week. - Start date: Enter the code for the start week of the allocation. - End date: Enter the code for the end week of the allocation. - Last week amount: If there is an amount that is less than the weekly amount remaining in the last week, enter the amount to allocate in the last week. Otherwise, leave the field blank. - If SSO has not allocated the PSL, do the following: - Allocation type: Select L - Paid sick leave . - Amount: Enter the amount of earnings to allocate for each week. - Start date: Enter the code for the start week of the allocation. - End date: Enter the code for the end week of the allocation. - Last week amount: If there is an amount that is less than the weekly amount remaining in the last week, enter the amount to allocate in the last week. Otherwise, leave the field blank. - Contentious: Select the appropriate option. - Complete: Select D - No . - Select Update . - Select Previous or Next as required to return to the M103 - Initial Decision (M103) transaction. | - If there is not a M175 - Allocation Set-up (M175) transaction, in FTS, create one as follows: - Registration number: Select the appropriate registration number. - If SSO has not allocated the WLI, do the following: - Type: Select F - Wage Loss Insurance . - Amount: Enter the amount of earnings to allocate for each week. - Start date: Select the code for the start week of the allocation. - End date: Select the code for the end week of the allocation. - Last week amount: If there is an amount that is less than the weekly amount remaining in the last week, enter the amount to allocate in the last week. - If SSO has not allocated the PSL, do the following: - Type: Select L - Paid Sick Leave . - Amount: Enter the amount of earnings to allocate for each week. - Start date: Select the code for the start week of the allocation. - End date: Select the code for the end week of the allocation. - Last week amount: If there is an amount that is less than the weekly amount remaining in the last week, enter the amount to allocate in the last week. Otherwise, leave the field blank. - Decision type: Select 1 - Initial . - Contentious: Select the appropriate option. - Completed: Select C - Yes . - Store the transaction and on the calculation worksheet, note which day it is required. - Return to SSO. |

| 103 | The Waiting period field incorrectly displays 2 - Waived on an apprentice claim qualifying for a WP waiver. | Complete the following fields: - Waiting period: Select 6 - Waived for apprentices . - Wage loss insurance : Delete contents. | None |

| 103 | The Wage loss insurance field is blank on a claim qualifying for a WP waiver due to PSL or QPIP payments. | Do the following: - Waiting period: Ensure 2 - Waived is displayed. - Wage loss insurance: Select 3 - Paid sick leave prior to benefit period commencement. WP must be waived . | None |

| 103 | An Assessment (ASMT) Insurability WI is Pending for an insurability ruling on an ROE in the qualifying period which the client requires to qualify for benefits. | Complete the following field: - Manual action: Select 73 - Canada Revenue Agency case . | In RCM, update the ROE as follows: - Status: Select Insurability Ruling Pending . - Select Submit . |

| 103 | A claim for sickness benefits is being calculated with a medical certificate that is outstanding and the Recovery week field is blank. | Complete the following field: - Recovery week: Is Indefinite?: Select Yes . | |

| 103 | A claim is being established for maternity benefits and the week indicated in the Actual date of birth field is not the same as the week indicated in the Expected date of birth field. | Complete the following field: - Confinement week: Select the expected date of confinement. - Complete: Select D - No . | In FTS, create a Subsequent decision - Special Benefits (M106) transaction as follows: - Actual date of confinement - Store the transaction (for Day 2). - Return to SSO. |

| 103 | A claim is being established with Yes selected in the No claimants report required section but a return to work (RTW) date is indicated on the most recent ROE, or provided by the client elsewhere on the file. | Complete the following field: - Return to work: Enter the w/c of the client’s RTW date indicated on the ROE or elsewhere on the file. | None |

| 103 | A claim for combined sickness, and maternity benefits is being established with a Recovery week that is the week before the maternity start week. | Complete the following field: - Recovery week: Is Indefinite?: Select Yes . | None |

| 103 | A claim for combined sickness, maternity and parental benefits is being established. | Complete the following field: - No claimants report required: Determine if the exemption from reporting request is on file: - If yes and the No claimants report required field displays No , select Yes . - If no, leave the No option pre-filled. - If the Recovery week is the week before the maternity start week, do the following: - Recovery week: Is Indefinite?: Select Yes . - Complete: Select D - No . | - In FTS, create a Subsequent decision - Special Benefits (M106) transaction as follows: - Registration number: Select the appropriate registration number. - Arrival/Placement week: Enter the arrival/placement w/c. - Start Week: Enter 9999. - Entitlement weeks: Enter the amount of parental weeks the client is entitled to. - Supplemental claim information: Select 99 - Parental extended (if required). - Decision type: Select 1 - Initial . - Contentious: Select the appropriate option. - Completed: Select C - Yes . - Return to SSO. |

| 107 | The maternity window must be manually extended due to the hospitalization of the child on an initial claim and the maternity benefits are not being interrupted. | Complete the following field: - External maternity end week: Input the external maternity end week. | None |

| 107 | The only field completed other than the Registration number line is the External maternity end week (SRMIS 1524271). | Complete the following field: - Registration number: Delete contents. - Decision type: Delete contents. - BPNE: Delete contents. - Contentious: Delete contents. - Complete: Delete contents (if field entry was a C - Yes , you must modify the previous transaction so that it contains a C - Yes in this field). | None |

| 112 | A D51/D61, D52/D62 or D53/D63 disentitled must be manually imposed on the claim. | Modify the following fields: - Start week: Delete contents. - Entitlement weeks: Delete contents. - Waiting period served: Delete contents. - End week: Delete contents. - Status: Input applicable code: - D51/D61 - Does not meet caregiver/compassionate care entitlement conditions - Not a family member. Status code 13. - D52/D62 - Maximum number of caregiver/compassionate care benefit weeks paid for patient. Status code 10. - D53/D63 - Does not meet caregiver/compassionate care entitlement conditions - Inadequate medical certificate. Status code 14 . - D53/D63 - Claimant is not eligible - Medical certificate not issued by a medical practitioner within the meaning of the Employment Insurance Regulations. Status code 16 . [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2359.dita) | |

| M149 | The First name field was modified because the client has only one name. | If the First name field on the Name and Address screen in SSO was modified to “NA” because the client has only one name and selected X as the gender marker, enter a “.” in the First name field. | None |

| M159 | The First name field was modified because the client has only one name. | If the First name field on the Name and Address screen in SSO was modified to “NA” because the client has only one name and selected X as the gender marker, enter a “.” in the First name field. | None |

| 161 | A D43 disentitlement is input for a leave of absence without just cause for which the leave of absence end date is known. | Complete the following field: - End date: Select the correct end date of the leave of absence. | |

| 171 | Input the apprenticeship training information as follows: | Complete the following fields: - Date field in the Start week section: Select the start date of the training. - Date field in the End week section: Select the end date of the training. - Project number: Enter the first 10 digits of the reference code. - Project SCC: Enter the first 4 digits of the reference code. - Training identification: Select 21 - Apprentice full- transfer labour market agreement . - Apprentice indicator: Determine if there is an advance payment request: - If the client has not requested advance payment and the reason for separation is J- Apprenticeship Training , select 1 - No advance pay, stop claimant’s report at course end week . - If the client has not requested advance payment and the reason for separation is not J- Apprenticeship Training , select 2 - No advance pay, continue claimant’s reports beyond course end week . - If the client has requested advance payment and the reason for separation is not J- Apprenticeship Training , select 3 - Advance pay, stop claimant’s reports at course end week . - If the client has requested advance payment and the reason for separation is not J- Apprenticeship Training , select 4 - Advance pay, continue claimant’s reports beyond course end week . - Institution code: Enter the first 6 digits of the reference code. - Claimant’s report: Determine if the exemption from reporting request is on file: - If yes, select Rescind . - If no, leave the field blank. | |

| 175 | There is an allocation of monies due to permanent separation and the permanent separation from employment occurred in a different week than the last day worked. | - Determine the correct allocation dates and amounts. Refer to the Earnings activity for guidance if required. [Earnings](/en/procedure/activity/earnings.shtml) - Determine if the correct allocation start date is different than the one currently displayed on the –M175 - Allocation Set-up (M175) transaction: - If no, no further action is required. - If yes, complete the following fields: - Start date: Select the correct w/c for the allocation start week. - End date: Select the correct w/c for the allocation end week. - Last week amount: Enter the correct amount for the last week of the allocation. [Earnings](/en/procedure/activity/earnings.shtml) | |
```

- If none of the conditions apply, go to step 2.

- If any of the conditions apply, follow the changes and additional steps indicated. Go to step 2.

- Select Next to page through to the next transaction.

- Determine if there is a new transaction on the screen which you must review:

- If yes, return to step 1.

- If no, go to Reviewing the calculation to determine if additional transactions are required .
               [Reviewing the calculation to determine if additional transactions are required](/en/procedure/task/calc_inputting/rcdatr_ic_rb.shtml) 

#### Recalculation

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/recalculation_level_1.dita`

- In FTS, determine if the BP to be recalculated is displayed on the Dormant tab:

- If no, go to step 5.

- If yes, determine if an active claim is displayed on the Summary screen:

- If no, go to step 2.

- If yes, go to step 5.

- On the Dormant tab, select the appropriate BPC:

- Select Reactivate .

- Move the WI to Pending as follows:

- Pending reason: Select Other .

- Comments: Type “waiting for claim status to change to active.”

- Bring forward date: Enter the next business day.

- When the WI moves to the current workload, go to step 5.

- In SSO, review the transaction currently on screen and based on the Recalculation Input Guide and any additional inputs required when inputting the claim calculation (i.e. a message code for an approved write-off), determine if the transaction is correct, must be modified or deleted:

- If the transaction is correct, go to step 6.

- If the transaction requires modifications, modify the transaction as indicated in the guide. Go to step 6.

- If the transaction must be deleted, select Delete to delete the transaction and go to step 7.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2360.dita)

- Select Next to page through to the next transaction.

- Determine if there is a new transaction on the screen which you must review:

- If yes, return to step 5.

- If no, go to step 8.

- On the calculation worksheet, note any additional transactions the Recalculation Input Guide indicates are required for the recalculation.

- Based on the transaction indicated in the Recalculation Input Guide , determine if claimant’s reports are required:

- If yes, go to step 10.

- If no, go to step 14.

- Determine if there are claimant’s reports already on file for the period required:

- If no, fact-find with the client and go to step 11.
               [fact-find](/en/procedure/task/fact_find.shtml)

- If yes, go to step 14.

- Determine if the client was contacted during fact-finding:

- If the client was contacted, go to step 12.

- If the client was not contacted or did not reply to the N-10-00-00 letter, go to step 13.

- In NWS, add to the draft SROC or create a new SROC as follows:

- New SROC: Main Issue: Select Calculation .

- New SROC: Comments: Type “claimant’s reports required for recalculation.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save and go to step 14.

- In NWS, create a record of decision (ROD) as follows:

- Comments: Type “Unable to obtain claimant’s reports — recalculation of the claim with no change to the benefit period commencement (BPC).”

- Details: Type “Claimant’s reports required to input the recalculation of the claim — the BPC change cannot be input at this time.”

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_2361.dita)

- Go to Reviewing the calculation to determine if additional transactions are required . 

#### Note

Source topic: `en_EN/common_notes/note_c_2359.dita`

Note:

When a D63 is generated, update only the status code. 

#### Note

Source topic: `en_EN/common_notes/note_c_2360.dita`

Note:

If the recalculation result is NCA - No changes to the claim and the only change was a supplemental unemployment benefits (SUB) plan being added or removed from the ROE, ensure that the Waiting Period Waiver field is updated on the Determination of Earnings screen in SSO to reflect whether the WP should be waived. 

#### Note

Source topic: `en_EN/common_notes/note_c_2361.dita`

Note:

Ensure that the BPC displayed in FTS is entered in the Subsequent or manual BPC field on the Coding Requirements screen in SSO. 

## Policy reference

Source topic: `en_EN/task/calc_inputting/rtgc_ic_rb/policy_reference.dita`

 
