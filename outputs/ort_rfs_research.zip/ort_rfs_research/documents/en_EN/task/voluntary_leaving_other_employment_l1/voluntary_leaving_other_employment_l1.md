# Adjudicating voluntary leaving (Level 1): Other employment — Continuing claim

Source map: `en_EN/task/voluntary_leaving_other_employment_l1/voluntary_leaving_other_employment_l1.ditamap`

## Summary

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/summary.dita`

Summary: When a client voluntarily leaves employment with the intent of starting other employment, the client’s entitlement to benefits on a continuing claim may be affected. Adjudication is required to determine if there was just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/what_you_need_to_know.dita`

### Adjudicating voluntary leaving for other employment

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/adjudicating_voluntary_leaving_for_othe_4cb01a91.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless the client has enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

Voluntary leaving for other employment includes the following situations:

- voluntarily leaving a job to start another within 4 weeks;

- voluntarily leaving a job to continue to work full-time in another (when working both jobs at the same time);

- voluntarily leaving one job for another when there is a genuine job offer (but the new job is not obtained for reasons beyond the client’s control);

- voluntarily leaving insurable employment to become self-employed.

Voluntary leaving for other employment does not include the following situation:

- voluntarily leaving to look for another job.

An ROE is not required to adjudicate a voluntary leaving. 

### Determining full-time employment

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/determining_full-time_employment.dita`

Full-time employment means that the employee works the number of hours normally worked by full-time employees in the occupation or industry.

In most cases, full-time employment means working 35 hours or more per week. 

### Automated adjudication

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/automated_adjudication.dita`

ACP does not adjudicate voluntary leaving on a continuing claim. 

### Levels of decision

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/levels_of_decision.dita`

A Level 1 officer can adjudicate voluntary leaving on a continuing claim when specific conditions are met and the client left employment for one of the following reasons:

- leaving one employment and continuing full-time employment;

- accepting a job offer with no more than a 4-day gap between the first day worked with the new employment and the LDW from the previous employment ;

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/employment_is_not_insurable.dita`

Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is not required if the employment is not insurable because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. 

### Actions required following adjudication

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/actions_required_following_adjudication.dita`

When the voluntary leaving is adjudicated and the ROE is received, the Special condition field of the ROE must be updated to show either Voluntary leaving - Just cause or Voluntary leaving - No just cause . 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the reason for separation (RFS) was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

## Regional considerations

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs, or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application? 

### In FTS:

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/in_fts.dita`

- Is there a 75 - Verification of reason for termination of Employment manual action (MA75) imposed to stop payments?

- Is there a registration number? 

### In Imaging:

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/reviewing_the_file_level_1.dita`

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 2.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_other_employment_l1#Employment_is_not)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if there is enough information to adjudicate the voluntary leaving based on the National Policy on Levels of Decision:

- If additional details are needed, go to step 5.

- If additional details are not needed, go to step 8. 

#### Fact-finding

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/fact-finding_level_1.dita`

- Fact-find with the client or the employer.

- Determine if the client or employer was contacted during fact-finding:

- If the client or employer was contacted, go to step 7.

- If the client or employer was not contacted or did not reply to the N-10-00-00 or Z-00-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_other_employment_l1#reassigntol2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — [client or employer].”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the conditions are met to adjudicate the issue at Level 1 by referring to the applicable situation below.

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4985.dita) 

- If all the conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_other_employment_l1#_Reason_for_separation)

- If all the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/voluntary_leaving_other_employment_l1#reassigntol2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — just cause.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In RCM, verify if the ROE with the voluntary leaving has been received:

- If yes, go to step 3.

- If no, go to step 4.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select E - Quit / Take another job or E - Quit / To become self-employed .

- Special condition: Select Voluntary leaving - Just cause .

- Cut and paste any comments related to the voluntary leaving from block 18 to the Additional information field.

- Select Validate .

- Select Submit .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3230.dita)

- In FTS, determine if there is a D11 was imposed because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 was only imposed due to this previously deferred RFS issue and if no other issues must be adjudicated.

- If no other issues need to be adjudicated, go to step 6.

- If other issues must be adjudicated, go to the appropriate task for guidance. Go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Determine if an MA75 is imposed and if there is a registration number for the voluntary leaving:

- If an MA75 is imposed but there is no registration number, go to step 8.

- If an MA75 is imposed and there is a registration number, go to step 9.

- If no MA75 is imposed but there is a revised registration number, go to step 10.

- If none of the above applies, go to step 11.

- Select the Registration Number (M025, M030, M035) transaction and obtain a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Select the Renewal/Revised (M106) transaction and remove the MA75 as follows:

- Registration number: Select the applicable registration number.

- Manual Action: Select 75 - Verification of reason for termination of Employment .

- Rescind: Check the box.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 11.

- Select the Renewal/Revised (M106) transaction and clear the outstanding registration as follows:

- Claim allowed: Select NCA - no change on the claim .

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI related to the voluntary leaving. 

#### Employment is not insurable

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Enter the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Complete the WI related to the voluntary leaving. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/reassigning_the_issue_to_level_2_level_1.dita`

- In FTS, on the Summary tab, determine if an MA75 has been imposed:

- If yes, go to step 2.

- If no and the client is requesting special benefits, go to step 2.

- If no and the client is requesting regular benefits, select the Renewal/Revised (M106) transaction and impose the MA75 as follows:

- Registration Number: Leave the field blank. If a number is displayed, remove it.

- Manual action: Select 75 - Verification of reason for termination of Employment .

- Select Update .

- In NWS, reassign the WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client quit [his/her] job and [provide a brief reason for the referral, e.g. employment gap is greater than 4 weeks] — unable to complete at Level 1.”

- Select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4985.dita`

Voluntary leaving to accept other employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the new employment was supposed to be permanent; and

- there was no more than a 4-day gap between the first day worked with the new employment and the LDW from the previous employment; or

- the first day worked with the new employment started before the LDW at the previous employment; and

- the weekly number of hours at the new employment was equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

Voluntary leaving temporary employment to accept other temporary employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the new temporary employment was supposed to last longer than the previous temporary employment; and

- there was no more than a 4-day gap between the first day worked with the new employment and the LDW from the previous employment; or

- the first day worked with the new employment started before the LDW from the previous employment; and

- the weekly number of hours at the new employment was equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

Note:

Temporary employment is defined as a seasonal, contract, or term employment, and has an end date.

Permanent employment is defined as a lasting employment, or an employment that is intended to last or to remain unchanged indefinitely. It has no end date.

Voluntary leaving employment to continue working in full-time employment — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- the client had more than one employment at the same time and voluntarily left one of them; and

- the employment the client kept was full-time and the client was not expecting it to end.

Note:

On a continuing claim, all voluntary leaving for other employment must be adjudicated at Level 2, except in the situations described above. 

#### Note

Source topic: `en_EN/common_notes/note_c_3230.dita`

Note:

Selecting Validate may cause the ROE to be flagged with an error. If this occurs, no further action is required. If the client submits another claim, the ROE is corrected at that time. 

## Policy reference

Source topic: `en_EN/task/voluntary_leaving_other_employment_l1/policy_reference.dita`

- Digest 6 — Voluntarily leaving employment
         [Digest 6 — Voluntarily leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html) 
