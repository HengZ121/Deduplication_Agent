# Adjudicating an Integrity case — Income review on EI ERB claims

Source map: `en_EN/task/adj-ic-ir-eierb/adj-ic-ir-eierb.ditamap`

## Summary

Source topic: `en_EN/task/adj-ic-ir-eierb/summary.dita`

Summary : Integrity investigators inform the Level 2 adjudication team when clients received monies from employment during the period they received the EI Emergency Response Benefit (EI ERB). 

## What you need to know

Source topic: `en_EN/task/adj-ic-ir-eierb/what_you_need_to_know.dita`

### Processing an Integrity Claim Review (CR) WI

Source topic: `en_EN/task/adj-ic-ir-eierb/processing_an_integrity_claim_review_cr_wi.dita`

The officer determines if the client is eligible for the EI ERB, completes the record of decision (ROD) and implements the decision using the following chart: 

### EI Emergency Response Benefit (EI ERB)

Source topic: `en_EN/task/adj-ic-ir-eierb/ei_emergency_response_benefit_ei_erb.dita`

The Government of Canada introduced the EI ERB on March 24, 2020 to provide temporary income support to workers who are without employment or SE income due to the COVID-19 pandemic.

The EI ERB was payable to clients requesting regular or sickness benefits between March 15, 2020 (w/c 2230) and September 20, 2020 (w/c 2257). The week of September 27, 2020 (w/c 2258) could have been payable as EI ERB, but only if the client received the EI ERB in a prior week. 

### Reconsidering a decision

Source topic: `en_EN/task/adj-ic-ir-eierb/reconsidering_a_decision.dita`

EIA 52 states that a claim for benefits may be reconsidered as long as it results in an overpayment (OP) or an underpayment (UP). The time limit for reconsidering a claim is 36 months from the week where benefits were paid or payable. This period is extended to 72 months if there is a false or misleading statement.
       [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

There are 4 distinct actions that must be completed within the 36 or 72-month periods. If any of the 4 actions cannot be completed within these timeframes, the officer cannot reconsider the claim. These 4 actions are:

- deciding whether or not to reconsider the claim (i.e. if the information presented justifies a reconsideration, reconsideration will result in an OP or UP or there is enough time to complete the work);

- rendering the new decision;

- calculating the OP;

- notifying the client of the decision.

The officer reviews the 2-week periods with a false statement that result in an OP. 

### False statements

Source topic: `en_EN/task/adj-ic-ir-eierb/false_statements.dita`

A false statement is a statement that is incorrect or untrue . It can be the result of an intentional or negligent action, or it can be the result of an honest mistake. The officer only considers whether there is a false statement in the 2-week period being reviewed, even if the officer is reviewing a 4-week period to determine if the client’s income exceeds $1 000.

For the purposes of this review, Integrity considers that a false statement has been made when the client under-declared income by $200 or more during the 2-week period being reviewed.

For example, a client declares $100 in income, but it is later determined that the client actually earned $330. Because the amount declared and the actual amount are different and the client under declared the income by more than $200, a false statement was made. 

### Reconsideration timeframe

Source topic: `en_EN/task/adj-ic-ir-eierb/reconsideration_timeframe.dita`

When determining whether conditions have been met to extend the reconsideration time limit to 72 months, officers review each 2-week period separately. It is possible that officers determine they can extend the reconsideration time limit for one 2-week period but not for another.

Clients may have received the EI ERB even after reporting income. When an investigation confirms that the eligibility criteria for EI ERB is not met, the officer creates the appropriate OP, provided the reconsideration is completed within the appropriate timeframe. 

### Responsibilities of the officer from the Level 2 adjudication team

Source topic: `en_EN/task/adj-ic-ir-eierb/responsibilities_of_the_officer_from_th_9210ee53.dita`

When the Integrity officer is unable to render a decision (e.g. the employer or client disagree on the type of income, or the income is outside of the Integrity Services Branch delegation), the officer from the Level 2 Integrity adjudication team takes the necessary actions to render a decision on the income issue. 

### Determining if monies are income

Source topic: `en_EN/task/adj-ic-ir-eierb/determining_if_monies_are_income.dita`

Monies are considered income if both of the following conditions are met:

- The monies arise from employment.

- The monies were earned during the period for which the EI ERB is paid.

Separation monies and monies paid for work that took place before or after the period for which the EI ERB is paid are not considered income.

In order to review the client’s eligibility for the EI ERB paid, the officer conducts a fact-finding about the nature, origin and purpose of the monies received. The officer considers the following factors:

- Does the payment arise out of employment?

- When were the monies earned? Is it during the EI ERB period or during an earlier or later period of work?

- Who is making the payment? Is it someone other than the employer?

- What is the reason for the payment?

For more information on monies considered income on an EI ERB claim, the officer refers to the EI Emergency Response Benefit Digest 3.7 — Income from Employment or Self-Employment .
       [3.7 — Income from Employment or Self-Employment](/en/policy/generic/ei_erb_digest.shtml#ch_3_7) 

### Determining eligibility to EI ERB when income is present

Source topic: `en_EN/task/adj-ic-ir-eierb/determining_eligibility_to_ei_erb_when__6a4a5388.dita`

Clients initially received the full amount of the EI ERB even if they reported income . However, clients were not paid if they reported a full work week (FWW) or finding full-time employment on a Sunday or Monday, which resulted in a found work code being imposed.

When reviewing income on an EI ERB claim, the officer reviews the 2-week periods separately starting from the first week that the EI ERB was paid. The officer confirms that the eligibility requirements have been met under EIA 153.9 (1)(a)(iv) and (v) that is the client stopped working and had no income for at least 7 consecutive days in the 2-week period being reviewed. If the client has not had a period of 7 consecutive days of no work and no income, the officer applies EIA 153. 9(4) to determine if the income exceeds $1 000 over a 4-week period.
       [EIA 153.9 (1)(a)(iv) and (v)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1242533) 
       [EIA 153. 9(4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#1244385)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1648.dita) 

### Determining if income exceeds $1 000 over a 4-week period

Source topic: `en_EN/task/adj-ic-ir-eierb/determining_if_income_exceeds_1_000_ove_92f27edf.dita`

When the client has not had at least 7 consecutive days of no work and no income in a 2-week period, the officer determines whether income exceeds $1 000 over a 4-week period. To identify the 4-week period, the officer starts at the 2-week period under review and finds the closest preceding 2-week period in which the EI ERB was originally paid. For a 2-week period to have been originally paid, the client must have completed claimant’s reports and received payment. The officer adds the income over the 4-week period being reviewed. If the total income in those 4 weeks exceed $1 000, the officer imposes a 47 - EI ERB – Earnings limit exceeded for the four week period disentitlement (D47) only for the 2-week period being reviewed. If it is $1 000 or less in this period, the officer does not impose a D47 and the officer repeats the process for the next 2-week period to be reviewed in which the EI ERB was paid.

If there are no previous weeks in which the EI ERB was paid (the first 2 weeks are the start of the EI ERB claim), the officer only considers the income in the 2-week period being reviewed to determine if the income exceeds $1 000.

For examples of how to count 4-week periods, the officer refers to EI Emergency Response Benefit Digest .
       [EI Emergency Response Benefit Digest](/en/policy/generic/ei_erb_digest.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1649.dita) 
     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1650.dita) 

Once it is has been determined that a client received income while receiving the EI ERB, the Integrity investigator completes the EI ERB CT 18 Tool and saves it in the Integrity investigation Document Upload System. The officer reviews the document to confirm that the information is accurate.
       [EI ERB CT 18 Tool](https://014gc.sharepoint.com/sites/94714/_layouts/download.aspx?SourceUrl=https://014gc.sharepoint.com/sites/94714/ortorl/EIOPP-Tool-CT18D47Earnings-E.xlsx)

Weeks for which a 65 - Lump Sum Payment ($2000) - Canadian Emergency Response code (D65) is imposed are considered weeks paid for calculating the 4-week period purposes. 

### Determining eligibility when there is a full work week (FWW) or found work code

Source topic: `en_EN/task/adj-ic-ir-eierb/determining_eligibility_when_there_is_a_a2ba435f.dita`

Weeks in which payment was prevented because of an FWW or found work code are not included in the 4-week period and the earnings are not considered when determining if the income exceeds $1 000.

If the review of the income will result in an OP, the officer can use originally declared and previously unpaid weeks with an FWW or found work code to reduce the OP. The officer first determines if the client was eligible for the EI ERB paid for a 2-week period with an FWW or found work code. If both weeks in the 2-week period were not paid due to an FWW or found work code, the client is not eligible for any benefits paid for that 2-week period and these weeks are not included when counting the 4-week period.

If only one of the weeks has an FWW or found work code, the officer determines if the client was eligible in that 2-week period under EIA 153.9(1) and 153.9(4). If the client’s eligibility is proven, the officer applies the week with an FWW or found work code to the OP.

The officer uses only the amount needed to reduce the OP and never issues payment of EI ERB weeks, even when it is determined a week is payable.

     [Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1651.dita) 

### Impact of EI ERB repayments

Source topic: `en_EN/task/adj-ic-ir-eierb/impact_of_ei_erb_repayments.dita`

There may be situations where clients made a repayment of EI ERB after realizing they were not eligible, but the repayment does not yet show in the system. Prior repayments of EI ERB have no impact on this review of income. When the EI ERB eligibility criteria are not met, the officer creates an OP. 

### Reviewing the file in NIIS

Source topic: `en_EN/task/adj-ic-ir-eierb/reviewing_the_file_in_niis.dita`

In NIIS, officers review the income information that the Integrity investigator gathered. Officers access the Report of Investigation (IC70) screen to review the Recommendation tab and the Investigation Information Sheet (IC71) screen.

From the IC71 screen, officers access the Findings tab to view the checklist that was completed with the client or employer during fact-finding, if necessary. Officers view the Recommendation tab to determine the Integrity investigator’s recommendation.

If the client or the employer submits documents related to the case, it is noted in the Recommendation tab and officers review the documents in the Integrity Investigation Document Upload System or Imaging. 

### Documenting the decision

Source topic: `en_EN/task/adj-ic-ir-eierb/documenting_the_decision.dita`

The officer documents the decision on a ROD in NWS. The officer includes all the reviewed periods and their results. 

### Returning a file to Integrity

Source topic: `en_EN/task/adj-ic-ir-eierb/returning_a_file_to_integrity.dita`

If the officer determines that facts are missing, the officer returns the file to the investigator for further fact-finding and indicates the missing information that is necessary to determine the client’s EI ERB eligibility. Facts are not considered missing or incomplete if the client did not respond to Integrity’s attempts to fact-find.

The officer also returns the file to Integrity when a 31 - EI ERB entitlement conditions not met disentitlement (D31) was previously imposed and it covers the period being reviewed for income. 

### Note

Source topic: `en_EN/common_notes/note_c_1648.dita`

Note:

The 7 consecutive days being reviewed for the purposes of EIA 153.9 (1) include any days within the 2-week claim period. 

### Note

Source topic: `en_EN/common_notes/note_c_1649.dita`

Note:

To determine the 4-week period on a renewal claim, begin with the first 2 weeks that EI ERB was paid on or after the renewal week and, if necessary, include the closest previous 2-weeks in which the EI ERB was originally paid. 

### Example

Source topic: `en_EN/common_notes/note_c_1650.dita`

Example:

The EI ERB was paid from w/c 2230 to w/c 2238 and the claim was renewed and paid as of w/c 2245. There are earnings in w/cs 2245 and 2246. The 4-week period is during w/cs 2246, 2245, 2238 and 2237. 

### Example

Source topic: `en_EN/common_notes/note_c_1651.dita`

Example:

A D47 applies to 4 weeks of EI ERB benefits received, resulting in a $2 000 OP. The client previously declared 6 FWW’s that prevented payment during the original period the EI ERB was received. The officer determines that eligibility has been proven for each 2-week period that contains an FWW. Although eligibility is proven for 6 FWWs, the officer instructs IPOC to reduce the OP using 4 of the originally declared FWWs. 

## Regional considerations

Source topic: `en_EN/task/adj-ic-ir-eierb/regional_considerations.dita`

**Quebec — Returning the file to Integrity**

In addition to the information already indicated in this procedure, the officer returns the file to Integrity by:

- sending an email explaining the situation to the investigator, ensuring to:

- request a delivery receipt;

- add the GD mailbox address QC-DGSI-ISB-RETOUR-RETURN-GD in the CC field.

- creating a client Note in NWS and typing “Measure — returned to Integrity on [DD-MM-YYYY].” 

## What you need to look for

Source topic: `en_EN/task/adj-ic-ir-eierb/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/adj-ic-ir-eierb/in_nws.dita`

- Is there relevant information to the case in SROCs, ROD, Action Item (AI) WIs and Call Back (CB) WIs? 

### In NIIS:

Source topic: `en_EN/task/adj-ic-ir-eierb/in_niis.dita`

- What is the recommendation of the investigator on the Recommendation tab of the IC70 Report of Investigation screen ? 

### In FTS:

Source topic: `en_EN/task/adj-ic-ir-eierb/in_fts.dita`

- What is the original claimant’s report information?

- Is there a renewal claim?

- Are there any inputs that might impact the investigation on the Transaction History screen?

- Is there a FWW code 1 - Full work week - week 1 , 2 - Full work week - week 2 or 3 - Full work week both weeks in any of the claimant’s reports under investigation? 

### In Imaging:

Source topic: `en_EN/task/adj-ic-ir-eierb/in_imaging.dita`

- Are there any documents related to the case? 

### In the Integrity Investigation Document Upload System:

Source topic: `en_EN/task/adj-ic-ir-eierb/in_the_integrity_investigation_document_2f4ba789.dita`

- Are there any documents related to the case? 

### In ACS:

Source topic: `en_EN/task/adj-ic-ir-eierb/in_acs.dita`

- Did Integrity send a letter to the client? 

## Step by step

Source topic: `en_EN/task/adj-ic-ir-eierb/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/adj-ic-ir-eierb/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj-ic-ir-eierb/reviewing_the_file_level_2.dita`

- In NIIS, determine if the investigator indicated that the client did not respond to the request for information:

- If yes, go to step 2.

- If no, go to step 3.

- In the Integrity investigation Document Upload System or Imaging, determine if the client responded to the fact-finding (C-74-01-10) letter after the case was sent for adjudication:

- If no, go to step 3.

- If yes, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj-ic-ir-eierb#rfi)

- Determine if Integrity has provided enough information to render a decision on the income issue:

- If yes, go to step 4.

- If no, go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj-ic-ir-eierb#rfi)

- Determine if the income being reviewed is for the same period as the one in which a D31 was imposed:

- If no, go to step 5.

- If yes, a review of the income is not required. Go to Returning the file to Integrity .
               [Returning the file to Integrity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj-ic-ir-eierb#rfi)

- Determine if the monies are considered income. Refer to EI Emergency Response Benefit — BE 2020-04 – Updated and EI Emergency Response Benefit Digest 3.7 for more information:

- If no, go to step 6.

- If yes, determine the period for which the monies were earned and go to step 7.

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — monies are not income — D47 does not apply.”

- Details: Type “The case involves [type of monies]. The monies are not considered income for EI Emergency Response Benefit purposes.” Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to No disentitlement .
               [No disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj-ic-ir-eierb#nod)

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — income [type of monies].”

- Details: Type “The case involves [type of monies]. The monies paid or payable are income for EI Emergency Response Benefit purposes.” Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In Integrity investigation Document Upload System, open the completed EI ERB CT18 Tool to confirm the information input by the investigator and go to step 9.

- Review all 2-week periods and determine if there are any that have a false statement:

- If yes, go to step 10.

- If no, go to Not within the reconsideration period .
               [Not within the reconsideration period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj-ic-ir-eierb#level2_item_2)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1652.dita)

- Determine the 2-week period with a false statement to be reviewed.

- Determine if there is at least 7 consecutive days with no work and no earnings in the 2-week period being reviewed:

- If no, go to step 12.

- If yes, a D47 does not apply to this 2-week period. Go to step 14.

- Determine the closest previous  2 weeks in which the EI ERB was originally paid. Exclude weeks reported in which payment was prevented because of a FWW or found work code.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1653.dita)

- Determine if earnings exceed $1 000:

- If yes, note that a D47 must be imposed for the 2-week period being reviewed. Go to step 14.

- If no, do not impose a D47 for the 2-week period being reviewed. Go to step 14.

- Determine if all 2-week periods have been reviewed:

- If no, return to step 10.

- If yes, go to step 15.

- Determine if a D47 applies to any 2-week periods identified in step 10:

- If no, go to step 16.

- If yes, go to step 17.

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — income reviewed — D47 does not apply.”

- Details: Enter the appropriate details depending on the case and document the decision and rationale according to the National Fact-Finding and Documentation Policy . Add the following details, if necessary:

- the 2-week periods in which a D47 is not imposed because the weeks are not in the 36-month period;

- the 2-week periods in which a D47 is not imposed because the weeks are not in the 72-month period;

- the 2-week periods in which a D47 is not imposed because the income does not exceed $1 000 over the 4-week period.

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to No disentitlement .
               [No disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj-ic-ir-eierb#nod)

- Determine if, during the period reviewed, there was one week with an FWW or found work code that was reported on the original claimant’s reports that prevented payment:

- If yes, go to step 18.

- If no, go to step 19.

- Determine if the client’s eligibility was proven for the 2-week period with thean FWW or found work code:

- If yes, the week in which payment was prevented due to an FWW or found work code will be applied to the OP. Note the week in question for the Operational Centre Memo (MM06) transaction and go to step 19.

- If no, go to step 19.

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — income review — D47 applies.”

- Details: Enter the appropriate details depending on the case and document the decision and rationale according to the National Fact-Finding and Documentation Policy . Add the following details, if necessary:

- the 2-week periods in which a D47 is not imposed because the weeks are not in the 36-month period;

- the 2-week periods in which a D47 is not imposed because the weeks are not in the 72-month period;

- the details of false statements and whether the reconsideration timeframe was extended to 72 months;

- the 2-week periods in which a D47 is not imposed because the income does not exceed $1 000 over the 4-week period;

- the 2-week periods in which a D47 is imposed because the income exceeds $1 000 over the 4-week period;

- the 2-week periods in which the D47 is modified and the reason;

- the 2-week periods in which the D47 is rescinded and the reason.

- the weeks with an FWW or found work code that prevented payment and must now be applied as an UP to the OP.

               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Go to Implementing a decision — Income review on EI ERB claims to input the decision. 

#### Not within reconsideration timeframe

Source topic: `en_EN/task/adj-ic-ir-eierb/not_within_reconsideration_timeframe_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Integrity case number] — EI Emergency Response Benefit — not within reconsideration timeframe.”

- Details: Document the decision and rationale according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In FTS, select the Renewal/Revised (M106) transaction and clear the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- In NIIS, on the Report for Investigation (IC70) screen, select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type “Not within reconsideration timeframe, no decision on EI ERB.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In NWS, complete the CR Integrity - ERB reason for separation WI. 

#### No disentitlement

Source topic: `en_EN/task/adj-ic-ir-eierb/no_disentitlement_level_2.dita`

- In NIIS, on the IC70 Report for Investigation screen, select the Decision tab and complete the following fields:

- Disentitlement: Select No .

- Reason: Select Other and type the appropriate option:

- “EI ERB — [type of monies] [is or are] not considered earnings.”

- “EI ERB — income does not exceed $1 000 over a 4-week period.”

- Penalty: Select No .

- Warning: Select No .

- Violation: Select No .

- Select OK .

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In ACS, create and send the C-71-05-01 letter. Select the most appropriate option for each of the following attributes:

- Earnings / insurable hours of work / income while on claim (12577)

- Blank / free form (3311) : Select Blank .

- In NWS, complete the CR Integrity - ERB reason for separation WI. 

#### Returning the file to Integrity

Source topic: `en_EN/task/adj-ic-ir-eierb/returning_the_file_to_integrity_level_2.dita`

- In NIIS, on the Document tab, select the Report of Investigation (IC70) or Report of Clerical Investigation (IC50) screen and do the following:

- Select Recommendation .

- Return the file to Integrity as follows, depending on the case:

- IC70 Report of Investigation

- Return the case to Integrity Operations: Select Yes .

- IC50 Report of Clerical Investigation

- Return the case to Integrity Operations: Check the box .

- Enter the missing or additional information required in the text area.

- Select OK .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1654.dita)

- In FTS, select the Outstanding Registrations link to cancel the registration number as follows:

- Select Modify .

- In the appropriate registration section, do the following:

- Action: Select Cancel .

- Select Update .

- In NWS, complete the CR Integrity - ERB reason for separation WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1652.dita`

Note:

To determine the correct 2-week periods, count in sequence from the first week of the EI ERB claim (BPC showing in FTS). If there is a renewal, the 2-week period restarts from the week of renewal. 

#### Note

Source topic: `en_EN/common_notes/note_c_1653.dita`

Note:

If there are no preceding weeks in which the EI ERB was paid, consider the earnings only in the 2-week period being reviewed to determine if the earnings exceed $1 000. 

#### Note

Source topic: `en_EN/common_notes/note_c_1654.dita`

Note:

In the Quebec region, return the file to Integrity as follows:

- Send an email explaining the situation to the investigator:

- Request a delivery receipt.

- Enter the GD mailbox address qc-dgsi-isb-retour@servicecanada.gc.ca in the Cc field.
             [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca)

- In NWS, create a client Note and type “Measure — returned to Integrity — [DD-MM-YYYY].”

     [qc-dgsi-isb-retour@servicecanada.gc.ca](mailto:qc-dgsi-isb-retour@servicecanada.gc.ca) 

## Policy reference

Source topic: `en_EN/task/adj-ic-ir-eierb/policy_reference.dita`

- EIA 153.9 (4)
         [EIA 153.9 (4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

- EI Emergency Response Benefit — BE 2020-04 - Updated
         [EI Emergency Response Benefit — BE 2020-04 - Updated](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2020-04.shtml)

- EI Emergency Response Benefit Digest
         [EI Emergency Response Benefit Digest](https://ort-orl.esdc-edsc.canada.ca/en/policy/generic/ei_erb_digest.shtml) 
