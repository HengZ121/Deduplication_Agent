# Adjudicating voluntary leaving (Level 1): Referred training or employment activity — Renewal

Source map: `en_EN/task/vllevel1_coi_renewal/vllevel1_coi_renewal.ditamap`

## Summary

Source topic: `en_EN/task/vllevel1_coi_renewal/summary.dita`

Summary: When clients voluntarily leave employment to attend a referred training or an employment activity, their entitlement to regular benefits on a renewal claim may be affected. Adjudication is required to determine if there is just cause for leaving the employment. 

## What you need to know

Source topic: `en_EN/task/vllevel1_coi_renewal/what_you_need_to_know.dita`

### Adjudicating voluntary leaving to attend referred training or an employment activity

Source topic: `en_EN/task/vllevel1_coi_renewal/adjudicating_voluntary_leaving_to_atten_8b0bb5f9.dita`

When clients voluntarily leave their employment, the officer must determine if they had just cause for leaving. Just cause means that when all factors are considered, the client had no reasonable alternative but to leave the employment. If it is determined that the client left the employment without just cause, a disqualification is imposed on the claim for regular benefits, unless there are enough insurable hours since the voluntary leaving to establish a new claim. In this case, the ROE with the voluntary leaving is excluded from the calculation of the claim.

A designated authority may authorize clients to leave their employment in order to attend referred training or an employment activity under EIA 25 . In that situation, clients have just cause for leaving their employment, provided they do so in the 2 weeks before the start of the program.
       [EIA 25](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

To confirm that the client has been authorized to leave the employment, the designated authority gives the client an official document sometimes referred to as an authorization to quit or a counsel to leave employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4923.dita) 

An ROE is not required to adjudicate a voluntary leaving. 

### Authorization to quit employment

Source topic: `en_EN/task/vllevel1_coi_renewal/authorization_to_quit_employment.dita`

Each region has specific procedures in place for submitting the document authorizing the client to quit their employment. In some regions, the client is responsible for submitting a copy to Service Canada. In other regions, the designated authority submits it directly to Service Canada.

When the information is not on file, the officer fact-finds to complete the WI related to the voluntary leaving. When clients state that they have been authorized to quit, but a copy of the authorization is not on file, the officer advises the clients to ask the designated authority to provide it. If the authorization is not submit, the officer adjudicates the voluntary leaving based on the information on file.

Agreements with the provinces, territories and indigenous groups exist for implementing programs which are similar to Service Canada’s employment programs. These include:

- Labour Market Development Agreements for training-related employment measures managed by the provinces and territories.

- Indigenous Skills and Employment Training Program for training-related employment measures managed by various indigenous groups for indigenous individuals.

Sometimes an unemployed client is referred to training that starts at a future date and the client becomes employed before the training begins. If the client leaves this employment to attend the training, the issue must be referred to Level 2 since the voluntary leaving has not been recommended or approved by the designated authority.

In NWS, there may be a “New ROE” message displayed on the Adjudication Issue (ADJ) WI for the voluntary leaving issue. The message indicates that a new ROE has been received with a reason for separation (RFS) that must be reviewed. The ROE may match the period of employment for that ADJ WI or for another outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4936.dita) 

### Automated adjudication

Source topic: `en_EN/task/vllevel1_coi_renewal/automated_adjudication.dita`

ACP does not automate a decision for voluntary leaving to attend referred training or an employment activity. 

### Levels of decision

Source topic: `en_EN/task/vllevel1_coi_renewal/levels_of_decision.dita`

The Level 1 officer may adjudicate and allow benefits when the client’s reason for voluntarily leaving employment is to attend referred training or an employment activity and all of the following conditions are met:

- The client was referred by an authority designated by the Commission prior to the voluntary leave.

- The voluntary leave was approved by the designated authority.

- The referred training or employment activity started within 2 weeks of the date of the voluntary leave.

- The BPC or renewal week is equal to or after the week of voluntary leaving.

When the Level 1 officer cannot adjudicate the issue, the facts are documented and the voluntary leaving is referred to Level 2 for adjudication. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/vllevel1_coi_renewal/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the RFS was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Previously deferred decision

Source topic: `en_EN/task/vllevel1_coi_renewal/previously_deferred_decision.dita`

When converting or renewing a claim, any deferred RFS must be adjudicated.

If adjudication of the RFS is deferred, a disqualification is input in FTS when special benefits are allowed. Officers must always verify if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a 11 - Voluntary leaving - just cause not proven (D11) disqualification is on file, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer must rescind the D11 that is on file and update the Special Condition field on the ROE in RCM. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/vllevel1_coi_renewal/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the voluntary leaving is not required if the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, an authorized user must delete the ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4925.dita) 

### Claim action status and processing the claim

Source topic: `en_EN/task/vllevel1_coi_renewal/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All ADJ WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Voluntary leaving WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a record of decision (ROD) based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the stop payment (MA02). No letter is sent when the client is allowed to voluntarily leave an employment to follow another individual.

In some cases, the ADJ WI may be for a voluntary leaving issue that was previously adjudicated. The officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the applicable special condition based on the previous decision. 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/vllevel1_coi_renewal/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

The officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0092.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_4923.dita`

Note:

In exceptional cases, a Level 2 officer can consider a longer period of up to 4 weeks as just cause if the client provides a reasonable and credible explanation for leaving employment early (e.g. relocating to attend school). 

### Note

Source topic: `en_EN/common_notes/note_c_4936.dita`

Note:

The client may report voluntary leaving on the application for benefits but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_4925.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the voluntary leaving is required when the employment is not insurable due to a non-arm’s length issue. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0092.dita`

Note:

Any contentious RFS issues in the benefit period (BP) must be adjudicated. 

## Regional considerations

Source topic: `en_EN/task/vllevel1_coi_renewal/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/vllevel1_coi_renewal/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/vllevel1_coi_renewal/in_nws.dita`

- Is there a ROD for the voluntary leaving on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Voluntary Leave section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing checklists or other details relating to the voluntary leaving on this or a previous EI application? 

### In Imaging:

Source topic: `en_EN/task/vllevel1_coi_renewal/in_imaging.dita`

- Are there any imaged documents relating to the voluntary leaving? 

### In RCM:

Source topic: `en_EN/task/vllevel1_coi_renewal/in_rcm.dita`

- Is there an ROE for the voluntary leaving?

- If yes, what is the RFS indicated?

- Are there any comments related to the voluntary leaving? 

## Step by step

Source topic: `en_EN/task/vllevel1_coi_renewal/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/vllevel1_coi_renewal/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/vllevel1_coi_renewal/reviewing_the_file_level_1.dita`

- Determine if there is a ROD for the voluntary leaving issue on file:

- If there is no ROD for the voluntary leaving issue, go to step 2.

- If there is a ROD for the voluntary leaving issue, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#DecisionOnFile)

- Determine if the client is correcting previously provided information or providing previously omitted information and the information may impact the client’s entitlement to benefits previously paid:

- If no, go to step 3.

- If yes, determine if the issue must be referred to Integrity by referring Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if adjudication can be deferred by consulting the Deferring adjudication procedure.

- Determine if the facts on file clearly indicate that the employment is not insurable either because the client is working under a contract for service (self-employed) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 5.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information to adjudicate the voluntary leaving, or if additional fact-finding is required.

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4937.dita) 

- If all the required information is not on file, go to step 6.

- If all the required information is on file, go to step 13.

- If the information on file shows that the client was not referred, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#reassigntol2) 

#### Fact-finding

Source topic: `en_EN/task/vllevel1_coi_renewal/fact-finding_level_1.dita`

- Fact-find with the client to obtain the required information.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4938.dita)

- Determine if the client was reached during fact-finding, or if the client responded to the N-10-00-00 ACS letter:

- If the client was reached , go to step 8.

- If the client was not reached or did not reply to the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#reassigntol2)

- In NWS, add details to the draft SROC created during fact-finding or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — client.”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- Determine if the client was reminded during fact-finding to submit the missing document that provides the authorization to quit employment:

- If yes, go to step 10.

- If no, go to step 12.

- In NWS, move the WI related to the missing document that provides the authorization to quit employment to Pending as follows:

- Pending reason: Select Fact finding client .

- Bring forward date: Enter the date of the most recent contact + 10 business days.

- When the WI moves to the current workload, determine if the document that provides the authorization to quit employment is on file:

- If yes, go to step 12.

- If no, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#reassigntol2)

- Determine if the information on file shows that a designated authority authorized the client to quit the employment to participate in an employment activity:

- If yes, go to step 12.

- If no, go to Reassigning the issue to Level 2
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#reassigntol2) 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/vllevel1_coi_renewal/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine if the RFS is contentious:

- If the RFS is voluntary leaving, go to step 14.

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS) .
               [Non-contentious reason for separation (RFS)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#RFSVL)

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if all the following conditions are met to adjudicate the issue at Level 1:

[Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_4939.dita) 

- If all the conditions are met, go to Reason for separation (RFS) allowed .
               [Reason for separation (RFS) allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#RFSallowed)

- If all the conditions are not met, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/vllevel1_coi_renewal#reassigntol2) 

#### Reason for separation (RFS) allowed

Source topic: `en_EN/task/vllevel1_coi_renewal/reason_for_separation_rfs_allowed_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is voluntary leaving .

- Select Continue .

- Complete the Voluntary leaving screen as follows:

- Select To attend a course of instruction .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In FTS, determine if there is a D11 on file because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D11 is solely due to this previously deferred RFS issue and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 6.

- If other issues must be adjudicated, refer to the appropriate task for guidance. Then, go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F – Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In RCM, determine if the ROE is on file :

- If no, go to step 8.

- If yes, in RCM, update the Special condition field and go to step 8.

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/vllevel1_coi_renewal/employment_is_not_insurable_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Voluntary leaving — [employer’s name] — [last day worked] — Adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed). Adjudication of the voluntary leaving is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the voluntary leaving is therefore not required.”

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/vllevel1_coi_renewal/non-contentious_reason_for_separation_rfs_level_1.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 1 Voluntary leaving screen as follows:

- Select The reason for separation is not voluntary leaving .

- Select Continue .

- Complete the Not voluntary leaving screen as follows:

- Select the appropriate RFS.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if a ROE is on file:

- If yes, go to step 5.

- If no, go to step 7.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment: Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error and go to step 7.

- If no, go to step 7.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/vllevel1_coi_renewal/decision_already_on_file_level_1.dita`

- Determine if the applicable decision is listed:

- If yes, on the list, select the applicable ROD and select Save . Go to step 5.

- If no, select Decision not in the list .

- Select the applicable special condition based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/vllevel1_coi_renewal/reassigning_the_issue_to_level_2_level_1.dita`

- In NWS, reassign the ADJ WI to Level 2 as follows:

- Destination: Select Next available user .

- Complexity: Select Level 2 .

- Reason: Select Unable to complete .

- Details: Type “Client quit [his/her] job and [provide a brief reason for the referral, e.g. not a referred course] — unable to complete at Level 1.”

- Select OK .

- When the Warning window is displayed, select OK . 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4937.dita`

Required information:

- start and end dates of the referred training or employment activity

- client’s statement about the reason for leaving the employment to attend training

- name of the referred training or employment activity

- name of the institution or school and the location

- name and contact information of the training counselor

- document completed by a designated authority that provides authorization to quit employment 

#### Note

Source topic: `en_EN/common_notes/note_c_4938.dita`

Note:

If the clients state that they were referred by a designated authority but the document that provides the authorization to quit employment is not on file, advise them to submit it as soon as possible. 

#### Callout

Source topic: `en_EN/common_notes/note_c_4939.dita`

Voluntary leaving to attend referred training or an employment activity — Conditions to adjudicate the issue at Level 1 (all conditions must be met)

- The client was referred to the training or employment activity by an authority designated by the Commission before the voluntary leave.

- The voluntary leave was approved by the designated authority.

- The referred training or employment activity started in the 2 weeks following the date of the voluntary leave.

- The BPC or renewal week is equal to or after the week of voluntary leaving. 

## Policy reference

Source topic: `en_EN/task/vllevel1_coi_renewal/policy_reference.dita`

- BE 2010-12—Voluntary Leaving to Attend Approved Training
         [BE 2010-12—Voluntary Leaving to Attend Approved Training](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2010-12.shtml)

- Digest 6—Voluntarily leaving employment
         [Digest 6—Voluntarily leaving employment](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/table-of-contents.html)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html) 
