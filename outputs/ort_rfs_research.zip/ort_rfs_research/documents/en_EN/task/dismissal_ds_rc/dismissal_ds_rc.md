# Adjudicating a dismissal or suspension — Renewal claim

Source map: `en_EN/task/dismissal_ds_rc/dismissal_ds_rc.ditamap`

## Summary

Source topic: `en_EN/task/dismissal_ds_rc/summary.dita`

Summary: Dismissal or suspension from employment may affect a client’s entitlement to regular benefits on a renewal claim. The officer must determine whether the client was dismissed or suspended because of misconduct. 

## What you need to know

Source topic: `en_EN/task/dismissal_ds_rc/what_you_need_to_know.dita`

### Defining misconduct

Source topic: `en_EN/task/dismissal_ds_rc/defining_misconduct.dita`

If there is an indication of misconduct, Level 2 must follow the Fact-finding procedure and render a decision.

We can define misconduct as:

- a wrongful act or breach of an obligation in the employment contract, committed voluntarily, deliberately, knowingly or of such a careless or negligent nature that it appears to have been committed deliberately;

- which has a negative effect on the continuation of the employer-employee relationship.

In this respect, Service Canada must:

- Offer the client and employer the possibility of providing information on the RFS.

- Take this information into account in its decision.

When there are contradictory statements, allow both parties to provide an explanation or clarification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3246.dita) 

### Client does not want employer to be contacted

Source topic: `en_EN/task/dismissal_ds_rc/client_does_not_want_employer_to_be_contacted.dita`

If the client does not want the employer to be contacted, officers must explain that they are legally required to fact-find with the employer. 

### Railway misconduct

Source topic: `en_EN/task/dismissal_ds_rc/railway_misconduct.dita`

In the interest of public safety, the rules governing railway employees in the course of their duties, particularly those in the operating groups, are very strict. Railway employees are subject to suspension or dismissal for causes which, in other industries, would not carry such severe penalties. When an employee from the railway sector (railway employee) is dismissed or suspended, the officer must request a copy of the hearing transcript issued by the disciplinary committee, as well as all of the other files containing evidence regarding the separation. 

### Mandatory retirement

Source topic: `en_EN/task/dismissal_ds_rc/mandatory_retirement.dita`

Human rights legislation in Canada prohibits mandatory retirement. Very few occupations are exempt from this legislation. Some employers may be able to demonstrate a genuine reason for mandatory retirement; however these cases are rare.

In cases of mandatory retirement, clients do not voluntarily leave their employment. The separation is initiated by the employer. Consequently, a Level 2 officer must adjudicate the RFS as a dismissal and determine whether clients lost their employment due to misconduct. Normally, in the case of mandatory retirement, the facts on file support a decision of misconduct not proven. Written notice to the employer that EI benefits have been allowed is not required as there is no allegation of misconduct. 

### Imposing a disqualification or disentitlement

Source topic: `en_EN/task/dismissal_ds_rc/imposing_a_disqualification_or_disentitlement.dita`

Once it is determined that the client was dismissed for misconduct, the officer determines whether an indefinite disqualification or disentitlement applies.

On a renewal claim if it is determined the client lost their employment due to misconduct, an indefinite disqualification is imposed on the claim for regular benefits, unless the client has worked enough insurable hours since this misconduct to establish a new claim. In that case, the system imposes a disqualification and when the renewal is processed the officer manually rescinds this disqualification.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3247.dita) 

**Example 1**

In this chart, a renewal has been made in w/c 2111 and a 10 - Dismissal - misconduct proven disqualification (D10) has been imposed at that time. The client requests a second renewal for w/c 2134. It is not possible to terminate the D10. A new claim must be established with a BPC of w/c 2134.

**Example 2**

In this chart, a renewal request is made in w/c 2134. No other renewal request has been made before and there is no disqualification on file. Since the client has accumulated enough hours since the dismissal with misconduct proven, the claim can be renewed in w/c 2134 and no disqualification will be imposed.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3248.dita) 

### Imposing a disqualification or disentitlement — BPCs between w/c 2310 and w/c 2361

Source topic: `en_EN/task/dismissal_ds_rc/imposing_a_disqualification_or_disentit_0170a30a.dita`

Once it is determined that the client was dismissed for misconduct, the officer determines whether an indefinite disqualification or disentitlement applies.

On a renewal claim, if the client lost the employment due to misconduct, the officer imposes an indefinite disqualification on the claim for regular benefits. However, if the client has worked since this misconduct and the RFS from that employment is not contentious or was adjudicated and allowed, the officer determines if the client has worked enough hours in insurable employment since the BPC to establish a new claim. If so, the claim may be terminated to establish a new initial claim using the hours of insurable employment that the client accumulated since the BPC.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3249.dita) 

**Example #1**

In this chart, a renewal application was filed in w/c 2327 and a 10 - Dismissal - misconduct proven disqualification (D10) was imposed at that time. The client applies for second renewal for w/c 2341 after being laid off in w/c 2340. It is not possible to terminate the D10. Since the client has worked sufficient hours since BPC 2310 was established and the last RFS is not contentious (layoff), the officer can terminate the claim and establish a new initial claim, effective w/c 2341. the officer uses all hours from ROE 1 and ROE 2 to calculate BPC 2341.

**Example #2**

In this chart, a renewal application was filed in w/c 2341. The dismissal on ROE 2 has to be adjudicated because it falls in the benefit period (BP). If the dismissal is allowed, the officer can renew the claim effective w/c 2341 and the client can receive any remaining entitlement on this claim. However, if adjudication results in a misconduct proven decision on ROE 2, the officer renews the claim with a disqualification. Since the client has accumulated 500 hours since BPC 2310 was established and the last RFS is not contentious, the client can request to terminate BPC 2310 and establish a new initial claim effective w/c 2341.

**Example #3**

In this chart, a renewal application was filed in w/c 2341. The dismissal on ROE 2 has to be adjudicated because it falls in the BP. The client has accumulated only 390 hours since BPC 2310 was established. If the dismissal is allowed, the officer renews the claim without a disqualification. If misconduct is proven, the officer renews the claim with a D10.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3250.dita) 

**Disentitled due to a suspension**

There may be situations where the employee is suspended from his duties for having acted in a way that resembles misconduct. The employer generally uses that suspension to review the evidence and determine if a disciplinary measure is sufficient or if a definitive dismissal is appropriate.

A client suspended because of misconduct is not entitled to benefits for each day of the suspension. The 42 - Suspension from employment disentitlement (D42) is imposed to indicate a suspension from work for proven misconduct.

A client can gain relief from a D42 if one of the following conditions is met:

- The period of suspension expires.

- The client loses or voluntarily leaves his or her employment.

- After the period of suspension begins, the client accumulates with another employer the number of hours of insured employment required to establish a new claim. 

### Dismissed or suspended within 3 weeks of anticipated layoff

Source topic: `en_EN/task/dismissal_ds_rc/dismissed_or_suspended_within_3_weeks_o_bebc42ee.dita`

If the client was dismissed within 3 weeks of an anticipated layoff or the end-of-term employment, the 44 - Loss of employment in anticipation of layoff disentitlement (D44) is imposed. The D44 is imposed for a definite period only (maximum 3 weeks).

If the client was dismissed more than 3 weeks before the anticipated layoff and in all other cases except suspension , the indefinite D10 disqualification is imposed.

**Effect of disqualification or disentitlement on special benefits**

The D10 disqualification and the D42 and D44 disentitlements are suspended when special benefits are claimed and otherwise payable.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3251.dita) 

### Automated adjudication

Source topic: `en_EN/task/dismissal_ds_rc/automated_adjudication.dita`

ACP does not automate a Level 2 decision for dismissal. 

### Previously deferred decision

Source topic: `en_EN/task/dismissal_ds_rc/previously_deferred_decision.dita`

When converting or renewing a claim, any RFS for which adjudication had previously been deferred must be adjudicated.

When the claim is calculated, if the RFS adjudication is deferred, a disqualification is automatically imposed and appears in FTS on the Disqualification/Disentitlement screen.

the officer always verifies if any contentious RFS was adjudicated by checking for a record of decision (ROD) in NWS. If the RFS was adjudicated and a D10 was imposed, no regular benefits are payable on this claim.

If the RFS is now allowed, the officer rescinds the D10 that is on file and updates the Special Condition field on the ROE in RCM to Misconduct not proven .

If the RFS is now not allowed, the officer updates the Special Condition field on the ROE in RCM to Misconduct proven . 

### Adjudication not previously required — Specialized ACP process

Source topic: `en_EN/task/dismissal_ds_rc/adjudication_not_previously_required__s_a89cd8c4.dita`

A new specialized process that streamlines the processing of initial applications was introduced on September 27, 2020. Claims processed in this specialized ACP process were established without adjudicating contentious RFS issues in the qualifying period (QP). The RFS issues that were not previously adjudicated can be identified because the Special condition field was left blank on the ROE but the ROE was still included in the initial calculation.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0091.dita) 

If a contentious RFS in the QP was not adjudicated on an initial claim for regular benefits as it went through the specialized ACP process, it does not need to be adjudicated on the renewal claim, as long as the client is still requesting regular benefits. However, there may be an outstanding ADJ WI.

If there is an outstanding ADJ WI for a contentious RFS in the QP, the officer does not adjudicate the issue. To remove the outstanding ADJ WI, the officer sends a request to an authorized user to delete it.

If there is both a CA Renewal WI and an outstanding ADJ WI for a contentious RFS in the QP, the Level 1 officer processes the CA Renewal WI even though the ADJ WI remains outstanding. The officer:

- determines the effective date of the renewal;

- inputs the renewal and completes the registration number;

- completes the CA Renewal WI.

the officer completes the CA Renewal WI before sending the request to an authorized user to delete the outstanding ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0126.dita) 

### Notifying the employer

Source topic: `en_EN/task/dismissal_ds_rc/notifying_the_employer.dita`

The employer must be notified in writing of the decision and provided with the right to request a reconsideration in cases where misconduct was not proven unless the employer advises that the client was dismissed for unsuitability. In that case, no misconduct is alleged and therefore no notification is required. 

### Claim action status and processing the claim

Source topic: `en_EN/task/dismissal_ds_rc/claim_action_status_and_processing_the_claim.dita`

When there is an outstanding adjudication issue on a renewal claim, the Claim action status is In Progress (Automation) . All Adjudication Issue (ADJ) WIs must be completed before the system can finalize the renewal. There is a Resolve Issue tab for ADJ Dismissal WIs which includes screens where the officer documents the decision. When the ADJ WI is completed, the system creates a ROD based on the Resolve Issue screens. When the renewal is finalized, the system generates the required transactions based on the Resolve Issue screens and removes the stop payment (MA02). If the dismissal or suspension is allowed and the employer must be notified, the system automates the Z-01-00-00 letter, or creates a Correspondence (COR) WI. If the dismissal or suspension is not allowed, the system creates a COR WI for the D-01-00-00 or N-00-00-00 letter.

A temporary Budget 2021 measure applies to claims with a BPC between September 26, 2021 (w/c 2310) and September 18, 2022 (w/c 2361). During this period, adjudication is required only if the RFS on the most recent ROE in the QP is contentious. In addition, the officer does not use the common entrance requirement (CER) of 420 hours of insurable employment to determine if the client requalifies after a disqualifying event. Instead, the client needs to have worked at least one hour in insurable employment since the disqualifying event and to have filed an EI application.

If the RFS since the disqualifying event on claims with a BPC between w/c 2310 and w/c 2361 is either non-contentious or is adjudicated and allowed, the officer can establish a new claim without a disqualification using the hours from all the ROEs in the QP.

If the dismissal or suspension is not allowed, the officer notifies the client of the decision verbally and in writing. When preparing the ACS letter, the officer chooses the attribute informing the client that the minimum number of hours is required to qualify for benefits, even when a new claim can be established. 

### Previously adjudicated dismissal

Source topic: `en_EN/task/dismissal_ds_rc/previously_adjudicated_dismissal.dita`

In some cases, the ADJ WI may be for a dismissal issue that was previously adjudicated. the officer indicates on the Resolve Issue tab of the ADJ WI that a decision is already on file. If the previous decision resulted in a ROD created by the system, the system creates a new ROD with the same information when the ADJ WI is completed. If the previous decision resulted in a ROD created manually, the officer indicates the appropriate special condition based on the previous decision. 

### Determining if the file must be referred to Integrity

Source topic: `en_EN/task/dismissal_ds_rc/determining_if_the_file_must_be_referre_f4ff817e.dita`

When a client comes forward to correct previously provided information or provide previously omitted information, the officer determines if the information can be considered an error correction, or if it must be referred to Integrity to be considered under the voluntary disclosure policy.

The voluntary disclosure policy may apply if the client is aware that misinformation resulted in an inappropriate payment of benefits and is attempting to correct this situation. Unless specified otherwise, it is presumed that in providing the information, the client is in agreement that benefits were not payable.

To determine if the new information can be considered an error correction or must be referred to Integrity, the officer refers to Determining if an issue must be referred to Integrity .
       [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

When the reason for separation (RFS) was undisclosed on a previous claim and a potential overpayment (OP) situation exists, the officer refers to Determining if an issue must be referred to Integrity to determine if the RFS must be referred to Integrity for investigation.
       [Determining if an issue must be referred to Integrity](https://ort-orl.esdc-edsc.canada.ca/en/procedure/task/determining_issue_referred_integrity.shtml) 

### Moving the Adjudication (ADJ) WI to Pending when the reason for separation (RFS) is referred to Integrity

Source topic: `en_EN/task/dismissal_ds_rc/moving_the_adjudication_adj_wi_to_pendi_b3f8fede.dita`

When the RFS is referred to Integrity, the officer moves the ADJ WI to Pending until the investigation is complete and the case is adjudicated. When the ROD for the Integrity case is created, the ADJ WI for the RFS moves to the officer’s current workload. the officer then completes the ADJ WI by selecting the Decision already on file option. 

### Processing the Adjudication (ADJ) WI when the employment is not insurable

Source topic: `en_EN/task/dismissal_ds_rc/processing_the_adjudication_adj_wi_when_400f350b.dita`

Adjudication of the dismissal or suspension is not required if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares. If the facts on file clearly indicate that the employment is not insurable for one of these reasons, an authorized user must delete the ADJ WI.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3240.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_3246.dita`

Note:

For information regarding RFS issues resulting from a client not complying with the employer’s COVID-19 vaccination policy, the officer refers to the EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo) .
       [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml)

     [EI Eligibility and refusal to comply with a mandatory vaccination policy — BE 2021-10 (BE Memo)](/en/policy/bememo/be2021-10.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_3247.dita`

Note:

If the claim’s BPC is w/c 2309 or earlier or the BPC is w/c 2362 or later, the only disqualification that can be rescinded is the D10 that the system imposed on the renewal. 

### Note

Source topic: `en_EN/common_notes/note_c_3248.dita`

Note:

ROEs for employment after the event must be on file in order to determine if the client has enough hours since the misconduct to establish a new claim in order to gain relief from the disqualification. If the ROEs are not on file, the claim is renewed with a disqualification and the onus is on the client to provide evidence of sufficient hours since the event to either rescind the disqualification or establish a new claim. 

### Note

Source topic: `en_EN/common_notes/note_c_3249.dita`

Note:

When assessing whether to establish a new claim, officers keep in mind that the Budget 2021 temporary measures do not apply to new claims with a BPC of w/c 2362 or later. 

### Note

Source topic: `en_EN/common_notes/note_c_3250.dita`

Note:

ROEs for employment after the BPC must be on file in order to determine if the client has enough hours since the BPC to establish a new claim. If the ROEs are not on file, the officer renews the claim with a disqualification and the onus is on the client to provide evidence of sufficient hours since the BPC to establish a new claim. 

### Note

Source topic: `en_EN/common_notes/note_c_3251.dita`

Note:

The client may report dismissal on the application for benefits but the ROE indicates a non-contentious RFS. In this situation, fact-finding is required. If it is determined that the client’s RFS is not contentious (e.g. shortage of work, sickness), the WI is completed indicating the correct non-contentious RFS. 

### Note

Source topic: `en_EN/common_notes/note_c_0091.dita`

Note:

The ACP specialized process ends on August 16, 2021. As of that date, ACP creates ADJ WIs for contentious RFS issues in the QP, as it no longer establishes claims without adjudicating them. 

### Note

Source topic: `en_EN/common_notes/note_c_0126.dita`

Note:

Any contentious RFS issues in the BP must be adjudicated. 

### Note

Source topic: `en_EN/common_notes/note_c_3240.dita`

Note:

This does not apply to situations where the employment is not insurable due to a non-arm’s length issue. Adjudication of the dismissal or suspension is required when the employment is not insurable due to a non-arm’s length issue. 

## Regional considerations

Source topic: `en_EN/task/dismissal_ds_rc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/dismissal_ds_rc/what_you_need_to_look_for.dita`

### In NWS:

Source topic: `en_EN/task/dismissal_ds_rc/in_nws.dita`

- Is there a ROD for dismissal on this or a previous EI application?

- Is there a ROD for deferring the RFS adjudication?

- What is the client’s statement in the Dismissal section of this or a previous EI application?

- Are there any SROCs, Action Item (AI) WIs or documentation containing additional information on the dismissal or suspension?

- What benefit type (BT)is the client applying for? 

### In FTS:

Source topic: `en_EN/task/dismissal_ds_rc/in_fts.dita`

- Have claimant’s reports been processed for the period in question?

- If yes, when was the original statement made? 

### In Imaging:

Source topic: `en_EN/task/dismissal_ds_rc/in_imaging.dita`

- Are there any imaged documents that may provide additional information on the dismissal or suspension? 

### In RCM:

Source topic: `en_EN/task/dismissal_ds_rc/in_rcm.dita`

- Is there an ROE for the dismissal?

- If yes, what is the RFS indicated?

- Are there any comments related to the dismissal or suspension?

- Are there other ROEs since the loss of employment? If so, does the client have enough hours after the dismissal to qualify for benefits? 

## Step by step

Source topic: `en_EN/task/dismissal_ds_rc/step_by_step.dita`

### Level 2

Source topic: `en_EN/task/dismissal_ds_rc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/dismissal_ds_rc/reviewing_the_file_level_2.dita`

- In NWS, determine if there is a ROD for the dismissal on file:

- If there is a ROD for the dismissal, go to Decision already on file .
               [Decision already on file](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#DecOnFile)

- If there is no ROD for the dismissal, go to step 2.

- Determine if adjudication can be deferred by consulting Deferring adjudication .

- Determine if the client is correcting previously provided information or providing previously omitted information, and if the information may impact the client’s entitlement to previously paid benefits:

- If no, go to step 4.

- If yes, determine if the issue should be referred to Integrity by consulting Determining if an issue must be referred to Integrity .
               [Determining if an issue must be referred to Integrity](/en/procedure/task/determining_issue_referred_integrity.shtml)

- Determine if the employment is not insurable either because the client is working under a contract for service (self-employed people) or because the client owns more than 40% of the business shares:

- If neither of these reasons applies, go to step 5.

- If the facts clearly indicate that the employment is not insurable for one of these reasons, go to Employment is not insurable .
               [Employment is not insurable](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#NotInsurable)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1745.dita)

- Determine if there is enough information on file to adjudicate the RFS:

- If no, go to step 6.

- If yes, go to step 9. 

#### Fact-finding

Source topic: `en_EN/task/dismissal_ds_rc/fact-finding_level_2.dita`

- Fact-find with the client and the employer by referring to the Fact Finding Guide or Digest 7 — Misconduct to determine the questions to ask.

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3231.dita)

- Determine if the client or employer was reached during fact-finding:

- If the client or employer was reached, go to step 8.

- If the client or employer was not reached or did not reply to the E-02-00-00 email, the N-10-00-00 letter or the Z-00-00-00 letter, go to step 9.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Reason for separation .

- Comments: Type “[Dismissal or Suspension] — [employer’s name] — [last day worked or start date of suspension] — [client or employer].”

- Details: Document the fact-finding details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1746.dita) 

#### Adjudicating a dismissal or suspension

Source topic: `en_EN/task/dismissal_ds_rc/adjudicating_a_dismissal_or_suspension_level_2.dita`

- Determine if the RFS is contentious:

- If the RFS is not contentious, go to Non-contentious reason for separation (RFS).
               [Non-contentious reason for separation (RFS).](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#NotCont)

- If the RFS is dismissal or suspension, go to step 10.

- If the RFS is another contentious RFS, in NWS, change the issue on the ADJ WI and refer to the appropriate procedure.

- Determine if misconduct is proven, considering all evidence provided by both the client and the employer, and in accordance with the principles outlined in the EIA, EIR and case law (refer to Digest 7 — Misconduct as needed):

- If the decision is that misconduct is not proven, go to Misconduct not proven .
               [Misconduct not proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#NoMisc)

- If the decision is that misconduct is proven, go to step 11.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3252.dita) 
           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3233.dita)

- Determine if the client was dismissed within 3 weeks of an anticipated layoff or end of term of employment:

- If no, go to step 12.

- If yes, go to Dismissal before anticipated layoff or end of term of employment — Misconduct proven .
               [Dismissal before anticipated layoff or end of term of employment — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#D44)

- Determine if the client was suspended:

- If the client was suspended, go to Suspension — Misconduct proven .
               [Suspension — Misconduct proven](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#SuspMisc)

- If the client was not suspended, go to Dismissal — Misconduct proven.
               [Dismissal — Misconduct proven.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#DismMisc) 

#### Dismissal — Misconduct proven

Source topic: `en_EN/task/dismissal_ds_rc/dismissal__misconduct_proven_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended for misconduct .

- Enter the employer’s name.

- Enter the date of the dismissal.

- Select Continue .

- Complete the Dismissed for misconduct screen as follows:

- Relevant Facts: Select Dismissed .

- Enter the relevant facts.

- Indicate if the client agrees with the employer’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select the appropriate options and enter any additional information.

- References: Select EIA 30 and enter any additional references.

- Decision: Select Misconduct proven .

- Do you wish to enter a disentitlement for a suspension or anticipated loss of employment?: Select No .

- Do you wish to terminate an existing disentitlement (D42, suspension from employment)?: Select the appropriate option and, if required, complete any additional fields.

- Overpayment: Review and, if required, modify the prefilled codes Detection , Infraction and Message fields.

- Select Continue .

- Determine if this employment is the last employment before the renewal:

- If it is not the last employment and the BPC is between w/cs 2310 and 2361 , go to step 16.

- If it is not the last employment and the BPC is w/c 2309 or before , go to step 17.

- If it is not the last employment and the BPC is w/c 2362 or later , go to step 17.

- If it is the last employment, go to step 19.

- Based on the renewal application, determine the renewal week:

- If the renewal week is w/c 2362 or later, go to step 17.

- If the renewal week is between w/cs 2311 and 2361, go to step 18.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3253.dita)

- Based on the ROEs on file, determine if the client has enough hours since the disqualifying event to qualify for a new claim:

- If the client does not have enough hours to qualify for a new claim, go to step 19.

- If the client has enough hours to qualify for a new claim, go to Rescinding a disqualification — Client has enough hours.
               [Rescinding a disqualification — Client has enough hours.](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#ClientHasGainedRelief)

- Based on the ROEs on file, determine if the client has worked enough hours since establishing this BPC to qualify for a new claim:

- If no, go to step 19.

- If yes, go to Budget 2021 — Reason for separation (RFS) measure .
               [Budget 2021 — Reason for separation (RFS) measure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/dismissal_ds_rc#Budegt2021_reason_for_separation)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3254.dita)

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 20.

- If the client was not reached by telephone during fact-finding, go to step 21.

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE is on file:

- If no, go to step 23.

- If yes, update the Special condition field and go to step 23.

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disqualifications – Definite/indefinite – Previous/current/revision (2970): Select D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous disqualification / Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Disqualification message (2543): Select D10 - Misconduct .

- D10 - No benefits payable (Date of event: before, on, or after the BPC date) (2546): Select D10 - Date of event after BPC and the appropriate options.

- D10 - Min hrs req for reg ben/Insuf. hrs accum. since event reg/Insufficient hrs reg+fishing (2547):

- If the BPC is between w/c 2310 and w/c 2361, select Minimum hours required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious the client does not have enough hours since the disqualifying event to qualify, select Insufficient hours accumulated since event for regular benefits or Insufficient hours accumulated since event for regular benefits and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Minimum hours required to qualify for regular benefits .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- Not Entitled to Regular after special: - D10/D11 or claim is BPNE - Initial or renewal claim or D42 – D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D10 imposed - Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D10 Min hours required to qualify for regular benefits/Not enough hours worked since event for regular/Not enough hours worked since event for regular and not enough fishing earnings for fishing benefits (2547):

- If the BPC is between w/c 2310 and w/c 2361, select Min hrs required to qualify for regular benefits .

- If the client has not worked since the disqualifying event, select Min hrs required to qualify for regular benefits .

- If the client has worked since the disqualifying event and it is obvious there are insufficient hours since the disqualifying event to qualify, select Insufficient hrs accumulated since event for regular or Insufficient hrs accumulated since event for regular and insufficient fishing earnings for fishing benefits .

- If the client has worked since the disqualifying event, but you do not have the information or knowledge to complete this block, select Min hrs required to qualify for regular benefits .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter in ACS when completing the COR WI.

- Complete the ADJ WI. 

#### Budget 2021 — Reason for separation (RFS) measure

Source topic: `en_EN/task/dismissal_ds_rc/budget_2021__reason_for_separation_rfs_measure_level_2.dita`

- In NWS, create a Call Back (CB) WI as follows:

- Complexity: Select Level 1 .

- Language: Select the appropriate option.

- Claim type: Select Initial .

- Benefit type: Select the appropriate option.

- Destination — SCC: Select the Service Canada Centre (SCC) as shown in FTS.

- End user: Select Next available user .

- Category: Select Pay affected .

- Issue: Select Calculation .

- Comments: Type “An indefinite disqualification has been imposed on the renewal claim for [employer name — LDP]. The client may have worked sufficient hours since this BPC to establish a new claim under Budget 2021 measures. If additional information is required, contact the client to discuss termination in favour of a new claim.”

- Obtained by: Select Telephone .

- Obtained from: Select Client .

- Select Save .

- Go to step 2.

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 3.

- If the client was not reached by telephone during fact-finding, go to step 4.

- Verbally communicate the decision to the client.

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or an N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the following attributes:

- Disqualifications – Definite/indefinite – previous/current/revision (2970): Select D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revision) .

- D11 / D10 / Both / Previous Disq / Revision (Initial/Renewal or Revision) (2542): Select Disqualification message .

- Disqualification message (2543): Select D10 - Misconduct .

- D10 – No benefits payable (Date of event: before, on, or after the BPC date) (2546): Select D10 - Date of event after BPC and the appropriate options.

- D10 – Min hrs req for reg ben/Insuf. hrs accum. since event reg/Insufficient hrs reg+fishing (2547):

- Select Minimum hours required to qualify for regular benefits .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- Not entitled to regular after special: - D10/D11 or claim is BPNE - Initial or renewal claim or D42 – D43 (2540): Select (D11/D10) imposed - Only special benefits allowed .

- D11/D10 imposed - Only special benefits allowed (2491): Select D10 imposed - Special benefits allowed .

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the appropriate date.

- D10 Min hours required to qualify for regular benefits/Not enough hours worked since event for regular/Not enough hours worked since event for regular and not enough fishing earnings for fishing benefits (2547):

- Select Min hrs required to qualify for regular benefits .

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter when completing the COR WI.

- Complete the ADJ WI. 

#### Decision already on file

Source topic: `en_EN/task/dismissal_ds_rc/decision_already_on_file_level_2.dita`

- Determine if the appropriate decision is listed:

- If yes, on the list, select the appropriate ROD and select Save . Go to step 4.

- If no , select Decision not in the list .

- Select the appropriate special condition based on the decision on file and select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI. 

#### Employment is not insurable

Source topic: `en_EN/task/dismissal_ds_rc/employment_is_not_insurable_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “[Dismissal or Suspension] — [employer’s name] — [last day worked or start date of suspension] — adjudication not required.”

- Details: Type the appropriate option:

- “The employment is not insurable because the client is working under a contract for service (self-employed people). Adjudication of the dismissal or suspension is therefore not required.”

- “The employment is not insurable because the client owns more than 40% of the business shares. Adjudication of the dismissal or suspension is therefore not required.”

- Contact an authorized user (team leader or business expertise advisor) to delete the ADJ WI. 

#### Non-contentious reason for separation (RFS)

Source topic: `en_EN/task/dismissal_ds_rc/non-contentious_reason_for_separation_rfs_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The reason for separation is not dismissal or suspension .

- Select Continue .

- Complete the Not dismissal or suspension screen as follows:

- Select the appropriate RFS.

- Select Continue

- Verify the information on the Record of Decision screen:

- Check I agree .

- In RCM, determine if the ROE is on file:

- If yes, go to step 5.

- If no, go to step 7.

- Update block 16 of the ROE as follows:

- Reason for issuing this record of employment : Select the appropriate RFS option and sub-option, if necessary.

- Select Validate .

- Select Submit .

- Determine if the ROE was flagged in error after validation:

- If yes, fix the validation error and go to step 7.

- If no, go to step 7.

- Complete the ADJ WI. 

#### Misconduct not proven

Source topic: `en_EN/task/dismissal_ds_rc/misconduct_not_proven_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended .

- Enter the employer’s name.

- Enter the date of the dismissal or suspension.

- Select Continue .

- Complete the Dismissed for misconduct screen as follows:

- Relevant Facts: Select Dismissed or Suspended .

- Enter the relevant facts.

- Indicate if the client agrees with the employer’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select the appropriate options and enter any additional information.

- References: Enter any additional references.

- Decision: Select Misconduct not proven .

- Do you wish to terminate an existing disentitlement (D42, suspension from employment)?: Select the appropriate option and, if required, complete any additional fields.

- Written Notification: Select the appropriate option and, if required, provide the employer’s information for the letter.

- Indicate if the client was suspended from employment.

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In FTS, determine if there is a D10 on file because this RFS adjudication was previously deferred:

- If yes, go to step 5.

- If no, go to step 7.

- Determine if the D10 is solely due to this previously deferred RFS issue and if other issues must be adjudicated:

- If no other issues must be adjudicated, go to step 6.

- If other issues must be adjudicated refer to the appropriate tasks for guidance. Then go to step 6.

- Select the Disqualifications/Disentitlements link and rescind the disqualification as follows:

- Select the disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) screen opens, complete the following fields:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In RCM, determine if the ROE is on file:

- If no, go to step 8.

- If yes, update the Special condition field and go to step 8.

- Complete the ADJ WI. 

#### Dismissal before anticipated layoff or end of term of employment — Misconduct proven

Source topic: `en_EN/task/dismissal_ds_rc/dismissal_before_anticipated_layoff_or__f67a228e_level_2.dita`

- In NWS, on the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended for misconduct .

- Enter the employer’s name.

- Enter the date of the dismissal.

- Select Continue .

- Complete the Dismissed for misconduct screen as follows:

- Relevant Facts: Select Dismissed or Suspended .

- Enter the relevant facts.

- Indicate if the employer agrees with the client’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select the appropriate options and enter any additional information.

- References: Select EIA 33 and enter any additional references.

- Decision: Select Misconduct proven .

- Do you wish to enter a disentitlement for a suspension or anticipated loss of employment?: Select Yes .

- Input Disentitlement: Select Anticipated loss of employment (D44) and enter the disentitlement end date (must be a weekday).

- Overpayment: Review and, if required, modify the pre-filled codes Detection , Infraction and Message fields.

- Do you wish to terminate an existing disentitlement (D42, suspension from employment)?: Select No .

- Select Continue .

- Verify the information on the Record of Decision screen:

- Check I agree .

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the appropriate options:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D44: Loses employment due to misconduct within 3 weeks of layoff or end of term .

- We/In addition, we (2687) .

- Definite disentitlement start date (1272): Enter the appropriate date.

- Definite disentitlement end date (1274): Enter the appropriate date.

- Text: Name of employer(s) (1502): Enter the employer’s name.

- Date of event (1292): Enter the date of the dismissal.

- being laid off / the end of your term (3023): Select being laid off or the end of your term .

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X] because you were dismissed from your job with [Text - Name of Employer(s)] due to misconduct on [Date of Event] within 3 weeks of [being laid off/the end of term].”

- Right to Request Reconsideration (with Blank option) (4169): Select Right to request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter in ACS when completing the COR WI.

- Complete the ADJ WI. 

#### Suspension — Misconduct proven

Source topic: `en_EN/task/dismissal_ds_rc/suspension__misconduct_proven_level_2.dita`

- On the Resolve Issue tab of the ADJ WI, complete the Level 2 Dismissal screen as follows:

- Select The client was dismissed or suspended for misconduct .

- Enter the employer’s name.

- Enter the date of the suspension.

- Select Continue .

- Complete the Dismissed for misconduct screen as follows:

- Relevant Facts: Select Suspended .

- Enter the relevant facts.

- Indicate if the client agrees with the employer’s version of the events.

- Credibility: Indicate whether credibility was a factor in the decision and complete any additional fields, if required.

- Rationale: Select the appropriate options and enter any additional information.

- References: Select EIA 31 and enter any additional references.

- Decision: Select Misconduct proven .

- Do you wish to enter a disentitlement for a suspension or anticipated loss of employment?: Select Yes .

- Input Disentitlement: Select Suspension from employment (D42) .

- Disentitlement start date (YYYY-MM-DD): Enter the start date.

- Disentitlement end: Select Indefinite or Specific date and enter the end date (must be a weekday).

- Overpayment: Review and, if required, modify the pre-filled codes Detection , Infraction and Message fields.

- Do you wish to terminate an existing disentitlement (D42, suspension from employment)?: Select the appropriate option and, if required, complete any additional fields.

- Select Continue .

- Determine if the client was reached by telephone during fact-finding:

- If the client was reached by telephone during fact-finding, or if there was no attempt to fact-find with the client by telephone, go to step 4.

- If the client was not reached by telephone during fact-finding, go to step 5.

- Verbally communicate the decision to the client.

- Verify the information on the Record of Decision screen:

- Check I agree .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3255.dita)

- In ACS, create and save a D-01-00-00 letter for regular benefits, or the N-00-00-00 letter for special benefits. Based on the claim information, select all of the required attributes, including the following:

- If the client is requesting regular benefits, select the appropriate options:

- Disentitlements (2976): Select D4, D24, D42, D43, D44 .

- D4, D24, D42, D43, D44 (3021): Select D42 - Suspension due to misconduct .

- We/In addition, we (2687) .

- Indefinite/Definite/Multiple Disentitlement dates (2485): Enter the appropriate dates.

- are/were (2979) .

- since/on (3022) .

- Date of suspension from employment (1470): Enter the appropriate date.

- Text - Name of employer(s) (1502): Enter the employer’s name.

- If the client is requesting special benefits, select the following attributes:

- Special benefits approved (3046): Select the BT and the appropriate options.

- This letter replaces or Footnote (2365): Select Footnote .

- Text - Footnote (1066): Type “Once you have received all your special benefits, we will not pay you any regular benefits from [X] to [X] because you were suspended from your job with [Text - Name of Employer(s)] due to misconduct.”

- Right to Request a Reconsideration (with Blank option) (4169): Select Right to Request a Reconsideration .

- In NWS, create a client Note instructing the responsible officer to add the appropriate attributes before sending the draft D-01-00-00 or N-00-00-00 letter in ACS when completing the COR WI.

- Complete the ADJ WI for the suspension issue. 

#### Rescinding a disqualification — Client has enough hours

Source topic: `en_EN/task/dismissal_ds_rc/rescinding_a_disqualification__client_h_d63939aa_level_2.dita`

- In NWS, on the Resolve Issue tab, verify the information on the Record of Decision screen:

- Check I agree .

- Complete the ADJ WI.

- Create a Reminder (REM) WI as follows:

- Complexity: Select Level 2 .

- Reason: Select Other .

- Comments: Type “Rescind this disqualification.”

- Due date: Enter the next business day.

- Language: Select the appropriate option.

- Details: Type “Once the renewal is finalized, if the client has enough hours to gain relief, rescind the D10 and create a ROD to justify the cancellation.”

- Destination: Enter the SCC as shown in FTS.

- End User: Select Myself .

- Select Save .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3256.dita)

- Move the REM WI to Pending as follows:

- Send to my pending workload: Check the box.

- Reason: Select Other .

- Comments: Type “The Claim action status of the renewal claim is In progress.”

- Bring forward date: Enter the next working day.

- Select Save .

- When the REM WI moves to the current workload, determine if the claim has been finalized:

- If no, repeat step 4.

- If yes, go to step 6.

- In NWS, create a ROD and complete the following fields:

- Comments: Type “Dismissal — [employer’s name] — [last day worked] — gained relief.”

- Details: Type “No disqualification to be imposed as client has sufficient hours since this disqualifying event to establish a new claim. No notification required.”

- In FTS determine if a D10 has been imposed:

- If yes, go to step 8.

- If no, go to step 11.

- Determine the claim status (CS):

- If the CS is 6 - Terminated , go to step 9.

- If the CS is 0 - Active , go to step 10.

- Select the File Control Data (M101)/Claim Action transaction:

- Select Reactivate non-blocked claim (M101-12) .

- Select Update .

- Select the Disqualifications/Disentitlements (M161) link and rescind this event’s D10 as follows:

- Select the original disqualification.

- Select Modify .

- When the Disqualifications/Disentitlements (M161) transaction opens, complete the following:

- Registration number: Select the appropriate registration number.

- Action: Select X - Rescind .

- Disqualification: 10 - Dismissal - misconduct proven .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select F - Non-fraud - Other .

- Message: Select 1 - An overpayment resulted due to a disqualification .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes to complete the registration number.

- Select Update .

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_3257.dita)

- In NWS, create a client Note and type “No D-01-00-00 letter is required.”

- Complete the REM WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_1745.dita`

Note:

Employment that is not insurable due to a non-arm’s length issue must be adjudicated. 

#### Note

Source topic: `en_EN/common_notes/note_c_3231.dita`

Note:

If the employee’s disciplinary record contains documentary evidence related directly to the dismissal or suspension, we should request a copy of the client’s file from the employer. In cases of railway misconduct, we must also request a copy of the hearing transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_1746.dita`

Note:

Create a new SROC for each conversation with the employer or the client (e.g. if you contacted the employer twice, create 2 SROCs). 

#### Note

Source topic: `en_EN/common_notes/note_c_3252.dita`

Note:

If the client or the employer cannot be reached, render a decision based on the information on file. 

#### Note

Source topic: `en_EN/common_notes/note_c_3233.dita`

Note:

Railway misconduct is only proven when the officer is able to obtain the transcript of the disciplinary committee hearing or when the client has provided sufficient facts regarding the railway rule or regulation violation to prove misconduct without the transcript. 

#### Note

Source topic: `en_EN/common_notes/note_c_3253.dita`

Note:

If the claim’s BPC is w/c 2309 or before, or w/c 2362 or later, the only disqualification that can be rescinded is the D10 that the system imposed on the renewal. 

#### Note

Source topic: `en_EN/common_notes/note_c_3254.dita`

Note:

For claims with BPCs between w/c 2310 and w/c 2361 a national common entrance requirement of 420 hours of insurable employment is required to establish a claim for regular or special benefits. If the client has a violation on file, increased entrance requirements may apply.
       [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements)

     [increased entrance requirements](/en/procedure/generic/knowledge.shtml#Increased_entrance_requirements) 

#### Note

Source topic: `en_EN/common_notes/note_c_3255.dita`

Note:

If the facts reveal that the client quit or was dismissed after the suspension, create another ADJ WI for the dismissal issue. Refer to the appropriate procedure to complete that WI. 

#### Note

Source topic: `en_EN/common_notes/note_c_3256.dita`

Note:

The only disqualification to be rescinded is this decision, which is related to the D10. If there are any other disqualifications on file, they must not be rescinded. 

#### Note

Source topic: `en_EN/common_notes/note_c_3257.dita`

Note:

Use the renewal registration number to rescind the disqualification. Override the 740 error. 

## Policy reference

Source topic: `en_EN/task/dismissal_ds_rc/policy_reference.dita`

- Digest 7 — Misconduct
         [Digest 7 — Misconduct](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-7/table-of-contents.html)

- National Policy on Voluntary Disclosure
         [National Policy on Voluntary Disclosure](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/divulgation-volontaire-voluntary-disclosure.shtml)

- EIA 29
         [EIA 29](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

- EIA 30
         [EIA 30](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-30.html)

- EIA 31
         [EIA 31](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-31.html)

- EIA 33
         [EIA 33](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-33.html) 
