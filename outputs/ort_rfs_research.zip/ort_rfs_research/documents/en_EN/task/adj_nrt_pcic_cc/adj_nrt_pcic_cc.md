# Adjudicating non-referred training: Family caregiver benefits — Continuing claim

Source map: `en_EN/task/adj_nrt_pcic_cc/adj_nrt_pcic_cc.ditamap`

## Summary

Source topic: `en_EN/task/adj_nrt_pcic_cc/summary.dita`

Summary: When a client receiving family caregiver benefits decides to take a non-referred training course, the officer determines if the client is entitled to benefits during the training period. 

## What you need to know

Source topic: `en_EN/task/adj_nrt_pcic_cc/what_you_need_to_know.dita`

### Training reported between September 27, 2020 and September 11, 2021

Source topic: `en_EN/task/adj_nrt_pcic_cc/training_reported_between_september_27__5ecd71c7.dita`

A transitional measure under which ACP automatically adjudicated and allowed all training effective September 27, 2020 has ended on September 11, 2021. The intent of this measure was to prevent any delay in payment to clients who reported training.

The client must still meet the entitlement conditions for family caregiver benefits while attending non-referred training. A client attending non-referred training may provide information on a claimant’s report or during a conversation with an officer that brings into question the entitlement to family caregiver benefits. In this case, the officer creates a WI for the training issue and follows normal adjudication procedures, even if ACP initially allowed the training. 

### Impact of training on family caregiver benefits

Source topic: `en_EN/task/adj_nrt_pcic_cc/impact_of_training_on_family_caregiver_benefits.dita`

When adjudicating non-referred training for a client receiving family caregiver benefits, the issue is not availability, but whether the client continues to care for the patient for whom the benefits are payable. This includes clients who are attending short-term training courses and targeted initiatives. Refer to the job aid for a complete list of non-referred short-term courses and targeted initiatives.
       [job aid](/en/procedure/generic/additionalresources/shortterm_courses_ti.shtml)

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1674.dita) 

### Targeted initiatives and short-term courses

Source topic: `en_EN/task/adj_nrt_pcic_cc/targeted_initiatives_and_short-term_courses.dita`

When clients receiving family caregiver benefits report that they are attending a targeted initiative or short-term course, the total daily or weekly attendance hours is not considered.

If the client is attending a short-term course referred under EIA 25, refer to Confirming referred training: Special benefits — Continuing claim .
       [Confirming referred training: Special benefits — Continuing claim](/en/procedure/task/confirmreftrng_sb_rc.shtml) 

### Levels of decision

Source topic: `en_EN/task/adj_nrt_pcic_cc/levels_of_decision.dita`

A Level 1 officer is authorized to allow benefits when both of the following conditions are met:

- The training is under 25 hours per week.

- The training location is in an area where the client can provide care and support to the patient.

There must be no doubt that the client is still providing care. If the client makes any statement that creates doubt that the client is providing care, the Level 1 officer refers the issue to Level 2. 

### Care or support

Source topic: `en_EN/task/adj_nrt_pcic_cc/care_or_support.dita`

Care is defined as:

- any care that is required because of a critically ill or injured patient’s state of health, other than the care provided by a health care professional.

Support is defined as:

- any psychological or emotional support that is required because of a critically ill patient’s state of health.

The definition of care or support includes situations where the client spends time each day with the critically ill patient in the home, a hospice or a medical facility.

An individual claiming this BT may require a short break from providing care or support to the critically ill patient. That is why benefits are not automatically denied when the client stops providing care for only a few days. The officer determines whether the client continues to be entitled to benefits based on the merits of each individual case.

If it becomes apparent that the client is not providing care or support based on the definitions above, the client is disentitled from benefits.

For more information, the officer can refer to Digest 22.2.4 — Care or support of critically ill or injured child or adult .
       [Digest 22.2.4 — Care or support of critically ill or injured child or adult](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-22/family-caregiver-benefits.html#a22_2_4) 

### Imposing a disentitlement

Source topic: `en_EN/task/adj_nrt_pcic_cc/imposing_a_disentitlement.dita`

If the client requests family caregiver benefits but does not show that the client is providing care or support while attending the course, the officer imposes a 61 - Family caregiver for children or adults - Does not meet the entitlement conditions (D61) disentitlement.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1675.dita) 

### Note

Source topic: `en_EN/common_notes/note_c_1674.dita`

Note:

If a client quits employment or refuses an offer of employment to attend a non-referred training course, a non-referred short-term training course or a targeted initiative, the officer adjudicates the reason for separation or refusal of employment on a separate WI. 

### Note

Source topic: `en_EN/common_notes/note_c_1675.dita`

Note:

If the claim is in MPS, the officer creates an Operational Centre Memo (MM06) to advise IPOC to impose a disentitlement on a continuing claim. 

## Regional considerations

Source topic: `en_EN/task/adj_nrt_pcic_cc/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/task/adj_nrt_pcic_cc/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/task/adj_nrt_pcic_cc/untitled_section.dita`

In FTS:

- Is there a registration number for the non-referred training issue?

- Is there training information in the Project tab?

In NWS:

- Is there a record of decision (ROD) for the non-referred training issue?

- Is there an SROC or an Action Item WI with the training information, from either the Part-time Training checklist or the Training Course Information (INS3141) form?

In Imaging:

- Is there non-referred training information or the INS3141 form? 

## Step by step

Source topic: `en_EN/task/adj_nrt_pcic_cc/step_by_step.dita`

### Level 1

Source topic: `en_EN/task/adj_nrt_pcic_cc/level_1.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_nrt_pcic_cc/reviewing_the_file_level_1.dita`

- Determine if the non-referred training issue has been adjudicated and if there is an existing ROD in NWS:

- If there is a ROD for the non-referred training issue, go to step 2.

- If the training has not been adjudicated, go to step 3.

- Determine if the client has made any statement that creates doubt that the client is providing care for the patient for whom the benefits are payable while on the non-referred training:

- If there is no doubt that the client is providing care for the patient, go to step 7.

- If there is doubt that the client is providing care for the patient, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#reassign2)

- Determine if the following non-referred training details are on file:

- number of hours of training per week (if the client is attending regular non-referred training)

- location of the training

- start date of training

- If all of the training details are not on file, go to step 4.

- If all of the training details are on file, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/adj_nrt_pcic_cc/fact-finding_level_1.dita`

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached , go to step 6.

- If the client was not reached or did not reply to the E-02-00-00 email or the N-10-00-00 letter, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#reassign2)

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — family caregiver benefits.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Determining if the conditions are met to allow at Level 1

Source topic: `en_EN/task/adj_nrt_pcic_cc/determining_if_the_conditions_are_met_t_16907630_level_1.dita`

- Determine the type of training the client is attending:

- If the client is attending a short-term training course or a targeted initiative, go to step 8.

- If the client is attending regular non-referred training, go to step 9.

- Determine if the short-term course or targeted initiative is at a location that requires the client to reside away from the patient while attending:

- If the short-term course or targeted initiative is at a location that allows the client to provide care or support to the patient while attending, go to step 9.

- If the short-term course or targeted initiative is at a location that can prevent the client from providing care or support to the patient while attending, go to Reassigning the issue to Level 2 .
               [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#reassign2)

- Determine if both of the following conditions are met:

- The non-referred training is less than 25 hours per week.

- The non-referred training is at a location that allows the client to provide care or support to the patient while attending the course.

- If both conditions are met, go to step 10.

- If either condition is not met, go to Reassigning the issue to Level 2 .
                   [Reassigning the issue to Level 2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#reassign2)

- In FTS, determine if the (CS) is 8 - converted to manual pay :

- If yes, go to Entitlement conditions met — MPS claim .
               [Entitlement conditions met — MPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#MPSInputs)

- If no, go to Entitlement conditions met — CPS claim .
               [Entitlement conditions met — CPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#CPSInputs) 

#### Entitlement conditions met — MPS claim

Source topic: `en_EN/task/adj_nrt_pcic_cc/entitlement_conditions_met__mps_claim_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — family caregivers — entitlement in order.”

- Details: Type “The client is providing care for the patient while on non-referred training.” Document any other details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In FTS, determine if there is a registration number assigned for the training issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and create an Operational Centre Memo (MM06) to inform IPOC of the decision as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 1 - No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work Type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Training ID 90. Start date [XXXX]. End date [XXXX].”

- Remarks line 2: Type “The client is entitled to collect benefits while attending a non-referred training course.”

- Remarks line 3: Type “Send paper claimant’s reports to the client.”

- Remarks line 4: Type your name and phone number.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, complete the WI for the training issue. 

#### Entitlement conditions met — CPS claim

Source topic: `en_EN/task/adj_nrt_pcic_cc/entitlement_conditions_met__cps_claim_level_1.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — family caregivers — entitlement in order.”

- Details: Type “The client is providing care for the patient while on non-referred training.” Document any other details according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save .

- In FTS, determine if the non-referred training information has been input on the Project tab

- If the non-referred training information has not been input, go to step 3.

- If the non-referred training information has been input, go to step 4.

- In FTS, input the training information on the Project tab as follows:

- Select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 5.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 5.

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 6.

- If an MA72 is imposed and there is a registration number, go to step 7.

- If no MA72 is imposed but there is a revised registration number, go to step 8.

- If none of the above applies, go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the appropriate registration number .

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: C - Yes .

- Select Update .

- Go to step 9.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI for the training issue. 

#### Reassigning the issue to Level 2

Source topic: `en_EN/task/adj_nrt_pcic_cc/reassigning_the_issue_to_level_2_level_1.dita`

- Determine if the CS is 8 - converted to manual pay :

- If yes, go to step 2.

- If no, go to step 7.

- Determine if there is a registration number for the issue:

- If no, go to step 3.

- If yes, go to step 4.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operation Centre Memo (MM06) to stop payment as follows:

- Registration number: Select the appropriate registration number .

- Memo (MPS): Check the box.

- Contentious: Select 1- No .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the BPC of the appropriate claim.

- Work item: Select 93 - Manual Pay System .

- Work Type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Urgent. Stop payment as of w/c [XXXX].”

- Remarks line 2: Type “Adjudication is required to determine if the client is entitled to benefits while attending non-referred training.”

- Remarks line 3: Type your name and telephone number.

- Decision Type: Select 3 - Revised .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, reassign the WI as follows:

- Destination: Select Next Available User .

- Complexity: Select Level 2 .

- Reason: Select Unable to Complete .

- Details: Type the appropriate reason:

- “Unable to contact client for fact-finding.”

- “Not within Level 1 authority — The non-referred training is more than 25 hours per week.”

- “The non-referred training is at a location that can prevent the client from providing care or support to the patient.”

- “There is doubt as to whether the client is providing care for the patient while on non-referred training.”

- Select OK .

- When the Warning window is displayed, select Ok . 

### Level 2

Source topic: `en_EN/task/adj_nrt_pcic_cc/level_2.dita`

#### Reviewing the file

Source topic: `en_EN/task/adj_nrt_pcic_cc/reviewing_the_file_level_2.dita`

- Determine if the non-referred training issue has been adjudicated and if there is an existing ROD in NWS:

- If there is a ROD for the training issue, go to step 2.

- If the training has not been adjudicated, go to step 3.

- Determine if the client has made any statement that creates doubt that the client is providing care for the patient for whom the benefits are payable while on the non-referred training:

- If there is doubt that the client is providing care for the patient, go to step 3.

- If there is no doubt that the client is providing care for the patient, go to step 8.

- Determine if the non-referred training details are on file (e.g. number of hours of training per week if the client is attending regular non-referred training, and location of school):

- If additional details are needed, go to step 4.

- If additional details are not needed, go to step 7. 

#### Fact-finding

Source topic: `en_EN/task/adj_nrt_pcic_cc/fact-finding_level_2.dita`

- Fact-find with the client.

- Determine if the client was reached during fact-finding:

- If the client was reached , go to step 6.

- If the client was not reached or did not reply to the E-02-00-00 email or the N-10-00-00 letter, go to step 7.

- In NWS, add details to the draft SROC or create a new SROC as follows:

- Main Issue: Select Training .

- Comments: Type “Non-referred training — family caregiver benefits.”

- Details: Document the fact-finding details according to the National Fact-Finding and Documentation Policy .
               [National Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- Select Save . 

#### Adjudicating non-referred training

Source topic: `en_EN/task/adj_nrt_pcic_cc/adjudicating_non-referred_training_level_2.dita`

- Adjudicate the non-referred training according to the entitlement principles found in Digest 22.5.0 Attending a course of instruction :

- If the client has met the entitlement conditions, go to step 8.

- If the client has not met the entitlement conditions, go to step 9.

- In FTS, determine if the CS is 8 - converted to manual pay :

- If yes, go to Entitlement conditions met — MPS claim .
               [Entitlement conditions met — MPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#MPSInputsL2)

- If no, go to Entitlement conditions met — CPS claim .
               [Entitlement conditions met — CPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#CPSInputsL2)

- In FTS, determine if the CS is 8 - converted to manual pay:

- If yes, go to Entitlement conditions not met — MPS claim .
               [Entitlement conditions not met — MPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#MPSInputsL2NotEnt)

- If no, go to Entitlement conditions not met — CPS claim .
               [Entitlement conditions not met — CPS claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/task/adj_nrt_pcic_cc#CPSInputsL2NotEnt) 

#### Entitlement conditions met — MPS claim

Source topic: `en_EN/task/adj_nrt_pcic_cc/entitlement_conditions_met__mps_claim_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — entitlement in order.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is a registration number assigned for the training issue:

- If yes, go to step 3.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) to inform IPOC of the decision and to reinstate payment as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work Type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Training ID 90. Start date [XXXX]. End date [XXXX].”

- Remarks line 2: Reinstate payment as of w/c [XXXX].” (if a request was sent to IPOC to stop payment).

- Remarks line 3: Type “The client is entitled to collect benefits for the non-referred training period . Send paper claimant’s reports to the client. ”

- Remarks line 4: Type your name and telephone number.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In NWS, complete the WI for the training issue. 

#### Entitlement conditions met — CPS claim

Source topic: `en_EN/task/adj_nrt_pcic_cc/entitlement_conditions_met__cps_claim_level_2.dita`

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — entitlement in order.”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if the non-referred training information has been input on the Project tab:

- If the non-referred training information has not been input, go to step 3.

- If the non-referred training information has been input, go to step 4.

- In FTS, input the training information on the Project tab as follows:

- Select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 5.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 5.

- Determine if an MA72 is imposed and if there is an outstanding registration number for the non-referred training issue:

- If an MA72 is imposed but there is no registration number, go to step 6.

- If an MA72 is imposed and there is a registration number, go to step 7.

- If no MA72 is imposed but there is a revised registration number, go to step 8.

- If none of the above applies, go to step 9.

- In FTS, select the Registration Number (M025, M030, M035) transaction and assign a registration number as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised Decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction and remove the MA72 as follows:

- Registration number: Select the appropriate registration number.

- Manual Action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- Go to step 9.

- In FTS, select the Renewal/Revised (M106) transaction and complete the registration number as follows:

- Claim Allowed: Select NCA - No changes to the claim .

- Contentious: Select 1 - No .

- Complete: Select C - Yes .

- Select Update .

- In NWS, complete the WI for the training issue. 

#### Entitlement conditions not met — MPS claim

Source topic: `en_EN/task/adj_nrt_pcic_cc/entitlement_conditions_not_met__mps_claim_level_2.dita`

- Verbally communicate the decision to the client

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — D61 from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number for the training issue:

- If yes, go to step 4.

- If no, select the Registration Number (M025, M030, M035) transaction and assign one as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- In FTS, select the Renewal/Revised (M106) transaction to create an Operational Centre Memo (MM06) to inform IPOC to impose a disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Memo (MPS): Check the box.

- Contentious: Select 2 - Yes .

- Complete: Select D - No .

- Select Update .

- When the Operational Centre Memo (MM06) transaction opens, send the information to IPOC as follows:

- Registration number: Select the appropriate registration number.

- BPC: Select the appropriate BPC.

- Work item: Select 93 - Manual Pay System .

- Work Type: Select 30 - New information on a manual pay claim .

- Remarks line 1: Type “Urgent request.”

- Remarks line 2: Select the appropriate option:

- If the end date is known, type “D61 from w/c [XXXX-X] to w/c [XXXX-X].”

- If the end date is not known, type “D61 from w/c [XXXX-X] to 9999-9.”

- Remarks line 3: Type “Training ID 90. Start date [XXXX]. End date [XXXX].”

- Remarks line 4: Type “The client is not entitled to collect benefits for the non-referred training period.”

- Remarks line 5: Enter your first name and last name.

- Decision Type: Select 3 - Revised .

- Contentious: Select 2 - Yes .

- Complete: Select C - Yes .

- Select Update .

- Select the Registration Number (M025, M030, M035) transaction and transfer the registration number to IPOC as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Change registration flag .

- Registration flag: Select 4 - Insurance Payment Operational Centre .

- Select Update .

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065)

- If the BT was family caregiver for children, select Family caregiver benefits for children denied - D61/D62/D63/Free text (11282) .

- Select D61 - Not entitled to family caregiver benefits for children - Various reasons (11283) .

- Select D61 - Client does not provide care or support to the critically Ill or injured child .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop down calendar.

- If the BT was family caregiver for adults, select Family caregiver benefits for adults denied - D61/D62/D63 / Free Text (11281) .

- Select D61 - Not entitled to family caregiver benefits for adults - Various reasons (11276) .

- Select D61 - Client does not provide care or support to the critically ill or injured adult .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop down calendar.

- Overpayment messages (2452) .

- Right to Request a Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- This letter replaces or Footnote (2365): Type “You have not proven that you are caring for your family member while attending a course of instruction on your own initiative.”

- In NWS, complete the WI for the training issue. 

#### Entitlement conditions not met — CPS claim

Source topic: `en_EN/task/adj_nrt_pcic_cc/entitlement_conditions_not_met__cps_claim_level_2.dita`

- Verbally communicate the decision to the client

- In NWS, create a ROD as follows:

- Comments: Type “Non-referred training — D61 from w/c [XXXX-X] to [XXXX-X].”

- Details: Document the decision and rationale according to the Fact-Finding and Documentation Policy .
               [Fact-Finding and Documentation Policy](/en/policy/nationalpolicy/national_policy_factfinding.shtml)

- In FTS, determine if there is an outstanding registration number for the non-referred training issue:

- If there is an outstanding registration number, go to step 4.

- If there is no outstanding registration number, assign one on the Registration Number (M025, M030, M035) transaction as follows:

- Action: Select Assign .

- Claim Source: Select 3 - Mail/Revised decision .

- Service Unit: Select 1 .

- Decision type: Select 3 - Revised .

- Select Update .

- Determine if an MA72 is imposed for the non-referred training issue:

- If an MA72 is imposed, go to step 5.

- If an MA72 is not imposed, go to step 6.

- Select the Renewal/Revised (M106) transaction to remove the MA72 and input the disentitlement as follows:

- Registration number: Select the related registration number.

- Manual action: Select 72 - Additional Training information required .

- Rescind: Check the box.

- Action: Select Add .

- Disentitlement: Select 61 - Family Caregiver for children or adults - Does not meet entitlement conditions .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Select Update .

- Go to step 7.

- In FTS, select the Disqualifications/Disentitlements (M161) transaction and input the disentitlement as follows:

- Registration number: Select the appropriate registration number.

- Action: Select Add .

- Disentitlement: Select 61 - Family Caregiver for children or adults - Does not meet entitlement conditions .

- Start date: Select the disentitlement start date.

- End date: Select the appropriate end date as follows:

- If the training has ended, select the corresponding end date of the disentitlement.

- If the training has not ended, select Indefinite .

- Detection: Select 31 - Other new facts - entitlement review .

- Infraction: Select B - Non-fraud - Availability, capability .

- Message: Select the appropriate message:

- 3 - An overpayment resulted due to a definite disentitlement .

- 4 - An overpayment resulted due to an indefinite disentitlement .

- Contentious: Select 2 - Yes .

- Complete: Select the appropriate option:

- C - Yes to clear the registration number.

- D - No to leave the registration number open for subsequent transactions.

- Select Update .

- Go to step 7.

- Determine if the non-referred training information has been input in the Project tab:

- If the non-referred training information has been input, go to step 8.

- If the non-referred training information has not been input, select the Project Data - Training (M171) transaction and input it as follows:

- Start date: Select the start date of the training.

- End date: Select the end date of the training.

- Training identification: Select 90 - Non-referred claimant .

- Select Update .

- Go to step 8.

- Determine if there is a pending claimant’s report:

- If there is a pending claimant’s report, clear the outstanding claimant’s report and go to step 9.
               [claimant’s report](/en/procedure/activity/claimant_report.shtml)

- If there is no pending claimant’s report, go to step 9.

- In ACS, create and send the N-00-00-00 letter. Based on the claim information, select all of the required attributes, including the following:

- Special benefits denied (3065)

- If the BT was family caregiver for children, select Family caregiver benefits for children denied - D61/D62/D63/Free text (11282) .

- Select D61 - Not entitled to family caregiver benefits for children - Various reasons (11283) .

- Select D61 - Client does not provide care or support to the critically Ill or injured child .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop down calendar.

- If the BT was family caregiver for adults, select Family caregiver benefits for adults denied - D61/D62/D63 / Free Text (11281) .

- Select D61 - Not entitled to family caregiver benefits for adults - Various reasons (11276) .

- Select D61 - Client does not provide care or support to the critically ill or injured adult .

- Select Indefinite/Definite/Multiple Disentitlement dates (2485) .

- Select the appropriate dates from the drop down calendar.

- Overpayment messages (2452) .

- Right to Request a Reconsideration (no Blank Option) (4169): Select Right to Request a Reconsideration .

- This letter replaces or Footnote (2365): Type “You have not proven that you are caring for your family member while attending a course of instruction on your own initiative.”

- In NWS, complete the WI for the training issue. 

## Policy reference

Source topic: `en_EN/task/adj_nrt_pcic_cc/policy_reference.dita`

- Digest 10.12.2 — Persons attending courses on their own initiative
         [Digest 10.12.2 — Persons attending courses on their own initiative](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/courses-instruction-employment-measures.html#a10_12_2)

- Digest 22.2.4 — Care or Support of critically ill or injured family member
         [Digest 22.2.4 — Care or Support of critically ill or injured family member](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-22/benefits-parents-critically-ill-children.html#a22_2_4)

- National Policy on Levels of Decision
         [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision-annex1.shtml) 
