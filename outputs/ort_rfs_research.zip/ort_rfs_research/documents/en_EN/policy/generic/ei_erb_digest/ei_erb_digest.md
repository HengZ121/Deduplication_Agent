# EI Emergency Response Benefit Digest

Source map: `en_EN/policy/generic/ei_erb_digest/ei_erb_digest.ditamap`

## Generic

Source topic: `en_EN/policy/generic/ei_erb_digest/generic.dita`

Table of contents

- Introduction
         [Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#introduction)

- Chapter 1: Basic Concepts
         [Chapter 1: Basic Concepts](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_1)

- Chapter 2: Definition of Claimant
         [Chapter 2: Definition of Claimant](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_2)

- Chapter 3: Claim Procedure

- 3.1 Alternate Form and Manner for Making an EI ERB Claim
             [3.1 Alternate Form and Manner for Making an EI ERB Claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_3_1)

         [Chapter 3: Claim Procedure](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_3)

- Chapter 4: Eligibility

- 4.1 Reside in Canada
             [4.1 Reside in Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_1)

- 4.2 Ceased Working for Reasons Related to Covid-19
             [4.2 Ceased Working for Reasons Related to Covid-19](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_2)

- 4.3 900 Series SINs and Work Permits
             [4.3 900 Series SINs and Work Permits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_3)

- 4.4 Commuter, Interstate and Overseas claims
             [4.4 Commuter, Interstate and Overseas claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_4)

- 4.5 Ineligibility
             [4.5 Ineligibility](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_5)

- 4.6 Voluntarily Leaving Employment
             [4.6 Voluntarily Leaving Employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_6)

- 4.7 Income from Employment or Self-Employment (SE)
             [4.7 Income from Employment or Self-Employment (SE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_7)

- 4.8 Income Loss Requirement – Application
             [4.8 Income Loss Requirement – Application](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_8)

         [Chapter 4: Eligibility](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4)

- Chapter 5: Overpayments (OPs) and Write-offs

- 5.1 Commission Error
             [5.1 Commission Error](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_5_1)

         [Chapter 5: Overpayments (OPs) and Write-offs](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_5)

- Chapter 6: Reconsideration of an EI ERB claim under EIA 52

- 6.1 Reconsideration Policy of the EI ERB Paid
             [6.1 Reconsideration Policy of the EI ERB Paid](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_6_1)

- 6.2 Advance Payment Reconciliation
             [6.2 Advance Payment Reconciliation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_6_2)

         [Chapter 6: Reconsideration of an EI ERB claim under EIA 52](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_6)

- Chapter 7: Administrative Provisions
         [Chapter 7: Administrative Provisions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_7)

- Chapter 8: Employment Benefits and Support Measures
         [Chapter 8: Employment Benefits and Support Measures](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_8)

**EIA VIII.4 – EI Emergency Response Benefit**

**Introduction**

On March 25, 2020, the Government of Canada implemented the COVID-19 Emergency Response Act , which included measures to provide immediate supports to Canadians, including the Canada Emergency Response Benefit (CERB). The Canada Revenue Agency (CRA) and Service Canada delivered the CERB simultaneously; administering 2 separate pieces of legislation.
       [COVID-19 Emergency Response Act](https://laws-lois.justice.gc.ca/eng/AnnualStatutes/2020_5/)

- As part of the COVID-19 Emergency Response Act, the Government of Canada introduced the Canada Emergency Response Benefit Act that pays income support to eligible Canadians and is administered through the CRA.

- In order to provide similar support for workers who would generally be eligible for the EI program, amendments to the EI Act provided for a new EI Emergency Response Benefit (EI ERB) administered through Service Canada.

For simplicity for individuals, these 2 programs have been communicated publicly as one CERB. The objective was to ensure that Canadians applying for either income support through the Canada Emergency Response Benefit Act or the EIA were treated in a similar manner. To support the delivery of the program, applicants were directed to a single online portal that explained the eligibility criteria for the Government’s CERB. This portal asked a few specific questions and directed individuals to the appropriate department, the CRA or Service Canada, through which they should apply for income support. The EI ERB through Service Canada was the preferred payer for anyone who would otherwise qualify for EI.

Despite these efforts, there are individuals who applied through the “wrong” department (EI-eligible individuals applied at the CRA; or non-EI-eligible applied at Service Canada). However, in an effort to support Canadians, the Government decided these individuals would not be required to re-apply through the “proper” department. Instead, the departments will work out details directly, with no interruption in payments to clients, provided that (in accordance with EIA 153.11 ) the total number of weeks of benefits that a client receives does not exceed 28.
       [EIA 153.11](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.11.html)

**Chapter 1: Basic Concepts**

Even though EIA VIII.4 was introduced in response to the global pandemic COVID-19 on March 25, 2020, it retroactively came into effect on March 15, 2020. Part VIII.4 provided for the administration of the EI ERB, which was available between March 15, 2020 and October 3, 2020. EI Special benefits (other than sickness) continued to be administered under Part I of the Act, however new initial claims for EI Regular, Sickness and Self-Employed Sickness benefits were not established during this time as per EIA 153.8(5) and (6) , as EIAVIII.4 took precedence over EIA I [ EIA 153.3(8) ]. Moreover, EIA 153.1310 specifically provides for deeming claims established between March 15, 2020 and the date of signing of the Interim Orders authorizing EIA VIII.4, to be claims for the EI ERB.
       [EIA VIII.4](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242424) 
       [EIA 153.8(5) and (6)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html) 
       [EIA 153.3(8)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.3.html)

Other provisions of the EIA and EIR apply to EIAVIII.4 only if specified . Of note:

- The waiting period (WP) does not apply to the EI ERB.

- There are no availability provisions that apply to Part VIII.4 of the EI Act. A client is not required to be ready, willing and capable of working in order to receive the EI ERB. This being said, a client cannot delay in returning to work should there not be any barriers to doing so. It is understood that should the client be required to stay at home to care for their child/children during this time that is permissible.

- In many situations, the Reason for Separation from employment will be related to the COVID-19 pandemic. Clients are not eligible for the EI ERB if they leave their employment voluntarily ( Emergency Response Benefit Digest 4.5 ).
         [Emergency Response Benefit Digest 4.5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_5)

- The eligibility criteria for the EI ERB do not prevent an individual who was dismissed from collecting the benefit.

- There is no requirement that clients apply for the EI ERB in a timely manner; therefore, antedate requests are not applicable. No client is permitted to make a claim after December 2, 2020.

- An EI ERB claim cannot be considered when a client is seeking relief from a violation as it is not an initial claim for benefits under EIA I , VII.1 or VIII and therefore cannot be used as one of 2 EI claims to be relieved of an EI violation.
         [EIA I](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-2.html#h-215806) 
         [VII.1](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-18.html#h-217977) 
         [VIII](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-22.html#h-218633)

- Deductions for repayments (assignment of benefits [AOB]) cannot be applied to the EI ERB as the benefit is not assignable; however, deductions for family order agreements (FOAs) do apply.

EIA 153.10(2) allows clients to receive both an emergency response benefit from the Government of Canada as well as financial assistance related to COVID-19 from a provincial or territorial government for the same period.
       [153.10(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.10.html)

The EI ERB legislation ( EIA VIII.4 ) utilizes some existing Delegations of Authority from the EIA. Additional delegations were requested to address the creation of new and/or adapted legislation in the interim orders. The existing Levels of Decision apply.
       [EIA VIII.4](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242424)

**Chapter 2: Definition of Claimant**

Claimant is defined in EIA 153.5(2) , and includes 4 categories:
       [153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html)

- Those who ceased working due to COVID-19;

- Those who would have a benefit period (BP) established for EI Regular or Sickness benefits;

- Those who exhausted a claim for EI Regular benefits and were unable to start working due to COVID-19;

- Those who exhausted a claim for EI fishing benefits and were unable to start working due to COVID-19.

Each category of claimants must meet specific criteria pursuant to EIA 153.9 to be eligible for the EI ERB. Claimants may receive a payment of $500 for each week (up to 28 weeks) that they remain eligible for the EI ERB. EIA 153.10(3) confirms that the family supplement (FS) also applies to the EI ERB payments.
       [153.9](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html) 
       [153.10(3)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.10.html)

**Chapter 3: Claim Procedure**

EIA 153.8(1) states that clients must apply for the EI ERB in the form and manner established by the Minister every 2 weeks. While Part VIII.4 of the EIA does not include the concept of an initial claim for benefits nor the establishment of a BP, filing an initial claim in AW is part of administering the EI ERB. This provides Service Canada with the necessary information to start making the EI ERB payments, with the 2-week claimant’s reports serving as ongoing confirmation of the client s’ eligibility.
       [EIA 153.8(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

Clients are paid a weekly benefit rate of $500 for a maximum of 28 weeks and must demonstrate that they meet the eligibility criteria for each 2-week period that they are claiming benefits. If clients are unable to prove their eligibility for a specific 2-week period, they are not eligible for the EI ERB during that period.

The EI ERB can be paid for any 2-week period between March 15, 2020, and October 3, 2020. Clients are not required to apply in a timely manner, so antedate requests do not apply. However, per EIA 153.8(2) , claims cannot be filed after December 2, 2020. Clients must meet all eligibility criteria for the 2-week period. A 31 - EI ERB entitlement conditions not met disentitlement (D31) was created for periods of ineligibility for the EI ERB.
       [EIA 153.8(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html#docCont)

EIA 50 was adapted under EIA 153.1302 to apply to EIA VIII.4 and provide the authorization to request additional information when it is required to determine if a client is eligible for the EI ERB. If the client fails to provide that information, the client is considered not eligible.
       [EIA 50](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html) 
       [153.1302](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1302.html)

EIA 153.8(3) and (4) stipulate that a client and an employer, respectively, are required to provide any information that may be required in respect of a claim for the EI ERB. This authorizes the Commission to request additional information from a client and/or employer related to an EI ERB claim.
       [153.8(3) and (4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

When a claim for the EI ERB is received, the Commission is responsible for determining if the client is eligible for the period for which they are making a claim. EIA 153.8(7) states the Commission must ensure the client  is notified of the decision on the EI ERB claim. It also provides the Commission with the authority to choose the manner in which the client is notified.
       [EIA 153.8(7)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

**3.1 Alternate Form and Manner for Making an EI ERB Claim**

EIA 153.8(1) authorizes the Minister to determine the form and manner in which a claim is made. The usual form and manner of applying for the EI ERB was through the submission of 2-week claimant’s reports. Some clients made reasonable attempts to submit a claim for the EI ERB in the commonly established form and manner (bi-weekly report) but were prevented from doing so through no fault of their own. As a result, an alternate form and manner of applying for the EI ERB has been authorized to accommodate specific categories of clients:
       [153.8(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

- Clients who had a 71 – Integrity Services case manual action (MA71) imposed on their claim and their access code cancelled due to the suspicion of fraudulent activity on their EI ERB claim;

- Clients who filed a request for reconsideration relating to their EI ERB claim prior to December 2, 2020, but for which the decision had not been rendered prior to December 2, 2020;

- Clients who experienced processing delays outside of their control relating to their EI ERB claim.

The use of the alternate form and manner is rare and does not apply to most EI ERB claims. This decision is within Level 2 authority, but is only made by a group of specifically trained officers. The alternate form and manner is only considered for a claim that meets established conditions for the specific categories of claimants.

If officers become aware of a claim to which they believe the alternate form and manner could be applied, they must refer the claim to the Business Expertise Advisor in their region for distribution to the specifically trained officers, or for referral to EI Operational Policy.

**Chapter 4: Eligibility**

EIA Subsection 153.9(1) provides the applicable eligibility criteria  for each category of claimants.
       [Subsection 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

```text
| Definition of claimant | Eligibility |

| EIA 153.5(2) For the purposes of EIA 153.6 to EIA 153.13, the definition claimant in EIA 2(1) applies to a person: [153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html) [EIA 2(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-2.html) - who ceases working, whether employed or self-employed, for reasons related to COVID-19; [153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html) [EIA 2(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-2.html) | EIA 153.9 (1) A claimant is eligible for the employment insurance emergency response benefit [EIA 153.9 (1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html) - if they - reside in Canada, - are at least 15 years of age, - have insurable earnings of at least $5,000 in 2019 or in the 52 weeks preceding the day on which they make the claim under section 153.8, - whether employed or self-employed, cease working for at least seven consecutive days within the two-week period in respect of which they claimed the benefit, and - have no income from employment or self-employment in respect of the consecutive days on which they cease working; [EIA 153.9 (1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html) |

| - who could have had a benefit period established ( EIA 7(2) ) on or after March 15, 2020 with respect to any of the benefits referred to in paragraph (3)(a) [sickness, self-employed sickness and regular benefits]; [EIA 7(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.html) [EIA 7(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.html) | - if they are a claimant referred to in paragraph 153.5(2)(b) and they have no income from employment or self-employment for at least seven consecutive days within the two-week period in respect of which they claimed the benefit; or |

| - who is unable to start working for reasons related to COVID-19 and to whom, at any time during the period beginning on December 29, 2019 and ending on October 3, 2020, at least one benefit referred to in paragraph (3)(b) [ Regular benefits ] has been paid or was payable, if, during that period - the established benefit period of that person with respect to those benefits has ended, - all of those benefits have been paid to that person, or - some of those benefits cannot be paid to that person by virtue of subsection 12(6); or | - if they are a claimant referred to in paragraph 153.5(2)(c) or (d) and they - reside in Canada, - are at least 15 years of age, - have insurable earnings of at least $5,000 in 2019 or within the 52 weeks preceding the day on which they make the claim under section 153.8, and - have no income from employment or self-employment for at least seven consecutive days within the two-week period in respect of which they claimed the benefit. |

| - who is unable to start working for reasons related to COVID-19 and to whom, at any time during the period beginning on December 29, 2019 and ending on October 3, 2020, at least one benefit referred to in paragraph (3)(c) [ fishing benefits ] has been paid or was payable, if, during that period - the established benefit period of that person with respect to those benefits has ended, - all of those benefits have been paid to that person, or - some of those benefits cannot be paid to that person by virtue of subsection 8(18) of the Employment Insurance (Fishing) Regulations . [Employment Insurance (Fishing) Regulations](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-445) [Employment Insurance (Fishing) Regulations](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-445) | - if they are a claimant referred to in paragraph 153.5(2)(c) or (d) and they - reside in Canada, - are at least 15 years of age, - have insurable earnings of at least $5,000 in 2019 or within the 52 weeks preceding the day on which they make the claim under section 153.8, and - have no income from employment or self-employment for at least seven consecutive days within the two-week period in respect of which they claimed the benefit. |
```

It is possible that a claimant may meet more than one definition of a claimant. Once it is determined which section of EIA 153.5(2) is to be used, the corresponding entitlement conditions of EIA 153.9(1) and, if applicable, EIA 153.9(4), are then considered.

Scenario 1

- Claim (reporting) period: April 5 to 18, 2020

- Client is 14 years old and turns 15 years old on April 15, 2020

- Has 418 insurable hours

- Earned $5 000 in 2019

- Resides in Canada

- Stopped working because of COVID-19 (shortage of work) on April 3, 2020

- Has had no income from employment since April 3, 2020

- Meets definition of claimant under EIA 153.5(2)(a)

As the client has insufficient hours to be considered a claimant under EIA 153.5(2)(b), this is a claimant under EIA 153.5(2)(a). The client is not eligible week 1 (April 5 to 11, 2020) of the 2-week claim period as they do not meet all of the eligibility criteria (not 15 years of age or older).

The client is eligible week 2 (April 12 to 18, 2020) of the 2-week claim period as they now meet the eligibility criteria (turns 15 years old during the week).

Scenario 2

- Claim (reporting) period: March 15 to March 28, 2020

- Client is 14 years old

- Has 1 000 insurable hours

- Earned $7 000 in 2019

- Resides in Canada

- Stopped working because of COVID-19 (shortage of work) on March 13, 2020

- Has had no income from employment since March 13, 2020

- The client does meet the definition of claimant under EIA 153.5(2)(b) as the client could have established a BP on or after March 15, 2020 for Regular benefits

The client meets the eligibility criteria under EIA 153.9(1)(b) as the client has no income from employment since March 13, 2020 and meets the 7-day requirement of no income in the 2- week period of their claim for benefits.

In this scenario the client was not required to meet the age requirement as he met the definition of claimant under EIA 153.5(2)(b) and eligibility under EIA 153.9(1)(b) which does not have the same eligibility criteria as the other sections of this Act.

The client is payable for the 2-week period for which he made a claim.

**4.1 Reside in Canada**

The intent is for the EI ERB to be available to a person who makes Canada their home and who ordinarily lives here, even if it is for a limited period of time. Therefore, unlike EI Regular benefits, the EI ERB is available to a client who is temporarily outside of Canada, if they make Canada their home and ordinarily live here.

For the purpose of the EI ERB, the definition of reside in Canada should be applied to every 2-week period for which the client is requesting the benefit. A client could be considered to live in Canada for the duration of one EI ERB claim but not another. If the evidence on each side is equally balanced when determining if the client resides in Canada, the benefit of the doubt is given to the client.

A client’s physical location does not determine if they reside in Canada. Generally, an individual’s attachment to a country is measured by evaluating the residential ties that the individual has to that country. However, in order to make a determination that an individual resides in Canada, many factors have to be considered.

A person who is temporarily out of Canada could still be considered to reside in Canada as long as they maintained significant ties to Canada. Similarly, a person could be considered to reside in Canada for the duration of their stay in Canada even if they maintain significant ties abroad, as long as they made their home and ordinarily lived in any part of Canada during the period for which they are requesting the EI ERB.

The following are considerations that could support the client’s statement that they reside in Canada for the duration of their EI ERB claim:

- The client owns or rents a dwelling in Canada where they live.

- The client lives in the family home of friends or relatives.

- The client lives in a home provided by their employer.

- The client maintains a property in Canada (example: utilities, insurance, snow removal, etc.)

- The client has personal effects and/or furniture in Canada.

- The client has a Canadian mailing address and/or phone number.

- The client has coverage with a provincial health plan.

- The client  has a Canadian driver’s licence and/or vehicle registered in Canada.

- The client pays income tax as a resident of Canada.

- The client has immediate family members in Canada.

- The client works in Canada.

- The client has a bank account in Canada.

Examples

- Temporary foreign workers (900-series SIN) who worked in Canada, ceased working and stayed in Canada (eligible)

- Clients who reside in Canada while requesting EI ERB and move out of Canada while completing claimant’s reports (eligible and then not eligible)

- Clients with a primary residence in Canada who are out of Canada (eligible)

Scenario 1

- Claim (reporting) period: April 19 to May 2, 2020

- Client is 39 years old

- Has 395 insurable hours

- Earned $18 000 in 2019

- Resided in Canada until April 20, 2020; relocated to the United States on April 21, 2020, to stay with family as she cannot afford her rent while not working

- Stopped working because of COVID-19 (shortage of work) on March 20, 2020

- Has had no income from employment since March 20, 2020

- Meets definition of claimant under EIA 153.5(2)(a)

As the client has insufficient hours to be considered a claimant under EIA 153.5(2)(b), she is a claimant under EIA 153.5(2)(a). The client is eligible week one (April 19 to 25, 2020) of the 2-week claim period as she meets the eligibility criteria (resided in Canada) for a portion of that week, and we cannot determine her eligibility on a daily basis.

The client is not eligible for week 2 (April 26 to May 2, 2020) as she does not meet the eligibility criteria (not residing in Canada) for that period and does not meet the definition of claimant under any of the other category.

Scenario 2

- Claim (reporting) period: May 10 to 22, 2020

- Client is 35 years old

- Has 1 600 insurable hours

- Earned $95 000 in 2019

- Resided in Canada up to and including May 13, 2020; relocated to London, England on May 14, 2020, for a new work opportunity for which she is delayed in starting because of COVID-19

- Stopped working because of COVID-19 (shortage of work) on March 13, 2020

- Has had no income from employment since March 13, 2020

- Meets definition of claimant under both EIA 153.5(2)(a) and (b)

While the client is living in Canada, she is eligible for the EI ERB under 2 categories of claimant, both EIA 153.9(1)(a) and (b).

When the client relocates to London, England she no longer meets the definition of claimant under EIA 153.5(2)(a) because she no longer resides in Canada; however, she does continue to meet the definition of claimant under EIA 153.5(2)(b) as she could have established a regular EI benefits claim.

The client is eligible for both weeks of her 2-week claim period and as long as she continues to meet the eligibility criteria when making a claim for benefits, we can continue to pay the client because the entitlement conditions in EIA 153.9(1)(b) do not require residence in Canada.

**4.2 Ceased Working for Reasons Related to Covid-19**

A client is considered to have ceased working for reasons related to COVID-19 when they are no longer able to work, or return to work, because of COVID-19. A client who was in receipt of Maternity, Parental, Compassionate Care or Family Caregiver benefits who is unable to return to work following the end of their benefits for reasons related to COVID-19 is considered to have ceased working for reasons related to COVID-19.

**4.3 900 Series SINs and Work Permits**

Just as with Canadian citizens and permanent residents who apply for the EI ERB, 900-series SIN holders must satisfy the eligibility criteria in accordance with each category of claimants under EIA 153.5(2). Each category of claimants requires a valid SIN.

As temporary foreign workers and foreign students are often required to leave Canada when their SIN and/or period covered by their appropriate permit expires; proof of additional permit or authorization to remain in Canada legally may be required to prove eligibility. The same may apply to deem the required employment earnings insurable.

**4.4 Commuter, Interstate and Overseas claims**

Clients who traditionally apply for EI and are Commuter, Interstate or Overseas clients may be eligible for the EI ERB.

A client who resides in the United States and commutes to Canada for work may be eligible for the EI ERB, if they are among a category of claimants and meet the corresponding eligibility criteria.

A client who commutes to Canada for work but who resides in the United States may meet the definition of claimant under EIA 153.5(2)(b), as the client may have been otherwise able to establish a BP on or after March 15, 2020. The eligibility criteria for EIA 153.9(1)(b) requires a client to have no income from employment or SE for at least 7 consecutive days within the 2-week period for which they are claiming the benefit. If the client is considered eligible, prior to paying the client it would be confirmed that they are not in receipt of other benefits, as they may impact the client’s ability to collect the EI ERB.

**4.5 Ineligibility**

EIA 153.9(2) explains that a client is not eligible for the EI ERB if, for the same period
       [153.9(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

- they receive other EI benefits

- they receive benefits under the QPIP

- they receive an income support payment under the Canada Emergency Response Benefit Act or

- they receive a payment under the Canada Emergency Student Benefit Act

Clients who collect more than one benefit for the same period may have an overpayment (OP) and be required to repay their benefits. CERB payment details are available in FTS.

In accordance with EIA 153.9(2.1) , once a client converts from the EI ERB, or an income support program under the Canada Emergency Response Benefit Act , to another benefit type, they are no longer eligible for the emergency benefits. This prevents clients from switching back and forth between the emergency benefits and other EI benefits.
       [153.9(2.1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

EIA 153.121 confirms that, if a BP was established prior to March 15, 2020, this BP must end before the EI ERB can be paid.
       [153.121](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.121.html)

EIA 153.13 further confirms that, when a BP is established for a client who has received the EI ERB, the weeks in which the client collected the EI ERB do not count as weeks of EI benefits paid. The client will be able to receive their full entitlement to EI benefits provided they continue to meet all entitlement conditions for the benefit they requested.
       [153.13](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.13.html)

**4.6 Voluntarily Leaving Employment**

EIA 153.9(3) provides that a client who quits their employment is not eligible for the EI ERB.
       [153.9(3)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

On the basis of the similarities between EIA VIII.4 and EIA I, combined with the jurisprudence that exists on the concept of “voluntary leaving employment”, it is reasonable to conclude that EIA 153.9(3) would encompass not only those employees who strictly “quit” their employment, but those who refused employment, those who refused to resume employment or those who refused to continue in employment as described in EIA 29(b.1) .
       [29(b.1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-29.html)

Once it has been established that the client voluntarily left their employment, jurisprudence would support that the adjudication of voluntary leaving should give consideration to other basic concepts such as just cause and reasonable alternative.

A number of circumstances have been identified that contribute to a determination of just cause, including consideration of reasonable alternatives:

- what situation led to the voluntary separation;

- whether other measures or reasonable alternatives that could have remedied the situation existed and/or were exercised; and

- the client ’s reasons for not using what appear to be reasonable solutions.

In making this evaluation, fact-finding should be undertaken with all parties and, when the balance of probabilities is equal, the benefit of the doubt is given to the client.

Scenarios

- Refusal to Resume Employment: A client is not eligible for the EI ERB if they refuse to return to their former employment (including SE) when it is reasonable to do so and the employer requests their return. In order to assess whether or not the client has just cause to refuse the request to return to their former employment, several factors should be considered, such as: A client who has a compromised immune system, or who lives with someone who does, may have just cause for refusing to return to work. When a client is afraid to return to work but the alleged fear appears to be more of a perception than real, the refusal may be without just cause. The circumstances around any real or perceived dangerous condition, as well as the existence of any health and safety precautions, will need to be examined. There may be other situations related to COVID-19 beyond these examples for why a client may refuse to return to work and for this reason each case must be considered based on the client’s individual circumstances.

- were all health and safety protocols recommended by public health officials met in the workplace? If not, did the client discuss their concerns with the employer?

- were other options explored, such as working from home or the possibility of a different position discussed with the employer?

- were reasonable attempts made to secure alternate child-care arrangements if the usual care provider is not available? If there is space with the usual care provider, why has the client decided not to utilize it?

- are there health concerns that must be considered?

- Refusal to Accept a Reasonable Job Offer: A client is not eligible for the EI ERB if they decline a reasonable job offer when they are able to work. Where there has been a refusal of a reasonable job offer, the Commission should consider whether the client had just cause for refusing it. In order to assess whether or not the client has just cause, several factors should be considered, such as: A certain flexibility may be given when determining what constitutes a reasonable job offer due to the current economic climate and the fact that suitable jobs may be scarcer. What is considered reasonable will vary for each client.

- the nature of the occupation relative to the client’s normal occupation

- wage and employment conditions

- hours of work and whether they conflict with family obligations

- health and safety concerns related to COVID-19

- commuting distance and transportation method

- availability issues related to caring for a child or dependent because their care facility is closed or they are sick or in quarantine due to COVID-19

**4.7 Income from Employment or Self-Employment (SE)**

The determination of income

For the purpose of Part VIII.4 of the EIA, moneys are considered income when they fulfill 2 conditions: (1) the moneys arise from employment or SE and (2) the monies were earned during the period in respect of which the EI ERB is paid. Moneys paid for work that took place before the period for which benefits are claimed are therefore excluded.

To determine whether a specific payment is income for EI ERB purposes, it is necessary to obtain all relevant information regarding the nature of the payment, its origin and its purpose.

The following factors should be considered:

- Does the payment arise out of employment or SE?

- When was the money earned? Is it for the current period or a prior period of work?

- Who is making the payment? If it is someone other than the employer or, in the case of a self-employed individual, based on a contract, is there a direct link to the employment/work performed?

- Why is the payment being made? Is it to compensate for loss of income, such as a separation payment?

Income may include, among others:

- wages or salary

- business income

- non-eligible dividends

- tips

- commissions

- bonuses

- statutory holiday pay

- vacation pay (when paid as wages for a period of leave)

- honoraria (for example, nominal amounts paid to emergency service volunteers)

- royalties (for example, if they were received as compensation for using or allowing the use of a copyright, patent, trademark, formula or secret process that is a result of their own work or invention as paid to artists)

- non-pecuniary income arising from employment (for example, for housing or utilities)

- wage top-ups paid by the employer (registered supplemental unemployment benefit [SUB] plans do not apply to the EI ERB)

- insurable wage loss insurance (WLI)

Excluded from income, among others, are:

- money or financial aid of any type related to COVID-19 provided by the client’s province or territory, such as relief grants

- social assistance

- separation monies (including severance pay)

- pensions

- student loans

- bursaries

- royalties from investment activities (including dividends, interest)

Although different from the usual treatment of these monies for the purposes of EI, in order to avoid confusion for clients, and to align with the interpretation of income as it relates to the application of the CERB Act, disability benefits (including workers’ compensation benefits [WCB] and non insurable WLI), are excluded from income when determining eligibility for the EI ERB.
       [disability benefits](https://www.canada.ca/en/services/benefits/ei/cerb-application/questions.html#persons-disabilities)

How income is considered on the EI ERB claims

Eligibility criteria of EIA 153.9(1) include an income loss. More specifically, a client must have ceased working for at least 7 consecutive days within the 2-week period in respect of which they claimed the benefit and have no income from employment or SE in respect of those 7 days. Alternatively, if a client claimed a 2-week period, received the EI ERB but did not meet the income loss requirement of EIA 153.9(1) then EIA 153.9(4) is engaged to determine if the client is eligible for the EI ERB for that 2-week period.
       [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

In an effort to avoid OPs for clients as a result of a failure to meet the income loss requirement, whenever a client initially reported found work or worked a full work week (FWW), no EI ERB was paid for that week.

**4.8 Income Loss Requirement – Application**

In accordance with EIA 153.8(1), eligibility for the EI ERB is considered for 2-week periods, regardless of the sequence of claimant’s reports submitted.
       [EIA 153.8(1),](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242461)

Specifically in relation to work and earnings, each 2-week period is first assessed under EIA 153.9(1) to determine if the client:

- whether employed or self-employed, ceased working for at least 7 consecutive days within the 2-week period in respect of which they claimed the benefit, and

- had no income from employment or SE in respect of the consecutive days on which they ceased working.

The 7 consecutive day break can occur anywhere within the 14-day period under review.

If these conditions are met for the 2-week period under review, no further income assessment is required, and the client is eligible for and entitled to keep the EI ERB for that 2-week period.

If the client does not meet these conditions listed under EIA 153.9(1), then EIA 153.9(4) engages. If the client worked or had income during both weeks of the 2-week period under review, without a gap of 7 consecutive days of no work and no income, it must be determined if the income amounts to $1 000 or less over a 4-week period.

EIA 153.9(4) specifically talks about a 4-week period in which the EI ERB is paid . This means that the client was issued and received payment of EI ERB. Weeks where the advance payment was applied ( 65 – Lump Sum Payment [$2000] – Canadian Emergency Response code [D65]) or reconciled in a previous decision (refer to EI Emergency Response Benefit Digest section 6.2 ) is a week of the EI ERB paid. Weeks where payment was issued and an overpayment has been established for that week is considered a week paid if the client remains ineligible for benefits for that week.
       [EI Emergency Response Benefit Digest section 6.2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_6_2)

If EIA 153.9(4) is engaged, the 4-week period considered includes the 2-week period under review and the closest preceding 2 weeks where the EI ERB was paid.

Exception : If a FWW or found work prevented the payment of the EI ERB in the 2-week period under review, this unpaid week is not considered in the 4-week period and the closest preceding 3 weeks where EI ERB was paid are used.

Example :

```text
| Week | EI ERB paid | Period for which eligibility is being reviewed | 4-week period under EIA 153.9(4) |

| March 15, 2020 w/c 2230 | $500 | | |

| March 22, 2020 w/c 2231 | $500 | | 4 |

| March 29, 2020 w/c 2232 | $500 | | 3 |

| April 5, 2020 w/c 2233 | $500 | | 2 |

| April 12, 2020 w/c 2234 | $500 | Week 1 of 2-week period under review | 1 |

| April 19, 2020 w/c 2235 | $0 | Week 2 of 2-week period under review | |
```

As no EI ERB was paid in the week of April 19, 2020 (w/c 2235), this week is not considered in the 4-week period.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0272.dita) 

In the case where a claim results in a single week (generally the last week of EI ERB paid), this single week is considered using the same method as a 2-week period. If this single week does not have seven days with no work and no income, EIA 153.9(4) is engaged to determine if the income in that week, plus the closest preceding three weeks where the EI ERB was paid, exceeds $1 000.

If the client was not paid for any immediately preceding, consecutive chronological week(s), those are skipped, and the next preceding paid week(s) are used. It is possible that some weeks will be used in more than one 4-week period (i.e. there may be overlaps).

Determine if the income in the 4-week period exceeds $1 000

If the income exceeds $1 000 over the 4-week period, then the client is ineligible for the 2-week period being assessed and an OP is applicable for that period. No OP is created for the other 2-weeks used in the 4-week period as they would be subject to the assessment of the 2-week period in which they fall.

If the income is $1 000 or below, then the client is considered to have met the income loss requirement of EIA 153.9(1) and they are entitled to keep the EI ERB paid for the 2-week period being assessed .

The scenarios below demonstrate the application of EIA 153.9(1) and (4).

Scenario 1

In this scenario, the client received EI ERB for all weeks while reporting income in some weeks but not others.

The client is eligible for all weeks of EI ERB paid.

```text
| Week | EI ERB paid | Income | Eligible to EI ERB | 4-Week period |

| March 15, 2020 w/c 2230 | $500 | $0 | Yes | |

| March 22, 2020 w/c 2231 | $500 | $0 | Yes | |

| Eligible from March 15, 2020 to March 28, 2020 under EIA 153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| March 29, 2020 w/c 2232 | $500 | $200 | Yes | 4 |

| April 5, 2020 w/c 2233 | $500 | $0 | Yes | 3 |

| Eligible from March 29, 2020 to April 11, 2020 under EIA 153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| April 12, 2020 w/c 2234 | $500 | $100 | Yes | 2 |

| April 19, 2020 w/c 2235 | $500 | $699 | Yes | 1 |

| Ineligible under EIA 153.9(1) as the client did not have 7 consecutive days without work and income in the 2-week period. Eligible under EIA 153.9(4) as the income over the 4-week period (March 29, 2020 to April 25, 2020) is under $1 000. |
```

Scenario 2

In this scenario, the client received EI ERB while reporting income in some weeks but not others. The client was not initially paid in one week where a FWW was reported, however is eligible for benefits pursuant to EIA 153.9(1). Since the week of the FWW was not initially paid it is not considered in counting the 4-week period, and the income during that week is not considered when determining if the income loss requirement is met.

```text
| Week | EI ERB paid | Income | Eligible to EI ERB | 4-Week period |

| April 19, 2020 w/c 2235 | $500 | $0 | Yes | |

| April 26, 2020 w/c 2236 | $500 | $200 | Yes | 4 |

| Eligible under EIA 153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| May 3, 2020 w/c 2237 | $500 | $0 | Yes | 3 |

| May 10, 2020 w/c 2238 | $0 | FWW ($1 200) | Yes | |

| w/c 2238 was not originally paid but is eligible under EIA 153.9(1) as there are 7 consecutive days with no income during this 2-week period under review. This week will not count in the 4-week block as the EI ERB was not initially paid. The EI ERB owed for this period could be used to reconcile the advance payment. If the client has specifically requested a reconsideration of the FWW under EIA 112, the payment owing could be applied to an outstanding debt, or be issued as a payment to the client if there is no outstanding debt. |

| May 17, 2020 w/c 2239 | $500 | $400 | Yes | 2 |

| May 24, 2020 w/c 2240 | $500 | $300 | Yes | 1 |

| Ineligible under EIA 153.9(1) as the client did not have 7 consecutive days without work and income in the 2-week period. Eligible under EIA 153.9(4) as the income over the 4-week period (wc 2240, 2239, 2237 and 2236) is less than $1 000. |
```

Scenario 3

In this scenario, the client received the EI ERB while reporting income in some weeks but not others. The client was not paid for some weeks where FWWs were reported.

The client is not eligible for the period of May 17, 2020 to May 30, 2020 as the income during the 4-week period under review for determining eligibility for these 2 weeks exceeds $1 000.

```text
| Week | EI ERB paid | Income | Eligible to EI ERB | 4-Week period |

| April 19, 2020 w/c 2235 | $500 | $0 | Yes | 4 |

| April 26, 2020 w/c 2236 | $500 | $400 | Yes | 3 |

| Eligible under EIA 153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| May 3, 2020 w/c 2237 | $0 | FWW | No | |

| May 10, 2020 w/c 2238 | $0 | FWW | No | |

| Ineligible under EIA 153.9(1). EIA 153.9(4) is considered but does not apply as no EI ERB was paid during this 2-week period. As the EI ERB was not paid to the client, these weeks cannot count in a 4-week block when reviewing subsequent weeks of EI ERB paid. |

| May 17, 2020 w/c 2239 | $500 | $400 | No | 2 |

| May 24, 2020 w/c 2240 | $500 | $300 | No | 1 |

| Ineligible for this 2-week period only. Per EIA 153.9(1), the client did not have 7 consecutive days without work and income in this 2-week period. Ineligible under EIA 153.9(4) as the income over the 4-week period (w/cs 2240, 2239, 2236, 2235) exceeds $1 000. |
```

Scenario 4

In this scenario, the client received EI ERB while reporting income in some weeks but not others. The scenario demonstrates where the 4-week periods overlap. The client is ineligible under EIA 153.9(4) for only one of the 2-week periods under review.

The client is eligible for the period of April 19, 2020 to May 2, 2020 as the income in the 4-week period considered for that claim is less than $1 000. However, the client is not eligible for the period of May 3, 2020 to May 16, 2020 as the income in the 4-week period for that claim exceeds $1 000.

```text
| Week | EI ERB paid | Income | Eligible to EI ERB | First 4-Week period | Second 4-Week period |

| April 5, 2020 w/c 2233 | $500 | $200 | Yes | 4 | |

| April 12, 2020 w/c 2234 | $500 | $0 | Yes | 3 | |

| Eligible under EIA 153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| April 19, 2020 w/c 2235 | $500 | $100 | Yes | 2 | 4 |

| April 26, 2020 w/c 2236 | $500 | $699 | Yes | 1 | 3 |

| Per EIA 153.9(1) the client did not have 7 consecutive days without work and income in this 2-week period. Eligible under EIA 153.9(4) as the income over the 4-week period (w/cs 2236, 2235, 2234, 2233) is under $1 000. |

| May 3, 2020 w/c 2237 | $500 | $999 | No | | 2 |

| May 10, 2020 w/c 2238 | $500 | $999 | No | | 1 |

| Ineligible for this 2-week period. Per EIA 153.9(1), the client did not have 7 consecutive days without work and income in this 2-week period. Ineligible under EIA 153.9(4) as the income over the 4-week period (w/cs 2238, 2237, 2236, 2235) exceeds $1 000. |
```

Scenario 5

In this scenario, the client received the EI ERB while reporting income in some weeks but not others. It demonstrates how the 4-week periods overlap, and the client is eligible for benefits under EIA 153.9(4) for 2 different 2-week periods.

The client is eligible for the period of May 24 to June 6, 2020 as the income in the 4-week period for that claim is less than $1 000. The client is also eligible for the period of 2242 2243 as the income in the 4-week period for that claim is less than $1 000.

```text
| Week | EI ERB paid | Income | Eligible to EI ERB | First 4-Week period | Second 4-Week period |

| May 10, 2020 w/c 2238 | $500 | $200 | Yes | 4 | |

| May 17, 2020 w/c 2239 | $500 | $0 | Yes | 3 | |

| Eligible under EIA 153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| May 24, 2020 w/c 2240 | $500 | $100 | Yes | 2 | 4 |

| May 31, 2020 w/c 2241 | $500 | $200 | Yes | 1 | 3 |

| Ineligible under EIA 153.9(1) as the client did not have 7 consecutive days without work and income in the 2-week period. Eligible under EIA 153.9(4) as the income over the 4-week period (w/cs 2241, 2240, 2239, 2238) is under $1 000. |

| June 7, 2020 w/c 2242 | $500 | $100 | Yes | | 2 |

| June 14, 2020 w/c 2243 | $500 | $200 | Yes | | 1 |

| Ineligible under EIA 153.9(1) as the client did not have 7 consecutive days without work and income in the 2-week period. Eligible under EIA 153.9(4) as the income over the 4-week period (w/cs 2243, 2242, 2241, 2240) is under $1 000. |
```

Scenario 6

In this scenario, there is a gap in reporting due to a renewal. It demonstrates how EIA 153.9(4) should be applied when there is a 1-week period when a client ceases claiming the EI ERB as well as how it is applied when there is a gap between periods being claimed.

```text
| Week | EI ERB paid | Income | Eligible to EI ERB | First 4-Week period | Second 4-Week period |

| March 15, 2020 w/c 2230 | $500 | $0 | Yes | | |

| March 22, 2020 w/c 2231 | $500 | $200 | Yes | 4 | |

| Eligible under EIA153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| March 29, 2020 w/c 2232 | $500 | $0 | Yes | 3 | |

| April 5, 2020 w/c 2233 | $500 | $500 | Yes | 2 | 4 |

| Eligible under EIA153.9(1) as the client ceased working for 7 consecutive days within the 2-week period. |

| April 12, 2020 w/c 2234 | $500 | $500 | No | 1 | 3 |

| w/c 2234 is considered as a single week, rather than a 2-week period. Not eligible for this week under EIA 153.9(1) as there are not seven days with no work and no income. Not eligible for w/c 2234 under EIA 153.9(4) as the income over the four-week period (w/cs 2234, 2233, 2232 and 2231) exceeds $1 000. Gap in reporting following this week. |

| Renewal filed: May 31, 2020 w/c 2241 | $500 | $100 | No | | 2 |

| June 7, 2020 w/c 2242 | $500 | $100 | No | | 1 |

| w/c 2241 and 2242 are considered a 2-week period following a gap in reporting. Ineligible under EIA 153.9(1) as the client did not cease working for 7 consecutive days within the 2-week period. Ineligible under EIA 153.9(4) as the income over the 4-week period exceeds $1 000. |
```

**Chapter 5: Overpayments (OPs) and Write-offs**

EIA 43 , 44 and 47 apply to the EI ERB, with EIA 44 adapted under EIA 153.1301 and EIA 43 adapted under EIA 153.1306 . As a result, a client is liable to repay, without delay, any EI ERB amount to which they were not eligible.
       [EIA 43](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-43.html) 
       [44](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-44.html) 
       [47](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-47.html#docCont) 
       [153.1301](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1301.html) 
       [153.1306](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1306.html)

EIA 153.1306 (1) of the EI Act provides the Commission with the authority to write-off the EI ERB OPs if:
       [EIA 153.1306](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1306.html)

- the amount does not exceed $100;

- the debtor is deceased;

- the debtor is a discharged bankrupt;

- the debtor is an undischarged bankrupt in respect of whom the final dividend has been paid and the trustee has been discharged;

- the OP does not arise from an error made by the debtor or as a result of a false or misleading declaration or representation made by the debtor, whether the debtor knew it to be false or misleading or not, but arises from

- a retrospective decision or ruling made under Part IV, or

- provision by the Commission of a weekly employment insurance emergency response benefit amount in excess of the amount referred to in EIA 153.10(1) ; or
             [EIA 153.10(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.10.html)

- the Commission considers that, having regard to all the circumstances,

- the amount is uncollectable,

- the repayment of the amount would result in undue hardship to the debtor, or

- the administrative costs of collecting the amount would likely equal or exceed the amount to be collected.

Furthermore under EIA 153.1306(2) , the portion of an amount owing under EIA 47 in respect of the EI ERB received before the Commission notifies the debtor of the OP may be written off by the Commission if:
       [EIA 153.1306(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1306.html)

- the OP does not arise from an error made by the debtor or as a result of a false or misleading declaration or representation made by the debtor, whether the debtor knew it to be false or misleading or not; and

- the OP arises as a result of

- a delay or error made by the Commission in processing a claim for the EI ERB,

- retrospective control procedures or a retrospective review initiated by the Commission,

- an error made on the record of employment by the employer,

- an incorrect calculation by the employer of the debtor’s insurable earnings, or

- an error in insuring the employment or other activity of the debtor.

Unlike EIR 56(2), EIA 153.1306(2) does not include a requirement that 12 months have passed between when the benefits were received and the Commission notifies the client of the OP.

Service Canada has the delegated authority for write-off under EIA 153.1306(1)(e) and EIA 153.1306(2). For write-off requests under EIA 153.1306(1)(a) to (d) and (f), a client or their legal representative may contact the CRA to request that an OP be considered for write-off. The CRA will conduct a financial assessment of the debtor’s situation, then make a recommendation as to whether or not the OP should be written off to the Chief Financial Officer Branch (CFOB) who has the delegated authority for those sections.

It should also be noted that, in situations where an employer entered into a Work-Sharing (WS) agreement, and a client participating in this agreement was receiving the EI ERB, but the Commission continued to pay the EI ERB after the start of the WS agreement, any resulting OP after the required corrections are made to the claim should be written-off. This is because the Commission, as a party to the WS agreement, was aware of the agreement, but there was a delay in processing that information through the EI systems.

Furthermore, for clients who had a claim for EI benefits established on or after March 15, 2020, but who were later converted to the EI ERB on the date of signing of the Interim Orders authorizing EIA VIII.4, any benefit rate paid in excess of $500 per week is written off in accordance with EIA 153.1310(c)(ii).

As per EIA 153.1307 adapting EIA 112.1, a decision under EIA 153.1306 is not subject to reconsideration under EIA 112 .
       [EIA 153.1307](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1307.html) 
       [112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

**5.1 Commission Error**

A Commission error occurs when the Commission has all the relevant information needed to make a decision, but the final decision is not supported by the information. The error can occur in the adjudication process or in failing to enter a decision into the computer system.

An example of a Commission error would be continuing to pay the EI ERB to participants of a WS agreement. This would be considered a Commission error since all the necessary information was available to the Commission; however, the EI ERB continued to be paid rather than work sharing benefits.

Conversely, paying the EI ERB to a client who indicated their age was less than 15 when submitting their initial application is not a Commission error. At the time of application, the Commission does not know under which category of claimants they may be eligible. A claimant eligible under EIA 153.5(2)(a), (c) or (d) must be at least 15 years of age, whereas there is no age eligibility criteria for claimants under EIA 153.5(2)(b).

The client who completes a 2-week claimant’s report indicating that they exceeded the $1 000 earnings could be viewed as knowing they were not eligible for EI ERB based on the initial application of EIA 153.9(4). Similarly, the payment of the EI ERB when the client declared earnings on their claimant’s reports is not a Commission error.

If a Commission error resulted in a decision that is contrary to the structure of the EIA , the decision must be corrected retroactively and an OP established. The requirement to meet the definition of a claimant pursuant to EIA 153.5 and the associated eligibility criteria outlined in EIA 153.9 are considered “Structure of the Act” issues.
       [EIA](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/index.html)

**Chapter 6: Reconsideration of an EI ERB claim under EIA 52**

EIA 52 applies to the EI ERB, providing the Commission the authority to reconsider a claim for benefits to address a client’s eligibility and potential underpayment (UP) and OP of benefits.
       [52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

In the reconsideration process there are 4 distinct operations that must be completed within the timeframes set out in EIA 52. If any of the 4 operations cannot be completed within these timeframes, the Commission cannot reconsider the claim. These 4 operations are:

- decide whether or not to exercise its discretion to reconsider (i.e. the information presented warrants reconsideration; reconsideration will result in an OP or UP; there is enough time to complete the work);

- make the new decision;

- calculate the amount to be recovered or to be paid; and

- notify the client of the decision.

**6.1 Reconsideration Policy of the EI ERB Paid**

**6.1.1 Introduction**

This section is intended to clarify when an EI ERB claim or a decision on an EI ERB claim can be reconsidered while remaining consistent and fair.

**6.1.2 Legislative Authority**

Reconsideration is the means by which the EIA recognizes and responds to the fact that it may be necessary to amend or correct an EI ERB claim. Reconsideration is completed to ensure clients receive benefits to which they were eligible.

EIA 153.6(1) incorporates EIA 52 by reference, and thereby provides authority for the Commission to reconsider an EI ERB claim. While EI clients under EIA Part I have to qualify and be entitled to benefits, the EI ERB clients under Part VIII.4 have to be eligible for benefits. EIA 153.1303 modifies EIA 52(2) and (4) to reflect the concept of eligibility.

**6.1.3 When Reconsideration should occur**

Eligibility considerations

Individuals have to meet the eligibility criteria appropriate to the class of claimants applicable to them at the time they apply for benefits. Not all of the eligibility criteria apply to every class of claimants. More information on the criteria that apply to each category of claimants as well as ineligibility criteria can be found in EI Emergency Response Benefit Digest 4 .
       [4](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4)

A claim for the EI ERB could be reconsidered if any of the applicable eligibility criteria has not been met. It would be similar to the concept of contrary to the structure of the Act, which occurs when an element required to set up an EI claim and to pay benefits is missing.

For example, an individual belonging to the category of claimants under EIA 153.5(2)(a), (c) or (d) is required to be at least 15 years of age. These claims can be reconsidered and an OP established if the client has not met the age eligibility criteria. By contrast, a client belonging to the category of claimants under EIA 153.5(2)(b) is not required to meet a specific age requirement and reconsideration would not be applicable to that claim based upon that eligibility criteria.

Ineligibility considerations

A client who has received EI benefits, Quebec Parental Insurance Plan benefits, Canada Emergency Response Benefits or Canada Emergency Student Benefits is not eligible to receive the EI ERB for the same period. The EI ERB claim could be reconsidered and an applicable OP established if other benefits were paid for the same period. More information on these ineligibility criteria can be found in EI Emergency Response Benefit Digest 4.5 .
       [EI Emergency Response Benefit Digest 4.5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_5)

A client considered under EIA 153.9(1)(a) may not quit their employment, refuse to return to employment or refuse to accept employment without just cause as they are not eligible for the EI ERB. An EI ERB claim where the client has quit their employment without just cause could be reconsidered since they no longer meet this eligibility criteria. Similarly, a client in receipt of the EI ERB who refuses to accept or return to work without just cause could have their claim reconsidered and a possible OP established. EI Emergency Response Benefit Digest 4.6 defines what may constitute just cause as it applies to the EI ERB.
       [153.9(1)(a)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html#docCont) 
       [EI Emergency Response Benefit Digest 4.6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_6)

As per EIA 153.9(4), clients are not eligible for the EI ERB when they receive income exceeding $1 000 over a 4-week period for which the EI ERB was paid. EI Emergency Response Benefit Digest 4.7 provides an explanation of how the 4-week periods are determined as well as what is considered income. Clients who received the EI ERB when they were not eligible due to their earnings may have an OP established.
       [EI Emergency Response Benefit Digest 4.7](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_7)

**6.1.4 Underpayments (UPs)**

If the Commission denied benefits that are now deemed payable, the Commission must calculate the UP amount, notify the client of the reconsideration result and issue the amount owing to the client.

**6.1.5 Reconsideration Timeframe – 36 months vs 72 months**

EIA 52(1) provides that the Commission may reconsider a claim for benefits within 36 months after the benefits have been paid or would have been payable. However, the reconsideration window can be extended to 72 months if the Commission decides that a false or misleading statement or representation has been made in connection to the claim.

Advance Payment

The date the advance payment was paid is used to determine the 36-month reconsideration timeframe when there are no weeks to which the advance payment was assigned. When claimant’s reports were processed with a D65, assigning the advance payment to specific weeks, then these weeks are considered the weeks that benefits are payable and are used to determine the reconsideration timeframe (refer to EI Emergency Response Benefit Digest 6.2 for more information on the advance payment).
       [EI Emergency Response Benefit Digest 6.2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_6_2)

**6.1.6 False or Misleading Statement**

A false statement is made when any of the information submitted in connection with a claim is untrue, regardless of the intent. Part VIII.4 of the EIA does not provide for penalties or misrepresentation for an EI ERB claim; therefore, none can be imposed. The purpose of determining if a false statement was made in the context of an EI ERB claim is strictly to ensure the appropriate reconsideration timeframe is utilized. This is a discretionary decision, and a Record of Decision (ROD) must be completed to support this decision.

Clients have a responsibility to know what they are applying for and if they meet the eligibility criteria. Some clients applied for the EI ERB through Service Canada while others applied for the benefit through the CRA. The Government decided that benefits should be paid as quickly as possible, with validation of the information submitted for claims after the fact. As of April 1, 2020, information was available on Canada.ca to Canadians describing the Canada Emergency Response Benefits (CERB), referred to as EI ERB when received from Service Canada, and its eligibility criteria. By May 25, 2020, the Internet Reporting Service (IRS) was also updated with an “Attestation page” where EI ERB clients were required to confirm meeting the eligibility criteria before completing and submitting their bi-weekly internet EI ERB claims.

Clients attested on each bi-weekly report (claim) that they were eligible for benefits and therefore benefits were paid. Clients who claimed benefits when they were ineligible or provided false information when applying for benefits or completing their bi-weekly claims, should have their claims reconsidered.

A false statement does not have to have been knowingly made in order for the reconsideration timeframe to be extended to 72 months, the simple fact that an error was made is sufficient to extend the timeframe.

It is important to note that a false or misleading statement must be present in connection with each claimant’s report for the period being examined in order to justify the extension of time after a period of 36 months has elapsed.

If the EI ERB claim (claimant’s reports) does not contain a false statement, the reconsideration timeframe may be extended to 72 months if a false statement was made on the initial application for benefits or the attestation, submitted via AW, that resulted in the EI ERB period being established.

The fact that the EI ERB claims were established by a utility does not come into play when determining if reconsideration should occur or not. This is no different than the EI computer application and payment systems.

**6.2 Advance payment reconciliation**

**6.2.1 Introduction**

This policy provides guidance regarding the EI ERB advance payment reconciliation and the circumstances under which the OP may be offset.

While the usual form and manner of applying for the EI ERB was through the submission of 2-week claimant’s reports, EIA 153.8(1) also authorizes the Minister to determine the form and manner in which a claim is made. This policy creates an alternate form and manner to apply for the EI ERB to demonstrate eligibility for the advance payment only. No monies are to be directly issued to the client in respect of the EI ERB because of this advance payment reconciliation. The December 2, 2020, [EIA 153.8(2)] legislative deadline has passed to apply for the EI ERB.
       [EIA 153.8(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

EIA 153.7(1) states that the EI ERB is payable to a client who makes a claim under EIA 153.8 and who is eligible for the benefit.
       [153.7(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.7.html) 
       [153.8](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

EIA 153.7(1.1) allowed the Commission to pay the EI ERB in advance of the customary time for paying it. This section was modelled after EIR 28 , authorizing the Commission to pay benefits for a week of unemployment in advance in certain specific circumstances.
       [153.7(1.1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.7.html) 
       [EIR 28](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-28.html)

The way the EI ERB is normally paid is through reimbursement when the client completes claimant’s reports under EIA 153.8(1) .
       [153.8(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

**6.2.2 Background**

During the period between March 15, 2020 and September 26, 2020, no EI regular or sickness BPs were established [ EIA 153.8(5) ]; rather all claims made for regular or sickness benefits during that period were deemed to be claims for the EI ERB [EIA 153.5(2) and EIA 153.8(1)]. Clients whose claims were finalized before June 15, 2020 received an advance payment of $2 000 immediately upon the processing of their application, representing 4 weeks of the EI ERB. This payment [authorized in EIA 153.7(1.1) ] ensured that, regardless of whether Canadians applied for assistance through the CRA or Service Canada, their initial payment was the same. Following the advance $2 000 payment, clients had to continue to complete 2-week claimant’s reports to demonstrate their ongoing eligibility for the EI ERB. Annex 1 of the EI ERB – BE 2020-04 further explains the advance payment. The maximum number of weeks payable of the EI ERB was 28.
       [EIA 153.8(5)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html) 
       [153.7(1.1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.7.html) 
       [EI ERB – BE 2020-04](https://ort-orl.esdc-edsc.canada.ca/en/policy/bememo/be2020-04.shtml)

The administrative code D65 was introduced to prevent payment in order to apply the equivalent of one week ($500) of the advance payment received to specific weeks of the EI ERB. Once the weeks paid counter on the EI ERB claim reached 12 weeks, a 2-week D65 was imposed immediately following. A second 2-week D65 was imposed immediately following 17 weeks paid. However, the D65 may or may not have been served, depending on the number of weeks of the EI ERB clients claimed (based on the filing of the claimant reports). Information: COVID-19—Initial $2,000 payment and new D65 provides further information.
       [Information: COVID-19—Initial $2,000 payment and new D65](/en/site/dossier/information_covid19_initial_2000_payment_new_d65.shtml)

The Commission has undertaken an advance payment reconciliation, and any applicable OP has been established. The reconciliation ensures that, for each client who received the advance payment, the number of weeks of the EI ERB paid matches the number of weeks of eligibility, based on the claimant’s reports received, to a maximum of 28 weeks. The resulting OPs range from $500 to $2 000 depending on how many weeks of D65 were served. The Notice of Debts for these OPs were issued from November 2021. A D65 is considered served if claimant’s reports were processed and the EI ERB was payable for that week. The EI ERB was not paid in a week where there was a full week disentitlement, a FWW declared, or the client declared a RTW on the Sunday or Monday of the week.

**6.2.3 Application**

Information provided at the onset of the pandemic may have confused clients because, regardless if they applied through the CRA or Service Canada, they received an initial payment of $2 000. For simplicity, the measure for immediate support to Canadians was communicated as one CERB. However, the CRA and Service Canada administered 2 separate pieces of legislation, which, while intending to be as symmetrical as possible, had different rules.

Completing an initial application in AW was part of Service Canada’s administration of the emergency benefit, and it provided the Commission with the necessary information to start making the EI ERB payments. The 2-week claimant’s reports served as ongoing confirmation of the client’s eligibility, after which the client was paid. However, with the CRA, the application itself generated the first payment and a separate application had to be made for every following 4-week period. Furthermore, while the CRA model was designed to pay in advance, Service Canada leveraged EI systems, which are designed to pay in arrears.

Though contrary to the intent set out under EIA 153.8(1) , these clients may not have realized the need to complete their claimant’s reports, which were required to confirm their eligibility to the advance payment. Alternatively, some clients, being knowledgeable EI users who understood the need for bi-weekly reporting and the link between the claimant’s reports and payment, purposefully may not have completed their claimant’s reports (or not for the entire period) so as not to be overpaid.
       [153.8(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

Example 1:

A client applies for benefits through Service Canada on March 24, 2020 (w/c 2231);

- Last day worked (LDW) March 20, 2020 (w/c 2230).

- Application is finalized April 4, 2020 (w/c 2232).

- Advance payment of $2 000 is paid April 6, 2020 (w/c 2233).

- No claimant’s reports completed.

- Returns to work April 20 (w/c 2235).

From the client’s perspective, the client was unemployed for 4 weeks, completed an application and received 4 weeks of the EI ERB (i.e., the $2 000 advance payment). However, without claimant’s reports completed for the full period of unemployment, the Commission cannot confirm eligibility for those benefits. If the client had completed the claimant’s reports, the client would have received an additional $2 000, resulting in a total payment of $4 000 for a 4-week period of unemployment (when the client was only entitled to $2 000).

If that same client had applied for the CERB through the CRA, the $2 000 would have been applied to the 4-week period of March 15 to April 10. No further actions were required of the client.

Example 2:

A client applies for benefits through Service Canada on March 24, 2020 (w/c 2231);

- LDW March 20, 2020 (w/c 2230).

- Application is finalized April 4, 2020 (w/c 2232).

- Advance payment of $2 000 is paid April 6, 2020 (w/c 2233).

- Completed reports from March 22, 2020, to April 18, 2020 (w/c 2231 to w/c 2234, for 4 consecutive weeks).

- Returns to work May 17, 2020 (w/c 2239).

From the client’s perspective, the client was unemployed for 8 weeks, completed an application and 2 2-week claimant’s reports (i.e. 4 weeks declared), and received 8 weeks of the EI ERB (i.e. the $2 000 advance payment plus 2 biweekly payments). However, without claimant’s reports completed for the full period of unemployment (a total of 8 weeks), the Commission cannot confirm the client’s eligibility to the EI ERB. If the client had completed the claimant’s reports, the client would have received an additional $2 000, resulting in a total payment of $6 000 for an 8-week period of unemployment (when the client was only entitled to $4 000).

If that same client had applied for the CERB through the CRA, the client would have completed 2 applications, and received $4,000 for the 4-week periods of March 15 to April 10 and April 11 to May 8. No further actions were required of the client.

EIA 153.7(1) prescribes that an EI ERB payment is only payable to a client who makes a claim under EIA 153.8 . A strict application of this legislation in the above examples would mean these clients did not meet the criteria to be eligible for the advance payment, as they did not make claims for the whole period. Therefore, the OP resulting from the advance payment reconciliation is appropriate.
       [153.7(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.7.html) 
       [153.8](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

However, the application of the D65 to the 2 weeks following the 12th week paid, and then to the 2 weeks after the 17th week paid was an administrative decision. In the interest of client service and in order to reconcile the advance payment for weeks the client would otherwise have been eligible, but for which there was no completed claimant’s reports, the Commission will accept the following to support eligibility to the advance payment for up to 4 weeks of the EI ERB:

- there is indication on file that the client did not understand the requirement to complete claimant’s reports in the context of receiving EI ERB and it is determined that had the client completed the reports, it would have resulted in the client being overpaid.

- there is indication on file that the client was aware that the completion of claimant’s reports would have resulted in further payments which would have resulted in the client being overpaid and the client deliberately did not complete the claimant’s reports as a result.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0273.dita) 

Every effort must be made to provide the client the opportunity to declare their eligibility, and the advance payment OP should be reconciled whenever possible. This reconciliation assigns $500 of the advance payment OP to a specific week deeming that week to have been paid as payment had already been issued.

The weeks of the EI ERB eligibility must be within 8 weeks of:

- the LDW as indicated on the application or the date of application (for those where no reports have processed); or

- the period for which the last claimant’s report was processed

There may be situations where the client indicates eligibility beginning in a week that does not align with what is in the system. While the EI system was used to pay the EI ERB, the concept of an initial claim for benefits or the establishment of a BP were not provisions incorporated or adapted in EIA VIII.4 . Therefore, clients may be able to prove eligibility and be considered otherwise payable for a week prior to what is showing as the BPC in the system.
       [EIA VIII.4](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-28.html)

Example 3:

A client applies through Service Canada on March 19, 2020 (w/c 2230):

- LDW March 18, 2020 (w/c 2230).

- Application is finalized April 4, 2020 (w/c 2232).

- BPC established March 22, 2020 (w/c 2231).

- Advance payment of $2 000 is paid April 6, 2020 (w/c 2233).

- No claimant reports completed.

- Returned to work April 10, 2020 (w/c 2233).

- Earnings reported when fact-finding to apply advance payment OP reconciliation:

- Week of March 15, 2020 (w/c 2230) $500

- Week of April 5, 2020 (w/c 2233) $63

From the client’s perspective, the client was unemployed for 4 weeks, completed an application and received 4 weeks of the EI ERB. However, without the claimant’s reports for the full period of unemployment, the Commission cannot confirm eligibility to the EI ERB. If the client had completed the claimant’s reports, the client would have received an additional $2 000, resulting in a total payment of $4 000 for a 4-week period of unemployment (when the client was only eligible to $2 000).

If that same client had applied for CERB through the CRA, the $2,000 would have applied to the 4-week period of March 15 to April 10. No further actions were required of the client.

When officers complete the fact-finding with clients regarding the advance payment OP reconciliation, clients must report any income received for the period requested to offset their advance payment OP, including the CERB or monies paid from the employer (e.g. the Canada Emergency Wage Subsidy).

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0274.dita) 

Example:

In this example, the client submitted their first 2 claimant’s reports and was paid 3 weeks of EI ERB. They also received the $2 000 advance payment. As they did not submit sufficient claimant’s reports to demonstrate eligibility for the advance payment, a $2 000 OP was created. The client now wishes to submit further claimant’s reports in order to reconcile the advance payment.

```text
| Week | EI ERB initially paid | Income | Eligible under EIA 153.9(1) | First 4-Week period | Second 4-Week period | Eligible under EIA 153.9(4) | Amount to reconcile |

| March 15, 2020 (w/c 2230) | $500 | $0 | Yes | | | | |

| March 22, 2020 (w/c 2231) | $500 | $0 | Yes | | | | |

| March 29, 2020 (w/c 2232) | $500 | $0 | Yes | 4 | | | |

| April 5, 2020 (w/c 2233) | $0 | $200 | Yes | 3 | 4 | | $500 |

| The client is eligible for benefits in w/c 2233 under EIA 153.9(1) as they have 7 consecutive days with no work and no income during this 2 week period. They were not previously paid EI ERB for this week, and therefore $500 can be reconciled. |

| April 12, 2020 (w/c 2234) | $0 | $200 | No | 2 | 3 | Yes | $500 |

| April 19, 2020 (w/c 2235) | $0 | $200 | No | 1 | 2 | Yes | $500 |

| The client is eligible for benefits in w/c 2234 and 2235 under EIA 153.9(4). They do not have seven days with no work and no income, however their earnings in the 4-week period are less than $1 000. $500 can be reconciled for each week. |

| April 26, 2020 (w/c 2236) | $0 | $200 | No | | 1 | Yes | $500 |

| The client is eligible for benefits in w/c 2236 under EIA 153.9(4). They do not have seven days with no work and no income, however their earnings in the 4-week period are less than $1 000. $500 can be reconciled for this week. w/c 2237 is not reviewed as the advance payment OP is fully reconciled. No additional EI ERB payments can be made, therefore this week is not processed. |
```

If the client reports income for the period that they are requesting to offset part or the entire advance payment, refer to the EI Emergency Response Benefit Digest 4.8 , to ensure that the client meets the income loss requirements to be eligible for the EI ERB prior to using these weeks to offset the advance payment OP.
       [EI Emergency Response Benefit Digest 4.8](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/generic/ei_erb_digest#ch_4_8)

The client’s eligibility to the EI ERB could be subsequently reconsidered and the OP re-established, if any of the other eligibility criteria are not met.

The advance payment OP is reconciled according to the original OP amount. After the OP has been offset, if the client made a payment or a recoupment was applied, the client is refunded any applicable credit amount.

EIA 44 allows the Commission to accept and retain benefit payments that the client voluntarily returned. Clients who meet the criteria to have the advance payment OP reconciled are considered to have proven entitlement to those benefits, removing the liability to repay. The Commission is not entitled to retain any amount exceeding the liability therefore the excess must be returned to the client.

**6.2.4 Write-off of an Advance Payment**

When a decision results in an OP of the EI ERB, the Commission must determine if a write-off provision applies per EIA 153.1306 .
       [EIA 153.1306](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.1306.html)

As the Commission had the authority to issue an advance payment, the payments are not a Commission error. The onus was on the client to prove eligibility for the advance payment by completing claimant reports. Since the OP arises from having received more benefits than one is eligible for based on the claimant reports completed, the write-off provisions under EIA 153.1306(2) do not apply.

**Chapter 7: Administrative Provisions**

EIA VI applies to Part VIII.4, with adaptations as appropriate ( EIA 153.6(1) and (2) and EIA 153.1305 ).
       [EIA VI](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-15.html#h-217634) 
       [EIA 153.6(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242452) 
       [EIA 153.1305](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-24.html#h-1257875)

Section 111 of the EIA allows the Commission to amend or rescind a decision, when new facts are presented or when a decision was made without knowledge of, or based on a mistake as to, some material fact. This may also result in an OP or UP of benefits.
       [111](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-111.html)

For the purpose of EIA 111,

- a new fact is a fact that either happened after a decision was rendered or had happened prior to a decision but could not have been discovered by a client acting diligently. In both cases the new fact must have some fundamental impact on a decision.

- a material fact is a fact that is significant or essential to the issue or matter at hand; therefore, a material fact is any information that does, or may, influence the outcome of the decision-making process.

Not to be confused with EIA 52 , clients or employers may also request formal reconsideration under EIA 112 when they disagree with a decision.
       [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 
       [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

Clients or employers who disagree with a decision rendered by the Commission have 30 days from the date that the decision is communicated to them to submit a request for reconsideration. If the request for reconsideration was not submitted within 30 days, a reason for the delay must be provided. The Commission may allow a longer period if it is satisfied that there is a reasonable explanation for the late reconsideration request.

Reconsideration under EIA 112 is a legislated process with clients or employers seeking to have the Commission conduct a formal, exhaustive review of one or more of its decisions and to issue a final decision(s). Upon receipt of a request for reconsideration, the Commission must reconsider the decision(s) identified and notify the client/employer of the outcome.

It is this final Commission decision that can be challenged through an appeal to the SST.

Note that, pursuant to EIA 153.121(2) , if a reconsideration under EIA 112 results in a BP being established before March 15, 2020, and the client has already been paid the EI ERB, the client is deemed to have not been eligible for the EI ERB. The EI ERB claim would be replaced with an EI BP.
       [EIA 153.121(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.121.html)

Under EIA 113 , a client or employer who disagrees with a decision that has been reconsidered under EIA 112 can file an appeal with the Social Security Tribunal – General Division. The appeal must be in writing and must be received by the Tribunal within 30 calendar days of receipt of the reconsideration decision.
       [EIA 113](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-24.html#h-217634)

If the client or employer disagrees with the decision rendered by the Social Security Tribunal – General Division (SST-GD), they may submit an appeal to the SST-AD. Again, the Tribunal must receive the appeal within 30 calendar days of the client or employer receiving the SST-GD’s decision.

The Commission can no longer reconsider an issue under EIA 52 , or amend a decision under EIA 111 , once the issue is under appeal at the SST.

**Chapter 8: Employment Benefits and Support Measures**

Part II of the EIA applies to Part VIII.4 ( EIA 153.6(1)(b) ).
       [Part II](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-14.html#h-216770) 
       [EIA 153.6(1)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-23.html#h-1242452)

A client who receives financial assistance under employment benefits (Part II) remains eligible to receive the EI ERB.

An insured participant includes a client who receives the EI ERB ( EIA 58 ).
       [EIA 58](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-58.html) 

### Note

Source topic: `en_EN/common_notes/note_c_0272.dita`

Note:

If there is no EI ERB paid in either week of a 2-week period due to FWW or Found Work, then the client does not meet the conditions listed under EIA 153.9(1), nor can EIA 153.9(4) be applied, since in the decision of Canada Employment Insurance Commission v. HM (AD-23-50), the Social Security Tribunal – Appeals Division (SST-AD) confirmed that the 4 weeks to be considered for EIA 153.9(4) must include the 2-week claim period for which eligibility is being determined. In this case, since neither of the weeks were paid, EIA 153.9(4) cannot be applied, and the client cannot be eligible for the 2-week period in question. 

### Note

Source topic: `en_EN/common_notes/note_c_0273.dita`

Note:

If there are weeks where claimant’s reports were submitted, but EI ERB was not paid due to a FWW, these weeks must be reviewed for potential eligibility first before new claimant’s reports are input. These weeks may be used to reconcile the advance payment OP. 

### Note

Source topic: `en_EN/common_notes/note_c_0274.dita`

Note:

If the client received the CERB, the client is not eligible for the EI ERB for the same period. In this case the officer does not apply this policy. [EIA 153.9(2)(c)] 
