# Postdate Policy

Source map: `en_EN/policy/nationalpolicy/national_policy_on_postdates/national_policy_on_postdates.ditamap`

## Introduction

Source topic: `en_EN/policy/nationalpolicy/national_policy_on_postdates/introduction.dita`

Table of Contents

- 1. Introduction
         [1. Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#intro)

- 2. Policy Objective
         [2. Policy Objective](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#policy_obj)

- 3. Postdating a claim
         [3. Postdating a claim](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#postdating_claim)

- 4. Administrative Policy and Postdating

- 4.1 Example
             [4.1 Example](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#example)

         [4. Administrative Policy and Postdating](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#administrative_policy_posdating)

- 5. Responsibilities

- 5.1 National Headquarters
             [5.1 National Headquarters](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#5_1_nh)

- 5.2 Regions and Call Centres
             [5.2 Regions and Call Centres](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#5_2_regions_call_centres)

         [5. Responsibilities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_on_postdates#responsibilities)

**1. Introduction**

EIA 10(1) informs the Commission when a benefit period (BP) may be established:
       [EIA 10(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/page-2.html#h-215911)

- A benefit period begins on the later of

- the Sunday of the week in which the interruption of earnings occurs, and

- the Sunday of the week in which the initial claim for benefits is made.

Historically, a strict interpretation of the above wording meant a client would have to submit a new application in any situation in which they want their claim to start at a later date. Therefore, to offer better service to clients and to remove the burden of reapplying for benefits, the Commission introduced the Postdate Policy.

The Postdate Policy does not replace the EIA, but is intended to supplement it. A claim should only be established under the Postdate Policy when it is to the client’s advantage and when one of the specified situations applies.

**2. Policy Objective**

Under the Postdate Policy, the client is not required to reapply to have the BP start at a later date when the reason for the postdate is one of the specified situations provided below.

**3. Postdating a claim**

A claim is considered to have been postdated when the BP is established at a date later than EIA 10(1) or the Administrative Policy would allow.
       [Administrative Policy](/en/policy/nationalpolicy/administrative_policy.shtml)

A BPC can be postdated up to 4 weeks, but it cannot be postdated beyond the current variable entrance requirement (VER) range. Given a renewal claim already has an established BPC, the renewal week cannot be postdated more than 4 weeks.

A claim cannot be postdated solely for a client to benefit from new legislation, unless otherwise communicated and authorized by EI Operational Policy.

The following circumstances establish when it may be advantageous to postdate an initial or renewal claim; at least one of the following must apply to postdate the claim:

- The client requires the hours of insurable employment from the last week worked in order to qualify for benefits.

- The week of the interruption of earnings (I of E) or the week of application is a full work week (FWW).

- The client would only be entitled to a partial first payment because of earnings in the week of the I of E and has requested the claim be postdated by one week.

- Separation monies or earnings, or a combination of both, in the week of the I of E or the week of application are equal to or greater than the benefit rate.

- For maternity and parental benefits: the client applied prior to the beginning of the benefit window.

- For special benefits: the client can receive the maximum entitlement, but earnings during the first week prevent payment of the full benefit rate.

- For teachers only: the client may be entitled to a contractual payment from their employer, in addition to a supplemental unemployment benefits (SUB) top-up for maternity and parental benefits. The payment parameters vary among provinces (during teaching or non-teaching periods), but these particular monies are considered earnings and prevent payment of EI benefits for those weeks, as they do not meet the criteria for SUB. A postdate could be to the client’s advantage, but attention must be paid to both the maternity window and parental window to ensure maximum entitlement remains available.

- For fishers only: the client submitted their summer or winter fishing claim before a BP for that claim type could be established, but within the current VER range.

- For benefits for self-employed people only: the client applies before their agreement has been in place for one year, so they are not entitled to benefits. If the date they become eligible to request benefits is within 4 weeks from the date they submitted their application, the claim can be postdated for up to 4 weeks.

In order to prevent the client from having to submit a second application for EI benefits, if the client has worked since the date of the initial application and requires those hours to qualify for benefits, the additional hours can be used to establish the BP. In order to use the additional hours to qualify for benefits, the BPC must be based on the most recent I of E, and the ROE and any other relevant employment information must be provided. If the initial decision has already been made, the client must reapply.

**4. Administrative Policy and Postdating**

Establishing a claim is a step-by-step process. First, it must be determined if the application was submitted in a timely manner ( Administrative Policy ). Then, it must be determined in which week the BP should be established.
       [Administrative Policy](/en/policy/nationalpolicy/administrative_policy.shtml)

When establishing the BP, postdating the claim may be to the client’s advantage. Postdating the claim is a separate decision that can only be made when the reason for postdating the claim is one of the situations specified above. In all other situations, the client must reapply.

The Administrative Policy and the Postdate Policy are 2 distinct policies that are often confused and combined. It is imperative to distinguish between the 2 to properly apply each of them.

**4.1 Example:**

- The I of E and last day paid (LDP) occurred in w/c 2275.

- The client has requested sickness benefits.

- The earnings in w/c 2275 are $450.

- The ROE indicates sickness as the reason for separation (RFS).

- The client provided a medical certificate with a recovery date of w/c 2293-5

- The client applied in w/c 2278.

- The benefit rate is $550.

According to the Administrative Policy, the application was submitted in a timely manner because the client applied within 4 calendar weeks of the I of E.

The Postdate Policy states a claim can be postdated in this situation because:

- For special benefits: the client can receive the maximum entitlement, but earnings during the first week prevent payment of the full benefit rate.

In this scenario, postdating the claim would be to the client’s advantage. The BP is therefore postdated to w/c 2276.

**5. Responsibilities**

**5. 1 National Headquarters**

National Headquarters is responsible for developing and applying this policy. It is also responsible for developing and maintaining processes, tools and procedures, as well as developing training for policy implementation.

**5.2 Regions and Call Centres**

Regional EI Processing and Payment Directors and Managers, Regional Integrity Services Directors and Managers and EI Call Centre Directors and Managers are responsible for ensuring implementation of the policy, and for ensuring no deviations are made without the express consent of the EI Operational Policy Director. 

## Background

Source topic: `en_EN/policy/nationalpolicy/national_policy_on_postdates/background.dita`

## Untitled

Source topic: `en_EN/policy/nationalpolicy/national_policy_on_postdates/untitled.dita`

 
