# Levels of Decision – Annex 1

Source map: `en_EN/policy/nationalpolicy/levels_decision-annex1/levels_decision-annex1.ditamap`

## Introduction

Source topic: `en_EN/policy/nationalpolicy/levels_decision-annex1/introduction.dita`

**Level 2 decisions delegated to Level 1**

Annex 1 does not list all Level 1 decisions. It is a list of authorities that are delegated to Level 2 officers in the Employment Insurance Table of Authorities that have now also been delegated to Level 1 through the Levels of Decision Policy. In order for a Level 1 officer to have the authority to render a decision under this policy, the specific conditions listed in the policy must be met and the officer must have the required skills and training.
       [Employment Insurance Table of Authorities](https://iservice.prv/eng/finance/DELEG/effective/ei/employment_insurance_table_authorities.pdf)

Officers refer all issues for family caregiver benefits (FCB) and certain issues for compassionate care benefits (CCB) to the appropriate specialized processing unit. This does not include conversions from FCB or CCB to other benefit types (BTs).

Updated October 21, 2025

Table of contents

- Antedate — EIA 10; 152.11

- Allowing an antedate
             [Allowing an antedate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s1_1)

- Denying an antedate
             [Denying an antedate](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s1_2)

         [Antedate — EIA 10; 152.11](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s1)

- Claim procedure — EIA 48; 49; 50(1); 152.1; EIR 26

- 900-Series SINs — EIA 18; 50
             [900-Series SINs — EIA 18; 50](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2_1)

- Late last ROE — Claim is BPNE N2—Last ROE missing
             [Late last ROE — Claim is BPNE N2—Last ROE missing](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2_2)

- D15 — Disentitlement
             [D15 — Disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2_3)

- D48 — Disentitlement
             [D48 — Disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2_4)

- D64 — Disentitlement
             [D64 — Disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2_5)

- Late claimant’s reports
             [Late claimant’s reports](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2_6)

         [Claim procedure — EIA 48; 49; 50(1); 152.1; EIR 26](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s2)

- Availability – EIA 18; 25; 50(8)

- Non-availability declared by client
             [Non-availability declared by client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_1)

- Vacation
             [Vacation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_2)

- Leaving the area for a reason other than vacation within Canada
             [Leaving the area for a reason other than vacation within Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_3)

- Change in residence
             [Change in residence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_4)

- Training and employment activities
             [Training and employment activities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_5)

- Jury duty
             [Jury duty](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_6)

- Part-time employment
             [Part-time employment](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_7)

- Part week employment — Bankruptcy situations
             [Part week employment — Bankruptcy situations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_8)

- Regular benefits in maternity window
             [Regular benefits in maternity window](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_9)

- Otherwise available — Sickness benefits
             [Otherwise available — Sickness benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_10)

- Gradual return to work
             [Gradual return to work](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_11)

- Change in return-to-work date
             [Change in return-to-work date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_12)

- Conversions
             [Conversions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3_13)

         [Availability – EIA 18; 25; 50(8)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s3)

- Labour dispute – EIA 36
         [Labour dispute – EIA 36](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s4)

- Incarceration – EIA 37(a); 152.2(a)
         [Incarceration – EIA 37(a); 152.2(a)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s5)

- Out of Canada – EIA 37(b); 152.2(b); EIR 55, 55.01

- Allowed
             [Allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_1)

- 7-day period allowed
             [7-day period allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_2)

- 14-day period allowed
             [14-day period allowed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_3)

- Imposing a disentitlement after the 7th day
             [Imposing a disentitlement after the 7th day](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_4)

- Imposing a disentitlement after the 14th day
             [Imposing a disentitlement after the 14th day](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_5)

- Imposing a disentitlement for the entire period
             [Imposing a disentitlement for the entire period](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_6)

- Terminating a disentitlement
             [Terminating a disentitlement](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6_7)

         [Out of Canada – EIA 37(b); 152.2(b); EIR 55, 55.01](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s6)

- Earnings and Error Correction – EIA 52, 54(s); EIR 35; 35(2); 36; 37; 38

- Earnings other than from self-employment (SE)
             [Earnings other than from self-employment (SE)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s7_1)

- Earnings from SE (including farming), business profits or commissions
             [Earnings from SE (including farming), business profits or commissions](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s7_2)

- Correction other than earnings
             [Correction other than earnings](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s7_3)

- Correction of a period of exemption from reporting
             [Correction of a period of exemption from reporting](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s7_4)

         [Earnings and Error Correction – EIA 52, 54(s); EIR 35; 35(2); 36; 37; 38](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s7)

- Dismissal and Suspension — EIA 30; 31

- Dismissal
             [Dismissal](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s8_1)

- Suspension
             [Suspension](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s8_2)

         [Dismissal and Suspension — EIA 30; 31](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s8)

- Voluntary leave and leave of absence — EIA 29; 32; 34; EIR 51.1

- Voluntary leaving
             [Voluntary leaving](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s9_1)

- Period of leave of absence
             [Period of leave of absence](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s9_2)

         [Voluntary leave and leave of absence — EIA 29; 32; 34; EIR 51.1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s9)

- Not unemployed — EIA 9; 11

- Self-employment and farming
             [Self-employment and farming](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s10_1)

- Not unemployed
             [Not unemployed](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s10_2)

         [Not unemployed — EIA 9; 11](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s10)

- Teachers requesting benefits during a non-teaching period — EIR 33
         [Teachers requesting benefits during a non-teaching period — EIR 33](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s11)

- Parental benefits and death of the child — EIA 23
         [Parental benefits and death of the child — EIA 23](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s12)

- Modification of an existing disentitlement – special benefits
         [Modification of an existing disentitlement – special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s13)

- Reconsideration — EIA 52; 112
         [Reconsideration — EIA 52; 112](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s14)

- EI Emergency Response Benefit (EI ERB) Claims — EIA 52; 112; 153.5(2) and (3); 153.6(1); 153.9(1), (2), and (4); 153.1303 (Temporary measure)
         [EI Emergency Response Benefit (EI ERB) Claims — EIA 52; 112; 153.5(2) and (3); 153.6(1); 153.9(1), (2), and (4); 153.1303 (Temporary measure)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/levels_decision-annex1#s15)

**1. Antedate –EIA 10;152.11**

**Allowing an antedate**

A Level 1 officer can render the decision to allow an antedate for all benefit types (BTs) when:

- the only reason the client did not submit the application between the requested benefit period (BP) start or renewal date and the actual application date is that the client was receiving severance or termination pay, the allocation of which would have prevented the payment of benefits for that period; and

- the client submitted the initial application in the 52-week period following the requested BP start date and qualifies to establish a claim in that week; or

- the client submitted the renewal application in the 52-week period following the requested renewal date.

A Level 1 officer can render the decision to allow an antedate for all BTs when:

- the reason the client did not submit the application between the requested BP start or renewal date and the actual application date is one or a combination of the following reasons:

- the client lacks experience or understanding of the EI program and its time requirements and has not had a claim in the 3-year period before the current application date;

- the client has little to no comprehension of French and English;

- the client received a job offer before the interruption of earnings (I of E) for a job that would start in the 8-week period after the I of E, but the new job was delayed or did not materialize. No verification with the employer is required;

- the client was waiting for the employer to issue the ROE; and

- one or a combination of the reasons above covers the entire period of the delay; and

- the client submitted the initial application in the 8-week period following the requested BP start date and qualifies to establish a claim in that week; or

- the client submitted the renewal application in the 8-week period following the requested renewal date.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0328.dita) 

A Level 1 officer can render the decision to allow an antedate on a claim for regular benefits when:

- the claim was previously BPNE 5 and a change in the VER has reduced the number of hours required to qualify for regular benefits; and

- the client will qualify for regular benefits based on the change in the VER; and

- the client submitted the application in the 8-week period following the requested BPC date; and

- the reason the client did not apply for benefits following the change to the VER was the client was unaware of the possibility of now qualifying for EI benefits.

A Level 1 officer can render the decision to allow an antedate on a claim for special benefits when:

- the reason the client did not submit the application between the requested BP start or renewal date and the actual application date is one or a combination of the following reasons:

- the client was sick, injured, or quarantined;

- the client was waiting for a response from a provincial Workers’ Compensation Board, wage loss insurance (WLI) or an insurance company;

- for CCB and FCB: the client was providing care or support to the patient for which the client has requested benefits, and there is no indication on file that someone else has applied for benefits related to the care or support of the same patient;

- the client lacks experience or understanding of the EI program and its time requirements and has not had a claim in the 3-year period before the current application date;

- the client has little to no comprehension of French and English;

- the client was waiting for the employer to issue the ROE; and

- one or a combination of reasons above covers the entire period of the delay; and

- the client completed the initial application in the 8-week period following the requested BP start date and qualifies to establish a claim in that week; or

- the client completed the renewal application in the 8-week period following the requested renewal date.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0329.dita) 

A Level 1 officer can render the decision to allow an antedate on a claim for sickness, maternity, or parental benefits when:

- the only reason the client did not submit the application between the requested BP start or renewal date and the actual application date is one of the following:

- the client was sick, injured, or quarantined; or

- the client was waiting for a response from a provincial Workers’ Compensation Board, WLI or an insurance company; and

- the client is not requesting regular benefits between the requested BP start or renewal date and the actual application date; and

- the client submitted the initial application in the 52-week period following the requested BP start date and qualifies to establish a claim in that week; or

- the client submitted the renewal application in the 52-week period following the requested renewal date.

A Level 1 officer can render the decision to allow an antedate on a claim for CCB or FCB when:

- the only reason the client did not submit the application between the requested BP start or renewal date and the actual application date is that the client was providing care or support to the patient; and

- there is no indication on file that someone else has applied for benefits related to the care or support of the same patient; and

- the client is not requesting regular benefits between the requested BP start or renewal date and the actual application date; and

- the client submitted the initial application in the 52-week period following the requested BP start date and qualifies to establish a claim in that week; or

- the client submitted the renewal application in the 52-week period following the requested renewal date.

**Denying an antedate**

A Level 1 officer can render the decision to deny an antedate when:

- the client does not qualify to establish a claim on any day between the client’s requested BP start date and the BPC.

**2. Claim procedure —EIA 48;49;50(1);152.1;EIR 26**

**900-Series SINs — EIA18;50**

A Level 1 officer can render a decision to allow regular or sickness benefits for a client with a 900-series SIN when:

- the client has a valid open work permit; or

- the client provided proof of maintained status of an open work permit; and

- the client is requesting regular benefits and is capable of and available for work and poses no restriction towards accepting employment; or

- the client is requesting sickness benefits and is otherwise available for work.

A Level 1 officer can render a decision to allow maternity benefits, parental benefits, FCB or CCB for a client with a 900-series SIN when:

- the client has a valid SIN; or

- the SIN is expired but the client is authorized to stay in Canada and is remaining in Canada.

**Late last ROE — Claim is BPNE N2—Last ROE missing**

A Level 1 officer can render the decision to allow a late last ROE received within 90 days of the date the claim was finalized as BPNE N2.

A Level 1 officer can render the decision to allow a late last ROE received more than 90 days after the date the claim was finalized as BPNE N2 when:

- the ROE was received within 52 weeks of the date the claim was finalized as BPNE 2; and

- the client was unable to submit the ROE for the entire period of delay due to an illness, injury or quarantine; or

- the client is requesting maternity, parental, FCB or CCB; or

- the client was out of the area or out of Canada for the entire period of the delay; and

- the client is not requesting benefits during the entire period of delay; or

- the client is not entitled to benefits due to an allocation of earnings and contacts Service Canada in the 6 weeks following the end of the allocation; or

- the employer delayed in providing the ROE and there is documentation on file showing the client requested Service Canada’s assistance in obtaining the ROE within the first 90 days from the date the claim was finalized as BPNE N2.

**D15 — Disentitlement**

**Imposing a D15**

A Level 1 officer can render the decision to impose a 15 - Claim Procedure disentitlement (D15) for failing to submit an ROE or other requested information.

**Rescinding a D15**

A Level 1 officer can render the decision to rescind a D15 imposed for failing to submit an ROE when it is received within 90 days from the date the D15 was imposed.

A Level 1 officer can render the decision to rescind a D15 imposed for failing to submit an ROE if it is received more than 90 days after the date the disentitlement was imposed when:

- the ROE was received within 52 weeks from the date the D15 was imposed; and

- the client was unable to submit the ROE for the entire period of delay due to an illness, injury or quarantine; or

- the client is requesting maternity, parental, FCB or CCB; or

- the client is not entitled to benefits due to an allocation of earnings and contacts Service Canada in the 6 weeks following the end of the allocation; or

- the employer delayed in providing the ROE and there is documentation on file showing the client requested Service Canada’s assistance in obtaining the ROE within the first 90 days from the date the D15 was imposed.

A Level 1 officer can render the decision to rescind a D15 imposed for failing to submit the requested information other than an ROE when:

- a Level 1 officer initially imposed the D15; and

- the client contacts Service Canada in the 6 weeks following the date the D-01-00-01 letter was sent; and

- the client submitted the requested information; and

- if the client is requesting regular benefits, the client was capable of and available for work and posed no restriction towards accepting employment during the entire period; or

- if the client is requesting regular benefits and was not available for work, the client had declared not being available for work.

**Terminating a D15**

A Level 1 officer can render the decision to terminate a D15 imposed for failing to submit an ROE when:

- the ROE was received no more than 52 weeks from the date the D15 was imposed; and

- the client was out of the area or out of Canada for the entire period of the delay; and

- the client is not requesting benefits during the period of delay.

A Level 1 officer can render the decision to terminate a D15 imposed for failing to submit requested information other than an ROE on a renewal claim when the reason for the disentitlement no longer applies at the time of the renewal.

**D48 — Disentitlement**

**Imposing a D48**

A Level 1 officer can render the decision to impose a 48 - Moved-address unknown disentitlement (D48) for failing to provide the address of the normal place of residence.

**Rescinding a D48**

A Level 1 officer can render the decision to rescind a D48 imposed for failing to provide the address of the normal place of residence when:

- a Level 1 officer initially imposed the D48; and

- the client contacts Service Canada in the 6 weeks following the date the D48 was imposed; and

- the client provides the address of the normal place of residence.

**Terminating a D48**

A Level 1 officer can render the decision to terminate a D48 imposed for failing to provide the address of the normal place of residence when:

- the client provides the address of the normal place of residence; and

- the client is not requesting benefits for the period the D48 is imposed.

A Level 1 officer can render the decision to terminate a D48 imposed for failing to provide the address of the normal place of residence if the client provides the new address when renewing the claim.

**D64 — Disentitlement**

**Imposing a D64**

A Level 1 officer can render the decision to impose a 64—Renewal—Proof of Identity not provided disentitlement (D64) for failing to provide the identity documentation requested when submitting a renewal application.

**Rescinding a D64**

A Level 1 officer can render the decision to rescind a D64 for failing to provide proof of identity when:

- a Level 1 officer initially imposed the D64; and

- the client contacts Service Canada within 6 weeks of the date the D64 was imposed; and

- the client provides the requested identity documentation.

**Terminating a D64**

A Level 1 officer can render the decision to terminate a D64 for failing to provide proof of identity when:

- a Level 1 officer initially imposed the D64; and

- the client has provided the requested identity documentation; and

- the client is not requesting benefits for the period the D64 is imposed.

**Late claimant’s reports**

**Allocation**

A Level 1 officer can render the decision to allow a late claimant’s report when:

- the client is not entitled to any benefits because of an allocation of earnings; and

- the client contacts Service Canada within 8 weeks of the date on which the allocation ended.

**Lack of EI experience**

A Level 1 officer can render the decision to allow a late claimant’s report when:

- the reason for delay was due to the client’s lack of experience with or knowledge of EI procedures or the time frame in which to submit claimant’s reports; and

- the client contacts Service Canada in the 12 weeks after the initial application; and

- the late claimant’s report includes the week of the BPC.

**Leaving the area or Canada**

A Level 1 officer can render the decision to allow a late claimant’s report when:

- the client left Canada or the area before the due date of the claimant’s report; and

- the client contacts Service Canada in the 8 weeks after the date the client returned to Canada; and

- no other reason prevented the client from submitting the claimant’s report before departure.

**Return to work**

A Level 1 officer can render the decision to allow a late claimant’s report when:

- the claimant’s report includes the waiting period; and

- the reason for the delay was due to the client returning to work during the week immediately following the waiting period; and

- the client is not requesting benefits for the week of the RTW; and

- no other reason prevented the client from submitting the claimant’s report before returning to work.

**Special benefits**

A Level 1 officer can render the decision to allow a late claimant’s report when:

- the delay was due to the client’s illness, injury or quarantine; and

- no other reason prevented the client from submitting the claimant’s report.

A Level 1 officer can render the decision to allow a late claimant’s report when:

- the client is requesting maternity, parental, FCB or CCB for the period of delay; and

- the client contacts Service Canada within 8 weeks of the last day of the period covered by the claimant’s report.

**3. Availability —EIA 18;25;50(8)**

**Non-availability declared by client**

A Level 1 officer can render the decision to impose a disentitlement on the claim for reasons of non-availability when:

- no benefits have been paid for the period during which the client declared not being available; or

- if benefits have been paid, the client has contacted Service Canada to correct the wrong information within 6 weeks of submitting the claimant’s report; and

- the client agrees that no benefits are payable during the period of non-availability.

A Level 1 officer can render the decision that a client is considered available when:

- the client is attending approved training under EIA 25 ; and
         [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- confirmation of the approved training (including training dates) from the referring authority is available on the client’s file or through LMDA Access; and

- the approved training dates cover the entire period of non-availability declared.

**Vacation**

A Level 1 officer can render the decision to impose a disentitlement on the claim for reasons of non-availability when:

- the client is or was on vacation (within or outside of Canada); and

- the client is or was not available for work; and

- benefits have not been paid for the period the client is or was on vacation; or

- if benefits have been paid, the client has contacted Service Canada to correct the wrong information within 6 weeks of submitting the claimant’s report.

A Level 1 officer can render the decision to terminate a disentitlement imposed on the claim for reasons of non-availability while on vacation when:

- the client is no longer on vacation; and

- the client contacts Service Canada within 6 weeks of the date of return; and

- the client is capable of and available for work and poses no restriction towards the acceptance of employment from the date of return.

A Level 1 officer can render the decision to terminate a disentitlement imposed on a renewal claim for non-availability while being on vacation when the vacation ended before the renewal date.

**Leaving the area for a reason other than vacation within Canada**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0330.dita) 

A Level 1 officer can render the decision to allow benefits for up to 7 days when the reason for leaving the area is:

- to attend the funeral of an immediate family member or close relative; or

- to visit an immediate family member who is seriously ill or injured; or

- to accompany an immediate family member to an accredited institution for the family member to receive medical treatment that is not readily or immediately available in the family member’s area of residence in Canada; or

- to seek work or attend a job interview; and

- the absence was for 7 days or less; and

- no benefits have been paid; or

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report ; and

- the client made arrangements to be contacted for employment opportunities and was able to return within 48 hours in the event of an employment opportunity.

A Level 1 officer can render the decision to terminate a disentitlement on the claim of a client who was out of the area, but within Canada, when:

- the client contacts Service Canada within 6 weeks of date of return to the area; and

- the reason the client was out of the area is one of the following:

- to attend the funeral of an immediate family member or close relative;

- to visit an immediate family member who is seriously ill or injured;

- to accompany an immediate family member to an accredited institution for the family member to receive medical treatment that is not readily or immediately available in the family member’s area of residence in Canada; or

- to seek work or attend a job interview; and

- the reason for the absence is the only entitlement issue in the file.

A Level 1 officer can render the decision to terminate a disentitlement imposed on a renewal claim for being out of the area when the absence ended before the renewal date.

**Change in residence**

A Level 1 officer can consider a client available during the period of relocation to a new residence when:

- there is no outstanding disentitlement, disqualification or manual action (MA) on file; and

- the client is capable of and available for work during the period of the move and poses no restrictions towards accepting employment during or since the move; and

- the client did not voluntarily leave employment without just cause to relocate.

**Training and employment activities**

**Non-referred training — NotEIA 25training**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0331.dita) 

A Level 1 officer can consider a client available and allow non-referred training (not EIA 25 ) on a claim for regular benefits when:
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- the training is between 10 and 14 hours per week; and

- the client is capable of and available for work and poses no restrictions towards accepting employment or the hours or days of availability; and

- the client is willing to quit the training or change the training schedule to accept full-time employment if the training schedule comes into conflict with the employment.

- the training is equal to or greater than 15 hours per week; and

- the client is capable of and available for work and poses no restrictions towards accepting employment; and

- all of the training obligations occur outside the normal work hours of the client’s usual employment; and

- the client is willing to quit the training or change the training schedule to accept full-time employment if the training schedule comes into conflict with the employment.

A Level 1 officer can consider a client otherwise available and allow non-referred training (not EIA 25 ) on a claim for sickness benefits when:
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- the training is between 10 and 14 hours per week; and

- the client declares that, if not for the illness, injury or quarantine, the client would be capable of and available for work; and

- the client’s intention upon recovery is:

- to return to the employment as the training will be completed before the recovery; or

- to quit the training and return to the employment; or

- to continue the training and to return to the employment with the same schedule and conditions as before the illness, injury or quarantine.

- the training is equal to or greater than 15 hours per week; and

- all of the training obligations occur outside the normal work hours of the client’s usual employment; and

- the client declares that, if not for the illness, injury or quarantine, the client would be capable of and available for work; and

- the client’s intention upon recovery is:

- to return to the employment as the training will be completed before the recovery; or

- to quit the training and return to the employment; or

- to continue the training and to return to the employment with the same schedule and conditions as before the illness, injury or quarantine.

A Level 1 officer can render the decision to allow the non-referred training (not EIA 25 ) while the client is receiving FCB or parental benefits when:
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- the training is less than 25 hours per week; and

- the client is not required to reside -away from the family member receiving the client’s care or support, or from the child, in order to attend the training.

A Level 1 officer can render the decision to allow the non-referred training (not EIA 25 ) while the client is receiving CCB when:
       [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

- the training is less than 25 hours per week.

A Level 1 officer can render the decision to terminate a disentitlement imposed for non-availability while the client attended training when:

- the client quits the training; or

- the training is complete; and

- the client is not requesting benefits for a period of break between semesters or during the school year; and

- the client is capable of and available for work and poses no restriction to accepting employment; or

- a proof of referral to the training under EIA 25 is received.
         [EIA 25](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-25.html)

**End of referred training or employment activity — EIA27(1.1)**

A Level 1 officer can render the decision to allow an early end to referred training or employment activity and the payment of regular or sickness benefits when:

- the client is capable of and available for work and poses no restriction towards accepting employment; or

- the client declares that, if not for the illness, injury or quarantine, the client would be capable of and available for work; and

- the reason for termination of the referred training or employment activity is one of the following:

- medical reasons; or

- the client completed the training or employment activity before the scheduled end week; or

- the client is having attendance issues because of providing care or support to a family member while receiving parental benefits, FCB or CCB; or

- the training or employment activity was beyond the client’s capabilities; or

- an authority designated by Service Canada determined that the training or employment activity was not suitable for the client.

**Jury duty**

A Level 1 officer can render the decision to allow benefits for the period the client is engaged in jury duty.

A Level 1 officer can render the decision to suspend a disentitlement related to availability for a period the client is engaged in jury duty.

**Part-time employment**

A Level 1 officer can consider a client available when:

- the client is currently working part-time; and

- the client is available for and seeking other suitable employment with this employer or any other employer; and

- the client is willing to leave the part-time employment to accept a full-time employment offer.

**Part week employment — Bankruptcy situations**

A Level 1 officer can render the decision to impose a disentitlement for a period of up to 4 days during the BPC week or renewal week when a client has worked but has not received all of some of the earnings due to the bankruptcy of the employer.

**Regular benefits in maternity window**

A Level 1 officer can consider a client available while requesting regular benefits during the maternity window before the date of confinement when:

- the client is laid off because of a shortage of work before or during the maternity window; or

- the client was receiving regular benefits before the start of the maternity window; and

- the client’s maternity leave at her place of employment was not scheduled for the period for which she is requesting regular benefits; and

- the client is capable of and available for work and poses no restrictions towards accepting employment.

A Level 1 officer can consider a client available while requesting regular benefits 14 days or more after the actual date of confinement when:

- the client is minor attached; and

- the client is laid off because of a shortage of work; or

- the client was receiving regular benefits before the date of confinement; and

- the client’s maternity leave at her place of employment was not scheduled for the period for which she is requesting regular benefits; and

- the client is capable of and available for work and poses no restrictions toward accepting employment.

**Otherwise available — Sickness benefits**

A Level 1 officer can consider a client otherwise available on an initial claim for sickness benefits when:

- the client would be capable of and available for work, if not for the illness, injury or quarantine; or

- the client would have been entitled to regular benefits if not for the illness, injury or quarantine.

A Level 1 officer can consider a client otherwise available on a continuing or renewal claim for sickness benefits when:

- the client was receiving or was entitled to parental benefits, FCB or CCB at the start of the illness, injury or quarantine; and

- the client’s entitlement to parental benefits, FCB or CCB will continue up to or beyond the recovery date; and

- the client submits a medical certificate for the period of incapacity which includes both the date the illness began and the expected recovery date.

A Level 1 officer can consider a client otherwise available while requesting sickness benefits in the maternity window before the actual date of confinement when:

- the client stopped working due to illness; or

- the client was receiving regular or sickness benefits before the start of the maternity window; and

- the client’s maternity leave at her place of employment was not scheduled for the period of time for which she is requesting sickness benefits; and

- the client would be capable of and available for work, if not for the illness, injury or quarantine.

**Gradual return to work**

A Level 1 officer can render the decision to continue paying sickness benefits when:

- the client recovered to the extent of being capable of working, but not full-time due to a gradual return to work or limited capabilities, as a result of the illness or injury; and

- the client has submitted the necessary medical certificate confirming the gradual return to work (RTW); and

- the client is entitled to sickness benefits for the period during which the client is unable to work due to illness, injury or quarantine.

**Change in return-to-work date**

A Level 1 officer can render the decision to rescind the RTW date to continue paying regular benefits when:

- the reason for not returning to work can be allowed at Level 1; and

- there is no outstanding disentitlement, disqualification, or MA on file; and

- the client is capable of and available for work and poses no restriction towards accepting employment.

A Level 1 officer can render the decision to rescind the RTW date to continue paying sickness benefits when:

- the reason for not returning to work is illness, injury or quarantine; and

- there is no outstanding disentitlement or MA on file; and

- the client submits a medical certificate for the period of incapacity extending beyond the RTW date; and

- the client would have been otherwise available if it was not for the illness, injury or quarantine.

A Level 1 officer can render the decision to rescind the RTW date to continue paying maternity, parental, CCB or FCB when:

- the reason for not returning to work can be allowed at Level 1; and

- there is no outstanding disentitlement or MA on file; and

- if the client is requesting parental benefits, CCB or FCB, the client continues to provide care or support to the family member.

A Level 1 officer can render the decision to rescind the RTW date to convert the claim to another BT when:

- the reason for not returning to work can be allowed at Level 1; and

- the client meets the qualifying and entitlement conditions related to the requested BT; and

- the client meets all availability or otherwise available conditions.

**Conversions**

**Special benefits to regular benefits**

A Level 1 officer can render the decision to convert a claim from special benefits to regular benefits when:

- the client was receiving regular benefits before receiving special benefits; or

- the reason for not returning to work can be allowed at Level 1; and

- the client is capable of and available for work and poses no restriction towards accepting employment.

**Apprenticeship to regular benefits**

A Level 1 officer can render the decision to convert a claim from apprenticeship to regular benefits when:

- the client received regular benefits before the apprenticeship training; or

- the reason for not returning to work can be allowed at Level 1; and

- the client is capable of and available for work and poses no restriction towards accepting employment.

**4. Labour dispute –EIA 36**

A Level 1 officer can implement the decision to impose or terminate a disentitlement that was rendered for a group of clients who lost their employment due to a work stoppage resulting from a labour dispute at their place of employment.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0332.dita) 

**5. Incarceration —EIA 37(a);152.2(a)**

A Level 1 officer can render the decision to impose a disentitlement when:

- the client is incarcerated; and

- there are no conditions allowing the client to be away from the institution; and

- benefits have not been paid for the period of incarceration; or

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report covering the period of incarceration.

A Level 1 officer can render the decision to terminate the disentitlement when:

- the client is no longer incarcerated; and

- the client is capable of and available for work and poses no restriction towards accepting employment.

A Level 1 officer can render the decision to terminate a disentitlement on a renewal claim when the incarceration ended before the renewal date.

**6. Out of Canada –EIA 37(b);152.2(b); EIR55,55.01**

**Allowed**

A Level 1 officer can render the decision to allow the entire period the client is out of Canada when:

- the client is entitled to maternity benefits, parental benefits, FCB or CCB.

**7-day period allowed**

A Level 1 officer can render the decision to allow the payment of benefits for a period of up to 7 consecutive calendar days while the client is out of Canada:

- to attend the funeral of an immediate family member (EIR 55 [2]) or one of the persons defined under EIR 55 (1)(b) ; or
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html) 
         [EIR 55 (1)(b)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- to visit an immediate family member (EIR 55 [2]) who is seriously ill or injured; or
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- to accompany an immediate family member to an accredited institution for the family member to receive medical treatment that is not readily or immediately available in the family member’s area of residence in Canada; and

- no benefits have been paid; or

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report; and

- the client made arrangements to be contacted for employment opportunities and was able to return within 48 hours in the event of an employment opportunity.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0333.dita) 

**14-day period allowed**

A Level 1 officer can render the decision to allow the payment of benefits for up to an additional 7 days while the client is out of Canada when:

- the client is visiting an immediate family member (EIR 55 [2]) who is seriously ill or injured; and
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- that immediate family member dies, and the client remains out of Canada to attend the funeral of that immediate family member; and

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report; and

- the client made arrangements to be contacted for employment opportunities and was able to return within 48 hours in the event of an employment opportunity.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0334.dita) 

**Imposing a disentitlement after the 7th day**

A Level 1 officer can render the decision to impose a definite or indefinite disentitlement for being out of Canada from the 8th day following the date of departure when:

- the client’s absence is to attend the funeral of an immediate family member (EIR 55 [2]) or one of the persons defined under EIR 55 (1)(b) ; or
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html) 
         [EIR 55 (1)(b)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- the client’s absence is to visit an immediate family member (EIR 55 [2]) who is seriously ill or injured; or
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- to accompany a member of the client’s immediate family who is receiving medical treatment from an accredited institution that is not readily or immediately available in the area; and

- no benefits have been paid from the 8th day following the date of departure; or

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0333.dita) 

**Imposing a disentitlement after the 14th day**

A Level 1 officer can render the decision to impose a definite or indefinite disentitlement for being out of Canada from the 15th day following the 14 days previously allowed when:

- the client was allowed benefits for up to 7 days to visit an immediate family member (EIR 55 [2]) who is seriously ill or injured; and
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- that immediate family member (EIR 55 [2]) dies and the client remained out of Canada to attend the funeral of that family member; and
         [(EIR 55 [2])](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- no benefits were paid from the 15th day; or

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0335.dita) 

**Imposing a disentitlement for the entire period**

A Level 1 officer can render the decision to impose a disentitlement for being out of Canada from the day following the departure date when:

- the reasons for being out of Canada are not exempt from disentitlement as per EIR 55 ; and
         [EIR 55](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-55.html)

- no benefits have been paid; or

- if benefits have been paid, the client contacts Service Canada within 6 weeks of submitting the claimant’s report.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0333.dita) 

**Terminating a disentitlement**

A Level 1 officer can render the decision to terminate a disentitlement for being out of Canada when:

- the client contacts Service Canada within 6 weeks of the date of return; and

- the client declares being available from the date of return or after.

A Level 1 officer can render the decision to terminate a disentitlement on a renewal claim for being out of Canada when:

- the disentitlement was originally imposed because the client was out of Canada; and

- the disentitlement no longer applies because the client returned to Canada before the renewal date.

**7.Earningsand Error Correction —  EIA52;54(s);EIR35;35(2);36;37;38**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0336.dita) 

**Earnings other than from self-employment (SE)**

A Level 1 officer can render the decision to allocate earnings (initial allocation or correction) when:

- there is no doubt that the monies paid or payable are earnings for EI purposes; and

- there is no doubt as to the period to which these monies must be allocated; and

- the correction request is received and actioned within 36 months from the week for which benefits were paid or payable; and

- for corrections, there is no active Integrity investigation on file.

**Earnings from SE (including farming), business profits or commissions**

A Level 1 officer can render the decision to allocate earnings (initial allocation or correction) from SE (including farming), business profits or commissions when:

- the SE has already been deemed minor in extent for the period to which the earnings would be allocated; or

- the client has established a claim under PART VII.1 - Benefits for Self-Employed Persons; and
         [PART VII.1](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-152.01.html)

- there is no doubt as to whether the monies paid or payable are earnings for EI purposes; and

- there is no doubt as to the period to which these monies must be allocated; and

- the client provides the net earnings; and

- the correction request is received and actioned within 36 months from the week for which benefits were paid or payable; and

- for corrections, there is no active Integrity investigation on file.

**Correction other than earnings**

A Level 1 officer can render the decision to correct information that is not related to earnings when:

- the correction request is made within 6 weeks of when the original claimant's report was made.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0337.dita) 

**Correction exemption from reporting**

A Level 1 officer can render the decision to correct information received for a period of exemption from claimant's reports when:

- the correction request is received within 6 weeks following the week in which the last payment of the exemption period was issued.

**8. Dismissal and Suspension —EIA 30;31**

**Dismissal**

A Level 1 officer can render the decision to allow a dismissal on all claim types (CTs) when:

- the client indicates being dismissed due to unsuitability or due to a shortage of work; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS.

A Level 1 officer can render the decision to allow the dismissal on an initial or renewal claim when:

- the client worked for the employer for 12 weeks or less; and

- the client did not provide any details on the EI application about that employment; and

- the employer, when contacted, confirms that the client was not suitable for the position and there was no misconduct; or

- a comment on the ROE confirms the dismissal is due to the client being unsuitable, not passing training or being terminated within the probationary period; and

- there are no other contentious issues related to the dismissal that would prevent the Level 1 officer from allowing the RFS.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0338.dita) 

**Suspension**

A Level 1 officer can render the decision on a renewal claim to terminate a disentitlement imposed for a period during which the client is suspended when:

- the period of suspension expired; or

- the client was laid off; or

- the reason for not returning to work can be allowed at Level 1; or

- the client accumulated enough insurable hours with another employer after the beginning of the period of suspension to qualify for the requested BT.

**9. Voluntary leave and leave of absence — EIA29;32;34; EIA51.1**

**Voluntary Leaving**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0339.dita) 

**Relocation of spouse**

A Level 1 officer can render the decision to allow the voluntary leave due to the relocation of a spouse when:

- the decision to relocate is related to the spouse’s employment; and

- the move to the new residence is for a period of at least one year; and

- the one-way commute to work would have been an hour or more; and

- the client relocated in the 4 weeks after the last day worked (LDW); and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

A Level 1 officer can render the decision to allow the voluntary leave due to the relocation of a common-law partner, with whom the client has resided for less than a year when:

- the client or the common-law partner gave birth to or adopted a child when they resided together in a conjugal relationship; or

- the client or the common-law partner is expecting the birth of a child; and

- the decision to relocate is related to the employment of the common-law partner; and

- the move to the new residence is for a period of at least one year; and

- the one-way commute to work would have been an hour or more; and

- the client relocated in the 4 weeks after the LDW; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

**Anticipation of marriage**

A Level 1 officer can render the decision to allow the voluntary leave due to a relocation in anticipation of marriage when:

- the client has married or has a definite wedding date within 4 weeks of the client’s LDW; and

- the one-way commute to work would have been an hour or more; and

- the client relocated in the 4 weeks after the LDW; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

**Relocation of dependent**

A Level 1 officer can render the decision to allow the voluntary leave due to the relocation of a dependent child for medical reasons when:

- the dependent child’s medical condition requires the client to move; and

- the client submits medical documents attesting that the dependent child requires treatment at a centre or from a medical specialist away from the usual area of residence; and

- the move to the new residence is for a period of at least one year; and

- the one-way commute to work would have been an hour or more; and

- the client relocated in the 4 weeks after the LDW; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

**Relocation of parent or legal guardian**

A Level 1 officer can render the decision to allow the voluntary leave due to the relocation of a parent or legal guardian when:

- the client was under 18 years old immediately before the relocation; and

- the client was residing with a parent or guardian immediately before the relocation; and

- the one-way commute to work would have been an hour or more; and

- the client relocated in the 4 weeks after the LDW; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

**Concurrent employment**

A Level 1 officer can render the decision to allow the voluntary leave on all CTs when:

- the client had more than one employment at the same time and voluntarily left one of them; and

- the employment the client kept was full-time and the client was not expecting it to end.

**Promise of employment**

A Level 1 officer can render the decision to allow the voluntary leave to accept other permanent employment on an initial or renewal claim when:

- the client had a genuine employment offer that was scheduled to start within 2 weeks of the LDW of the previous employment. Confirmation from the prospective employer is required; and

- the client did not start the new employment because the offer was withdrawn or cancelled for reasons unrelated to the client or the client’s actions. Confirmation from the prospective employer is required; and

- the client was unable to withdraw the resignation from the previous employment and unable to return to it; and

- the new employment was supposed to be permanent; and

- the weekly number of hours at the new employment would have been equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

A Level 1 officer can render the decision to allow the voluntary leave to accept temporary employment on an initial or renewal claim when:

- the client had a genuine employment offer that was scheduled to start within 2 weeks of the LDW of the previous employment. Confirmation from the prospective employer is required; and

- the client did not start the new employment because the offer was withdrawn or cancelled for reasons unrelated to the client or the client’s actions. Confirmation from the prospective employer is required; and

- the client was unable to withdraw the resignation from the previous employment and was unable to return to it; and

- the client quit one temporary employment for another temporary employment; and

- the new temporary employment was supposed to last the same amount of time or longer than the previous temporary employment; and

- the weekly number of hours at the new employment would have been equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

**To accept other employment**

A Level 1 officer can render the decision to allow the voluntary leave to accept other employment on an initial or renewal claim when:

- the new employment started within 4 weeks of the LDW of the previous employment; and

- the BPC or renewal week is after the week the new employment started; and

- the new employment was supposed to be a permanent position; or

- if the new job was temporary, it was to last longer than the job the client quit; and

- the weekly number of hours at the new employment was equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

A Level 1 officer can render the decision to allow a voluntary leave for other employment on a continuing claim when:

- the new employment was supposed to be permanent; and

- there was no more than a 4-day gap between the first day worked (FDW) with the new employment and the LDW from the previous employment; or

- the FDW with the new employment started before the LDW at the previous employment; and

- the weekly number of hours at the new employment was equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

A Level 1 officer can render the decision to allow a voluntary leave from temporary employment for other temporary employment on a continuing claim when:

- the new temporary employment was supposed to last longer than the previous temporary employment; and

- there was no more than a 4-day gap between the FDW with the new employment and the LDW from the previous employment; or

- the FDW with the new employment started before the LDW from the previous employment; and

- the weekly number of hours at the new employment was equal to or greater than the weekly number of hours worked at the previous employment; and

- there are no contentious issues related to the voluntary leaving that would prevent the Level 1 officer from allowing the RFS.

**Self-employment**

A Level 1 officer can render the decision to allow the voluntary leave to start SE activities on an initial or renewal claim when:

- the SE activities or the operation of the business started within 2 weeks of the date the client quit the employment; and

- the client has ceased SE activities or stopped operating the business; and

- the BPC or renewal week is after the start week of the SE activities or business; and

- the client is not requesting benefits for the SE or business operation period; and

- the client is capable of and available for work and poses no restrictions towards accepting employment.

**Workforce reduction**

A Level 1 officer can render the decision to allow the voluntary leave that is part of an approved workforce reduction program under EIR 51 .
       [EIR 51](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-51.html)

**Referred training or employment activities**

A Level 1 officer can render the decision to allow the voluntary leave to attend referred training or an employment activity when:

- an authority designated by Service Canada referred the client to the training or employment activity before the voluntary leave; and

- the referring authority approved the voluntary leave; and

- the referred training or employment activity started within 2 weeks of the voluntary leaving date; and

- the BPC or renewal week is the same as the week of the voluntary leaving or after.

**Medical reasons**

A Level 1 officer can render the decision to allow the voluntary leave for medical reasons when:

- the client provided a medical certificate or other similar document completed by a doctor or other medical professional recommending the client quit the employment. Confirmation from the employer is not required; or

- the client provided a medical certificate or other similar document for a temporary medical situation, but a leave of absence could not be arranged with the employer. The employer must confirm that there were no other suitable positions available for the client and that a leave of absence could not be allowed.

**Period of leave of absence**

A Level 1 officer can render the decision to allow a period of leave of absence on an initial or renewal claim for an ROE that is not the last when:

- the client is not requesting benefits for the period of the leave of absence; and

- the client resumed employment with the same employer after the period of leave of absence and then was laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment and the RFS can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits.

A Level 1 officer can render the decision to terminate a disentitlement on a renewal claim that was imposed for a previous period of leave of absence when:

- the client resumed employment with the same employer after the period of leave of absence and was then laid off or stopped working for a reason that can be allowed at Level 1; or

- the client did not resume the employment for a reason that can be allowed at Level 1; or

- the client accumulated enough insured hours with another employer after the beginning of the period of leave to qualify for benefits.

**10. Not unemployed – EIA9;11**

**Self-employment and farming**

A Level 1 officer can consider the SE minor in extent on an initial claim when:

- the business is permanently closed; and

- all business operations ceased before the BPC.

A Level 1 officer can consider the SE (including farming) minor in extent on a renewal claim when:

- the SE (including farming) had been previously allowed by a Level 2 officer on the initial claim; and

- there is no change to the circumstances and the facts related to the SE (including farming) since the adjudication on the initial claim.

A Level 1 officer can consider the SE minor in extent for a client who has worked for a friend or a family member when:

- the client is receiving regular benefits; and

- the friend or family member does not own a business related to the type of activities performed; and

- the client worked no more than 3 days consecutive days; and

- the client has not previously declared working for a friend or family member; and

- the client has not started a business or does not own a business; and

- the client is available and is seeking full-time employment; and

- the client is willing to stop helping the friend or family member to accept suitable employment; and

- any money earned from working for the friend or family member was declared and was paid by the individual and not a business.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0340.dita) 

A Level 1 officer can consider the SE (not including farming) minor in extent on a regular benefits claim when:

- the total amount the client personally invested in the following items does not exceed $25 000:

- premises;

- equipment;

- inventory;

- reinvestment; and

- the gross annual income from SE is equal to or less than $10 000; and

- no employees work in the business; and

- the client’s SE activities have decreased or remained constant in the last 3 years; and

- the client carried out the SE activities while holding full-time insurable employment; and

- the client invests less than 15 hours per week in the SE activities; and

- the client does not consider the SE the main source of income; and

- the client is not trying to make the SE the main source of income; and

- the client’s intention is to find full-time insurable employment; and

- the client has been seeking full-time insurable employment.

A Level 1 officer can consider the SE activities (not including farming) minor in extent on a claim for maternity, parental, FCB or CCB when:

- the total amount the client personally invested in the following items does not exceed $25 000:

- premises;

- equipment;

- inventory;

- reinvestment; and

- the gross annual income from SE is equal to or less than $10 000; and

- no employees work in the business; and

- the client’s SE activities have decreased or remained constant in the last 3 years; and

- the client carried out the SE activities while holding full-time insurable employment; and

- the client invests less than 15 hours per week in the SE activities; and

- the client does not consider the SE the main source of income; and

- the client is not trying to make the SE the main source of income; and

- the client is requesting to receive parental benefits and to carry out SE activities in a location that allows the client to provide care to the child; or

- the client is requesting FCB or CCB and to carry out SE activities in a location that allows the client to provide care or support to the patient.

A Level 1 officer can consider the farming minor in extent when:

- the farming income only comes from the rental of land; or

- the client is no longer engaged in the farm’s operations and farming ceased before the BPC.

A Level 1 officer can consider the farming minor in extent when:

- the gross farming income is equal to or less than $25 000; and

- the client operated the farm while holding full-time insurable employment; and

- the farm’s operations have decreased or remained constant in the last 3 years; and

- the client is available to work full-time for the periods of April through September and October through March; and

- farming is not the client’s main source of income.

**Not unemployed**

A Level 1 officer can render the decision to terminate a disentitlement imposed for a period for which the client was working under a contract of service when:

- the contract has terminated; and

- the disentitlement is being terminated from the date the contract ended; and

- the client is capable of and available for work and poses no restrictions towards accepting employment.

A Level 1 officer can render the decision to terminate a 1 - Not unemployed disentitlement (D1) on a renewal claim when:

- the D1 was previously imposed as the client was working in insurable employment when requesting benefits; and

- the client confirms no longer being employed with that employer; and

- the client is capable of and available for work and poses no restrictions towards accepting employment.

**11. Teachers requesting benefits during a non-teaching period – EIR33**

A Level 1 officer can render the decision to allow benefits in a non-teaching period when:

- the client is requesting maternity benefits, parental benefits, FCB or CCB; or

- all the client’s teaching employment in the qualifying period (QP) was on a casual, on call, or occasional basis during the teaching period; and

- the client does not have a signed or verbal contract for a subsequent teaching period; or

- the client had a contract which terminated; and

- the client does not have a signed, or verbal contract for a subsequent teaching period.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0341.dita) 

**12. Parental benefits and death of the child –EIA 23**

A Level 1 officer can render the decision to impose a 34 - Parental benefits entitlement conditions not met disentitlement (D34) when:

- the child for which the client is requesting parental benefits died; and

- the client agrees that no benefits are payable from the Monday following the week of the death of the child; and

- if parental benefits have been paid after the week of the child’s death, the client contacts Service Canada within 6 weeks from the date the claimant’s report processed.

A Level 1 officer can render the decision to rescind or terminate a D34 imposed because of the death of a child when:

- the client requests a BT other than parental and is entitled to that BT; or

- the client is entitled to parental benefits while caring for another child.

**13. Modification of an existing disentitlement – special benefits**

A Level 1 officer can render the decision to rescind or terminate a disentitlement on a continuing or renewal claim for special benefits when:

- the client is entitled to the requested BT; and

- the client has submitted all required documents for the period during which special benefits are requested; and

- if sickness benefits are requested, the disentitlement is not related to non-availability, not otherwise available, SE or labour dispute.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0342.dita) 

A Level 1 officer can render the decision to allow special benefits on continuing or renewal claim when:

- there is an outstanding disqualification or disentitlement on the claim due to a contentious RFS; and

- the client is entitled to the requested BT; and

- the client has submitted all required documents for the period during which special benefits are requested; and

- the client is requesting benefits after the BPC week.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0343.dita) 

A Level 1 officer can render the decision to terminate a disentitlement on a claim for CCB to allow another BT on a continuing or renewal claim when:

- the client is requesting a conversion from CCB to another BT; and

- there is a 51 - Does not meet compassionate care entitlement conditions disentitlement (D51), a 52 - Compassionate care benefits exhausted disentitlement (D52) or a 53 - Compassionate care benefits - No medical proof disentitlement (D53) on file; and

- the date from which the client is requesting the conversion is after the weeks of CCB requested; and

- the client meets the entitlement conditions for the requested BT; and

- if the client requests regular or sickness benefits, there is no disentitlement on file related to availability, not otherwise available, SE or a labour dispute; and

- if the client requests regular benefits, the reasons for not returning to work can be allowed at Level 1; or

- if the client requests special benefits, the reason for not returning to work can be allowed at Level 1 and is related to the requested BT.

A Level 1 officer can render the decision to terminate a disentitlement on a claim for FCB to allow another BT on a continuing or renewal claim when:

- the client is requesting a conversion from FCB to another BT; and

- there is a 61 - Family caregiver for children or adults - Does not meet entitlement conditions disentitlement (D61), a 62 - Family caregiver for children or adults – Benefits exhausted disentitlement (D62) or a 63 - Family caregiver for children or adults - No Medical Proof disentitlement (D63) on file; and

- the date from which the client is requesting the conversion is after the later of either the weeks requested or the required care or support date on the medical certificate; and

- the client meets the entitlement conditions for the requested BT; and

- if the client requests regular or sickness benefits, there is no disentitlement on file related to availability, not otherwise available, SE or a labour dispute; and

- if the client requests regular benefits, the reason for not returning to work can be allowed at Level 1; or

- if the client requests special benefits, the reason for not returning to work can be allowed at Level 1 and is related to the requested BT.

**14. Reconsideration — EIA52;112**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0344.dita) 

A Level 1 officer can render the decision to reconsider a claim under EIA 52 when:
       [EIA 52](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html)

- the initial decision was made by a Level 1 officer, and it was within their authority to make that decision; and

- the reconsideration is required because new information has been received; or

- the reconsideration is required to correct an error that is contrary to the structure of the act ; and ;
         [contrary to the structure of the act ;](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-17/reconsideration.html#a17_3_3_2)

- the new information is received, or the error is discovered and actioned within the 36-month reconsideration timeframe; or

- if the new information is received after the 36-month reconsideration timeframe, a Level 2 ROD is on file, extending the timeframe to 72 months.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0345.dita) 

A Level 1 officer can render the decision to maintain, modify or rescind an initial decision when:

- a formal request for reconsideration (RFR) was received under section 112 of the EIA; and

- the initial decision was rendered at Level 1 and was within Level 1 authority to render that decision; or

- an Integrity PSO or ISO completed an investigation with an earnings allocation that did not result in a warning letter, notice of violation or penalty; and

- the officer making the decision has been formally trained in RFR; and

- the RFR was received within the prescribed 30-day timeframe; or

- if the RFR was delayed, it was received no more than 120 days after the individual was notified of the initial decision.

**15. EI Emergency Response Benefit (EI ERB) Claims— EIA52;112;153.5(2) and (3);153.6(1);153.9(1), (2), and (4);153.1303(Temporary measure)**

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0346.dita) 

A Level 1 officer can render the decision to retroactively impose a 31 - EI ERB entitlement conditions not met disentitlement (D31) on an EI ERB claim when:

- a Request for Clarification letter (i.e. C-74-01-03 or C-74-01-06/07) was sent to the client; and

- the client did not respond to the letter, and it was not returned undeliverable; or

- the client responded to the letter and does not dispute the ineligibility to the EI ERB that was paid; and

- the client did not have $5000 in insured earnings in 2019 or in the 52 weeks preceding the date on which the EI ERB claim was made; and

- the client would not have been able to establish a BP under EIA 153.5(2)(b) ; and
         [EIA 153.5(2)(b)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html)

- the EI ERB claim being reconsidered is within 36 months of when the benefits were paid or payable; and

- the client does not meet the eligibility conditions for part, or the entire period of the EI ERB claim; and

- there are no contentious issues that would prevent the Level 1 officer from imposing the D31.

A Level 1 officer can consider an EI ERB claim in order when:

- the client meets the eligibility conditions for the 2-week period of the EI ERB claim by:

- meeting one of the definitions of claimant under EIA 153.5(2) ; and
             [EIA 153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html)

- meeting the related eligibility conditions under EIA 153.9(1) ; and
             [EIA 153.9(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

- there are no other circumstances that would make the client ineligible under EIA 153.9 .
         [EIA 153.9](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

A Level 1 officer can render the decision to rescind a D31 when:

- the Level 1 imposed the D31 in error; and

- the client has not provided any new information; and

- the Level 1 officer imposed the D31 in error based on the information available at the time the decision was made.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0347.dita) 

A Level 1 officer can render the decision to maintain, modify or rescind an initial decision related to an EI ERB claim when:

- a request for reconsideration was received under EIA 112 ; and
         [EIA 112](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-112.html)

- the request for reconsideration is related to a decision on an EI ERB claim under EIA 153.5(2) and 153.9(1), (2) or (4) ; and
         [EIA 153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html) 
         [153.9(1), (2) or (4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

- a Level 1 officer rendered the decision; or

- an Integrity Program Services Officer or Integrity Services Officer rendered the decision on an EI ERB investigation under EIA 153.5(2) and 153.9(1), (2) or (4) ; and
         [EIA 153.5(2)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.5.html) 
         [153.9(1), (2) or (4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.9.html)

- the officer making the decision has been formally trained in requests for reconsideration; and

- the request for reconsideration was received within the prescribed 30-day timeframe; or

- the request for reconsideration was delayed, but was received no more than 120 days after the individual was notified of the initial decision; and

- there are no contentious issues related to the EI ERB claim that would prevent the Level 1 officer from rendering a decision; and

- there is no outstanding Integrity EI ERB investigation. 

### Note

Source topic: `en_EN/common_notes/note_c_0328.dita`

Note:

This note applies only to the authority immediately above and no other authorities unless otherwise specified. If the client provides multiple reasons for the delay in applying for benefits and at least one of those reasons is in the above list and covers the entire period of the delay, the Level 1 officer can allow the antedate. 

### Note

Source topic: `en_EN/common_notes/note_c_0329.dita`

Note:

This note applies only to authority immediately above and no other authorities unless otherwise specified. If the client provides multiple reasons for the delay in applying for benefits and at least one of those reasons is in the above list and covers the entire period of the delay, the Level 1 officer can allow the antedate. 

### Note

Source topic: `en_EN/common_notes/note_c_0330.dita`

Note:

If the client is out of Canada for a reason other than vacation, the Level 1 officer refers to Out of Canada .
       [Out of Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s6)

     [Out of Canada](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s6) 

### Note

Source topic: `en_EN/common_notes/note_c_0331.dita`

Note:

When a client declares training up to 9 hours per week, additional fact-finding or follow-up with the client is not required. 

### Note

Source topic: `en_EN/common_notes/note_c_0332.dita`

Note:

The Level 1 officer does not have the authority to decide whether or not to impose or terminate the disentitlement. The Level 1 officer only has the authority to implement the decision rendered by the appropriate delegated authority. 

### Note

Source topic: `en_EN/common_notes/note_c_0333.dita`

Note:

Availability must also be adjudicated when the client is out of Canada and in receipt of regular benefits. Please refer to the Availability section of this policy.
       [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s3)

     [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s3) 

### Note

Source topic: `en_EN/common_notes/note_c_0334.dita`

Note:

Availability must also be adjudicated when the client is out of Canada and in receipt of regular benefits. Please refer to the Availability section of this policy.
       [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s3)

The client is only entitled to benefits for a maximum of 7 days to visit an immediate family member who is seriously ill or injured. The additional 7 days to attend the funeral of that immediate family member cannot include any time period before the death of the immediate family member. Refer to sub-section 10.11.8.1 of the Digest of Benefit Entitlement Principles for additional guidance on the above situation and counting the days.
       [sub-section 10.11.8.1 of the Digest of Benefit Entitlement Principles](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/absence-from-home.html)

     [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s3) 
     [sub-section 10.11.8.1 of the Digest of Benefit Entitlement Principles](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/absence-from-home.html) 

### Note

Source topic: `en_EN/common_notes/note_c_0335.dita`

Note:

Availability must also be adjudicated when the client is out of Canada and in receipt of regular or Sickness benefits. Please refer to the Availability section of this policy.
       [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s3)

Refer to sub-section 10.11.8.1 of the Digest of Benefit Entitlement Principles for additional guidance on the above situation and counting the days.
       [sub-section 10.11.8.1 of the Digest of Benefit Entitlement Principles](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/absence-from-home.html)

     [Availability](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s3) 
     [sub-section 10.11.8.1 of the Digest of Benefit Entitlement Principles](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/absence-from-home.html) 

### Note

Source topic: `en_EN/common_notes/note_c_0336.dita`

Note:

This section applies to allocation of earnings and the correction of claimant’s reports. 

### Note

Source topic: `en_EN/common_notes/note_c_0337.dita`

Note:

If the error correction request for issues other than earnings also involves earnings and exceeds the 6-week timeframe, the full correction request (including the earnings) must be referred to Level 2. 

### Note

Source topic: `en_EN/common_notes/note_c_0338.dita`

Note:

This note applies to the authorities in the dismissal section. The Level 1 officer does not need to confirm the reason for dismissal with the employer if the comment on the ROE is one of the following:

- being unsuitable;

- not passing training;

- being terminated within the probationary period. 

### Note

Source topic: `en_EN/common_notes/note_c_0339.dita`

Note:

Officers adjudicating voluntary leave issues must differentiate temporary and permanent employment as follows:

- Temporary employment is defined as a seasonal, contract, or term employment, and has an end date.

- Permanent employment is defined as a lasting employment, or an employment that is intended to last or to remain unchanged indefinitely. It has no end date. 

### Note

Source topic: `en_EN/common_notes/note_c_0340.dita`

Note:

When the client reports working for a spouse, a common-law partner, or a person with whom the client is romantically involved, the Level 1 officer reassigns the issue to Level 2 for adjudication. 

### Note

Source topic: `en_EN/common_notes/note_c_0341.dita`

Note:

A Level 1 officer can allow claims for maternity, parental, family caregiver and CCB claims during the teaching period. However, claims for regular or sickness benefits submitted by teachers under a contract of service during the teaching period must be referred to a Level 2 officer for adjudication. 

### Note

Source topic: `en_EN/common_notes/note_c_0342.dita`

Note:

A client is not required to demonstrate good cause for the delay in submitting a medical certificate. A Level 1 officer is authorized to modify or rescind an existing disentitlement for a missing medical certificate for special benefits, regardless of the length of delay in submitting the medical certificate, provided the above conditions are met. 

### Note

Source topic: `en_EN/common_notes/note_c_0343.dita`

Note:

If sickness benefits are requested and a disentitlement was imposed due to non-availability (e.g. a client voluntarily left the employment due to family obligations or took a leave of absence to attend non-referred training), SE or labour dispute the Level 1 officer refers the decision to Level 2. 

### Note

Source topic: `en_EN/common_notes/note_c_0344.dita`

Note:

For corrections of Claimant’s reports please refer to section 7 of this policy.
       [section 7](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s7)

     [section 7](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes#s7) 

### Note

Source topic: `en_EN/common_notes/note_c_0345.dita`

Note:

The 36-month reconsideration timeframe is calculated from the date benefits were paid or should have been payable. Commission errors are corrected currently, and no OP will be created, unless the Commission error resulted in a decision that is contrary to the structure of the Act.

In situations of a recalculation where the ROE was submitted late, the L1 officer must first determine if the delay can be allowed according to the LOD policy, if not a L2 decision is required for the delay. 

### Note

Source topic: `en_EN/common_notes/note_c_0346.dita`

Note:

Only officers assigned to a specialized team for the reconsideration of the EI ERB claims have the following authority.

EIA 153.8 defines an EI ERB claim as a 2-week period starting on a Sunday between March 15, 2020, and October 3, 2020. In the context of the EI ERB, a claim refers to a 2-week period and not the entire period during which a client was receiving the EI ERB.
       [EIA 153.8](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html)

     [EIA 153.8](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-153.8.html) 

### Note

Source topic: `en_EN/common_notes/note_c_0347.dita`

Note:

A Level 1 officer cannot use the above authority to render a new decision on a claim. The intended purpose of this authority is to allow a Level 1 officer to correct an input error. If the client comes forward with new information related to the decision made on the claim, a reconsideration is required. A level 1 officer can only reconsider a claim when specified by the Levels of Decision Policy. 

## Background

Source topic: `en_EN/policy/nationalpolicy/levels_decision-annex1/background.dita`

## Untitled

Source topic: `en_EN/policy/nationalpolicy/levels_decision-annex1/untitled.dita`

**** 
