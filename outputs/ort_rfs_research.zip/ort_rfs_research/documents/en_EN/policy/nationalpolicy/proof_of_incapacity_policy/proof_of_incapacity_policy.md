# Proof of Incapacity Policy

Source map: `en_EN/policy/nationalpolicy/proof_of_incapacity_policy/proof_of_incapacity_policy.ditamap`

## Introduction

Source topic: `en_EN/policy/nationalpolicy/proof_of_incapacity_policy/introduction.dita`

Table of Contents

- 1. Introduction
         [1. Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_1)

- 2. Policy objective
         [2. Policy objective](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_2)

- 3. Determining when a medical certificate is required

- 3.1 Initial and renewal claims
             [3.1 Initial and renewal claims](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_3_1)

- 3.2 Conversions from regular to sickness benefitss
             [3.2 Conversions from regular to sickness benefitss](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_3_2)

- 3.3 Subsequent period of incapacity
             [3.3 Subsequent period of incapacity](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_3_3)

         [3. Determining when a medical certificate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_3)

- 4. Particular situations where proof of incapacity is required

- 4.1 Special scenarios where a medical certificate is required
             [4.1 Special scenarios where a medical certificate is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_1)

- 4.2 Sickness benefits prior to maternity benefits
             [4.2 Sickness benefits prior to maternity benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_2)

- 4.3 Sickness benefits during or after collecting other special benefits
             [4.3 Sickness benefits during or after collecting other special benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_3)

- 4.4 Self Employed Benefits
             [4.4 Self Employed Benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_4)

- 4.5 Fishing benefits
             [4.5 Fishing benefits](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_5)

         [4. Particular situations where proof of incapacity is required](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4)

- 5. Incapacity start date

- 5.1 Determining the incapacity start week
             [5.1 Determining the incapacity start week](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_5_1)

- 5.2 Subsequent period of incapacity - Gaps
             [5.2 Subsequent period of incapacity - Gaps](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_5_2)

         [5. Incapacity start date](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_5)

- 6. The recovery date to use when a medical certificate is provided

- 6.1 Specific recovery date provided
             [6.1 Specific recovery date provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_6_1)

- 6.2 Undetermined, unknown, uncertain or indefinite recovery dates
             [6.2 Undetermined, unknown, uncertain or indefinite recovery dates](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_6_2)

- 6.3 Terminal or palliative
             [6.3 Terminal or palliative](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_6_3)

         [6. The recovery date to use when a medical certificate is provided](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_6)

- 7. Early Recovery and Gradual return to work

- 7.1 Early Recovery
             [7.1 Early Recovery](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_7_1)

- 7.2 Gradual return to work
             [7.2 Gradual return to work](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_7_2)

         [7. Early Recovery and Gradual return to work](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_7)

- 8. Responsibilities

- 8.1 National Headquarters
             [8.1 National Headquarters](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_8_1)

- 8.2 Regions and Call Centres
             [8.2 Regions and Call Centres](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_8_2)

         [8. Responsibilities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_8)

**1. Introduction**

EIR 40 states that a medical certificate is required to prove the inability to work.
       [EIR 40](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-40.html)

“ 40 (1) The information and evidence to be provided to the Commission by a claimant in order to prove inability to work because of illness, injury or quarantine under paragraph 18(1)(b) or subsection 152.03(1) of the Act, is a medical certificate completed by a medical doctor or other medical professional attesting to the claimant’s inability to work and stating the probable duration of the illness, injury or quarantine.” In keeping with this regulatory requirement, when clients apply for sickness benefits, they are advised to obtain and retain a medical certificate for a period of six (6) years to support their claim for EI sickness benefits.

In keeping with this regulatory requirement, when clients apply for sickness benefits, they are advised to obtain and retain a medical certificate for a period of six (6) years to support their claim for EI sickness benefits.

One of the main findings in the Evaluation of Employment Insurance Sickness Benefits was a majority of clients did not use the maximum weeks of EI sickness benefits.  In fact, for those who did not exhaust those benefits, the average duration of sickness benefits was 9 weeks.  Findings such as this, as well as post-payment compliance reviews done by Integrity Services Branch on sickness claims, have allowed us to conclude there is low risk to providing flexibility in paying some initial weeks of sickness benefits without the immediate receipt of a medical certificate. However, paying longer periods of sickness benefits without proof of incapacity increases the risk of paying benefits for which entitlement cannot in fact be proven.
       [Evaluation of Employment Insurance Sickness Benefits](https://can01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.canada.ca%2Fen%2Femployment-social-development%2Fcorporate%2Freports%2Fevaluations%2Fei-sickness-benefits.html%23mainfind&data=05%7C01%7Cdeanne.field%40servicecanada.gc.ca%7C5698e969b6f041b306c608dbe0c3e77e%7C9ed558468a814246acd8b1a01abfc0d1%7C0%7C0%7C638350904229694917%7CUnknown%7CTWFpbGZsb3d8eyJWIjoiMC4wLjAwMDAiLCJQIjoiV2luMzIiLCJBTiI6Ik1haWwiLCJXVCI6Mn0%3D%7C3000%7C%7C%7C&sdata=a0HlXN0pGQP7YnHirmq3shyZDjr82rsEAA4g3U7%2Fyqw%3D&reserved=0)

**2. Policy objective**

In seeking an appropriate balance between stewardship of the EI account and service delivery, this policy specifies:

- how many weeks of sickness benefits are payable initially without the submission of a medical certificate;

- when the client will be required to submit a medical certificate to the Commission;

- what incapacity start date to utilize when it is unclear on a medical certificate;

- how gaps between periods of incapacity should be addressed;

- what recovery week should be used when the medical professional does not provide an exact recovery date on the medical certificate.

**3. Determining when a medical certificate is required**

A medical certificate will not be required from the onset of a claim for sickness benefits in some cases. Certain factors can mitigate the risks associated with this operational policy. For example, initial and renewal claims with a RFS from the last employer of “ D – illness or injury ”  lower the risk of not requesting the medical certificate from the start of a claim for sickness benefits, as there is some corroborating evidence that clients have also requested sick leave from their employer.  Sickness Benefits Compliance Reviews, in which medical certificates are requested for periods where sickness benefits were paid without a medical certificate, continue to be completed by Integrity Services.

**3.1 Initial and renewal claims**

For BPC’s of April 7, 2024 (w/c 2442) and later, a client applying for sickness benefits on an initial or renewal application does not initially need to submit a medical certificate when the reason for separation from the last employment is “ D - illness or injury”. A recovery week of BPC + 8 or renewal week + 8 can be allowed without receipt of a medical certificate, including when sickness is requested prior to maternity (see section 4.2 of this policy for additional considerations when paying sickness prior to maternity benefits). If further sickness benefits are needed beyond this initial period, medical proof is required to allow an extension up to a maximum of 26 weeks.
       [section 4.2](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_4_2)

In situations where the RFS from the last employer is not “ D – illness or injury,” a medical certificate must be submitted prior to the payment of any weeks of sickness benefits.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0364.dita) 

**3.2 Conversions from regular to sickness benefits**

The following outlines when a medical certificate must be requested when converting a claim from regular to sickness benefits:

- If no weeks of casual sickness* have been paid, officers can allow the week of conversion + 8 without requesting a medical certificate. After this period, the client must submit their medical certificate(s) to receive additional sickness benefits.

- If weeks of casual sickness have been paid prior to the request for conversion (including situations when a trip down occurs after 4 consecutive weeks of casual sickness), officers can allow up to 8 weeks from week of conversion, minus the number of casual sickness weeks already paid, without requesting a medical certificate. If the client has already been paid 8 weeks of casual sickness, a medical certificate must be submitted for any further weeks of sickness to be paid.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0365.dita) 

**3.3 Subsequent periods of incapacity**

Any period of illness beyond the BPC, renewal or conversion week plus the weeks of sickness benefits allowed, will require a medical certificate to substantiate further payment of sickness benefits beyond the initial period allowed. This applies regardless of the number of weeks requested by the client.

**4. Other situations where proof of incapacity is required**

**4.1 Special scenarios where a medical certificate is required**

In the following situations a medical certificate is required prior to the payment of any sickness benefits:

- Clients who have sufficient hours to qualify for special benefits, but not for regular benefits, and whose RFS for the most recent period of employment is not “ D - illness or injury”;

- Clients who have been disqualified from or disentitled to regular benefits;

- Clients wishing to collect sickness benefits after exhausting their regular benefits;

- Clients who are minor attached and whose RFS for the most recent period of employment is not “ D - illness or injury ”.

     [Info](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0366.dita) 

**4.2 Sickness benefits prior to maternity benefits**

Clients can collect sickness in their maternity window provided they are “otherwise available for work.”  As per Digest 12.3.2 - Sickness benefits within the maternity period there are specific parameters whereby a client can collect sickness in their maternity window.  Even if the RFS on the ROE is “ D ”, the same adjudication principles will apply.
       [Digest 12.3.2 - Sickness benefits within the maternity period](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-12/maternity-benefits-special-benefits.html#a12_3_2)

In all cases, when the conditions are met to pay sickness prior to maternity, sickness benefits are only payable up to the week prior to confinement week unless provided for in BE Memo 2020-01 - Payment of Sickness Benefits for the Week of Expected Date of Confinement or Actual Date of Confinement .
       [BE Memo 2020-01 - Payment of Sickness Benefits for the Week of Expected Date of Confinement or Actual Date of Confinement](/en/policy/bememo/be2020-01.shtml)

**4.3 Sickness benefits during or after collecting other special benefits**

Clients who are collecting Maternity, Parental, QPIP, Family Caregiver Benefits (FCB) or CCB may convert to sickness benefits regardless of the RFS in the following scenarios:

- During the initial benefit period

- In the extended benefit period if sickness benefits were collected during the initial benefit period.

A medical certificate is required to be submitted for all weeks of sickness benefits requested in the above cases.

- BE Memo 2013-07 – Sickness Claims while in receipt of Maternity Benefits
         [BE Memo 2013-07 – Sickness Claims while in receipt of Maternity Benefits](/en/policy/bememo/be2013-07.shtml)

- BE Memo 2013-02 – Sickness Claims for Claimants in Receipt of Parental Benefits
         [BE Memo 2013-02 – Sickness Claims for Claimants in Receipt of Parental Benefits](/en/policy/bememo/be2013-02.shtml)

- BE Memo 2014-04 – Sickness Claims for Claimants in Receipt of FCB and CCB
         [BE Memo 2014-04 – Sickness Claims for Claimants in Receipt of FCB and CCB](/en/policy/bememo/be2014-04.shtml)

**4.4 Self Employed Benefits**

A medical certificate must be submitted for all weeks of sickness benefits requested for the Self Employed as there is no third-party validation of the RFS on a ROE.

**4.5 Fishing benefits**

Fishing clients wishing to collect sickness benefits, other than casual sickness, must provide a medical certificate for all requests for sickness benefits at any point during the claim as there is no RFS of “ D – illness or injury” on a fishing ROE to mitigate the risk.

**5. Incapacity start date**

**5.1 Determining the incapacity start week**

On an initial or renewal claim, when the RFS is “D” and no medical certificate needs to be submitted, the incapacity start week is the BPC or renewal week.

In all other situations, the incapacity start date is the Sunday of the week in which the medical professional indicates the client became incapacitated. If no specific incapacity start date is provided, the incapacity start date is the Sunday of either the week in which the client was seen, or the week in which the medical professional signed the medical certificate (whichever is earlier).

**5.2 Subsequent period of incapacity - Gaps**

When a medical certificate is provided for a subsequent period of incapacity and the incapacity start date is not immediately following the recovery week on file, if there is no indication on the medical certificate that the period of incapacity is continuous from the initial period of incapacity, then the client must provide a medical certificate for the gap in order to receive benefits for that period.

**6. The recovery date to use when a medical certificate is provided**

**6.1 Specific recovery date provided**

If a specific recovery date is provided on a medical certificate, this must be used. Officers are not to use an indefinite recovery date (9999) when a specific recovery date is provided on a medical certificate, even if it is longer than the maximum 26 weeks payable.

     [Callout](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0367.dita) 

**6.2 Undetermined, unknown, uncertain or indefinite recovery date**

When a medical certificate has an undetermined, unknown, uncertain or indefinite recovery date, officers can allow a recovery week of incapacity start week (as defined in section 5.1 of this policy) + 8. The same applies for each subsequent medical certificate received with similar wording. Officers should not use an indefinite recovery date (9999).
       [section 5.1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/proof_of_incapacity_policy#ch_5_1)

**6.3 Terminal or palliative**

An illness is terminal when it will likely lead to death; palliative refers to end of life care. When a medical certificate (initial or subsequent) indicates the client is “terminal” or “palliative,” officers can allow an indefinite recovery week (9999) regardless of how many weeks of sickness benefits have been paid. However, the claim will not be postdated unless the client requests it or there is indication on the file that the client will be able to collect the full 26 weeks of sickness benefits.

**7. Early Recovery and Gradual return to work (RTW)**

**7.1 Early Recovery**

At all times, regardless of whether a medical was requested or not, the onus is on the client to declare an early recovery to ensure they are only paid benefits to which they are entitled.

A client collecting sickness benefits may indicate they are ready, willing and capable of working and wish to convert to regular benefits before the end of the initial period of sickness benefits allowed. If no medical certificate was requested, and there is no medical certificate on file indicating a longer incapacity date, no medical certificate is required to prove capacity for work.

When the recovery is prior to a recovery date indicated on a medical certificate that was submitted to the Commission, then the client will need to provide a medical certificate attesting to their recovery.

**7.2 Gradual return to work (RTW)**

A client who has not completely recovered but has been authorized by a medical professional to gradually RTW may receive partial sickness or partial regular benefits depending on the circumstances of their recovery ( Digest 10.7.4 - Part-time availability ). This will be dependent on how many weeks of entitlement remain as the client may wish to utilize partial payment of one type of benefits over another, and under which benefits they meet the entitlement conditions.
       [medical professional](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-11/unable-to-work.html#a11_2_2) 
       [Digest 10.7.4 - Part-time availability](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/hours-obligations-religious.html#a10_7_4)

The client must provide a medical certificate showing the medical professional’s authorization to RTW and any limitations for a gradual RTW. The medical certificate must include details such as the duration of the gradual RTW, the days or hours the client can work and the client’s abilities or lack thereof, all of which allow for adjudication and determination of the client’s availability based on these limitations ( Digest 10.10.0 – Health and physical capabilities ).
       [Digest 10.10.0 – Health and physical capabilities](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-10/health-physical-capabilities.html#a10_10_0)

**8. Responsibilities**

**8.1 National Headquarters**

National Headquarters is responsible for developing and applying this policy. It is also responsible for developing and maintaining processes, tools, and procedures, as well as developing training for policy implementation.

**8.2 Regions and Call Centres**

Regional EI Processing and Payment Directors and Managers, Regional Integrity Services Directors and Managers and EI Call Centre Directors and Managers are responsible for ensuring implementation of the policy, and for ensuring no deviations are made without the express consent of the EI Operational Policy Director. 

### Info

Source topic: `en_EN/common_notes/note_c_0364.dita`

Note: For BPC’s prior to April 7, 2024 (w/c 2442) a recovery week of BPC +15 was allowed when the RFS from the last employment was “D - illness or injury”. 

### Info

Source topic: `en_EN/common_notes/note_c_0365.dita`

*Casual sickness refers to weeks of sickness benefits paid on a regular or fishing claim type 

### Info

Source topic: `en_EN/common_notes/note_c_0366.dita`

Note: Clients who are minor attached and stop work due to illness, injury or quarantine are not eligible for sickness benefits ( EIA 21(1) ), even if a medical certificate is provided.
       [EIA 21(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-21.html#h-216150)

     [EIA 21(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-21.html#h-216150) 

### Callout

Source topic: `en_EN/common_notes/note_c_0367.dita`

Example:

A client provides a medical certificate with a recovery date of 8 months in the future. The recovery date is entered as 8 months from BPC, but the client recovers earlier than the 8 months and did not receive all their sickness benefit entitlement. If the client applies for the remaining weeks of sickness benefits after the 8-month recovery date is passed, they would be required to submit another medical certificate to support their incapacity. However, if an indefinite recovery date (9999) was input rather than the actual recovery date, and the client applies for the remaining weeks of sickness benefits after the original 8-month recovery date, this could allow the client to receive sickness benefits they may not be entitled to. They would have to provide proof of incapacity for this new period. 

## Background

Source topic: `en_EN/policy/nationalpolicy/proof_of_incapacity_policy/background.dita`

## Untitled

Source topic: `en_EN/policy/nationalpolicy/proof_of_incapacity_policy/untitled.dita`

**** 
