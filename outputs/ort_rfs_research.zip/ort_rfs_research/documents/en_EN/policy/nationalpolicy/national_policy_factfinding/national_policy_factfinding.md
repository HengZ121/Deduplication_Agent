# Fact-Finding and Documentation Policy

Source map: `en_EN/policy/nationalpolicy/national_policy_factfinding/national_policy_factfinding.ditamap`

## Introduction

Source topic: `en_EN/policy/nationalpolicy/national_policy_factfinding/introduction.dita`

Updated February 22, 2024

Table of contents

- Introduction
         [Introduction](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s1)

- Policy Objectives
         [Policy Objectives](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s2)

- Fact-Finding: the Basis of a Sound Decision

- 3.1 Fact-Finding Responsibilities
             [Fact-Finding Responsibilities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_1)

- 3.2 Client, Employers and Third Parties: Who Can Provide Information?

- 3.2.1 Client
                 [Client](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_2_1)

- 3.2.2 Employer
                 [Employer](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_2_2)

- 3.2.3 Third party (witness)
                 [Third party (witness)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_2_3)

             [Client, Employers and Third Parties: Who Can Provide Information?](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_2)

- 3.3 Fact-Finding in Cases of Voluntary Leaving for Strictly Personal Reasons
             [Fact-Finding in Cases of Voluntary Leaving for Strictly Personal Reasons](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_3)

- 3.4 Fact-Finding in Cases of Sexual Harassment and Other Sensitive Situations
             [Fact-Finding in Cases of Sexual Harassment and Other Sensitive Situations](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_4)

- 3.5 Fact-Finding with a minor (person under the age of majority)
             [Fact-Finding with a minor (person under the age of majority)](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_5)

- 3.6 Attempts Made to Obtain Documentation or to Conduct Fact-Finding
             [Attempts Made to Obtain Documentation or to Conduct Fact-Finding](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_6)

         [Fact-Finding: the Basis of a Sound Decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3)

- Documentation: the Cornerstone of a Sound Decision

- 4.1 Essential Claim Elements
             [Essential Claim Elements](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_1)

- 4.2 Obtaining and Documenting Information
             [Obtaining and Documenting Information](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_2)

- 4.3 Electronic and Paper Documents

- 4.3.1 Transcription of Paper Documentation into an Electronic Format
                 [Transcription of Paper Documentation into an Electronic Format](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_3_1)

- 4.3.2 Electronically Transmitting Documentation
                 [Electronically Transmitting Documentation](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_3_2)

             [Electronic and Paper Documents](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_3)

- 4.4 Documenting the Decision and Rationale

- 4.4.1 Discretionary Authority
                 [Discretionary Authority](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_4_1)

             [Documenting the Decision and Rationale](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_4)

- 4.5 Notification of the Decision
             [Notification of the Decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_5)

- 4.6 Official Languages
             [Official Languages](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_6)

- 4.7 Confidentiality
             [Confidentiality](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_7)

- 4.8 Protection of Informants
             [Protection of Informants](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_8)

         [Documentation: the Cornerstone of a Sound Decision](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4)

- Information Management and Retention
         [Information Management and Retention](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s5)

- Responsibilities

- 6.1 National Headquarters
             [National Headquarters](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s6_1)

- 6.2 Regions and Call Centres
             [Regions and Call Centres](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s6_2)

         [Responsibilities](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s6)

**1. Introduction**

On behalf of the Canada EI Commission (the Commission), Service Canada is required to collect all relevant information to render and support decisions about qualifying for and entitlement to EI benefits. Failure to obtain all relevant facts and documents to make a sound decision can result in an inaccurate decision being made and the creation of unnecessary requests for reconsideration. The Commission is accountable for the payment and non-payment of EI benefits. Insufficient evidence or the inability to produce evidence resulted in unfavourable decisions for the Commission by the Social Security Tribunal (SST) and the Federal Courts. It has also limited the Commission’s ability to prosecute or penalize clients who abuse the EI program.

EIA 48 provides the Commission with the authority to obtain information to determine if a client is qualified for and entitled to benefits, and it requires that the Commission notify the client of any decision about entitlement to benefits. This policy provides guidelines for fact-finding and documentation used in the decision-making process. It does not provide instructions on how to handle particular situations.
       [EIA 48](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

This policy does not outline the requirements relating to document retention. The authority for the disposal of EI documents belongs to ESDC , which in turn is responsible for developing a policy on document retention and disposal.
       [ESDC](https://iservice.prv/eng/imit/ims/clients/index.shtml) 

## Background

Source topic: `en_EN/policy/nationalpolicy/national_policy_factfinding/background.dita`

## 2. Policy Objectives

Source topic: `en_EN/policy/nationalpolicy/national_policy_factfinding/2_policy_objectives.dita`

**2. Policy Objectives**

This policy establishes the principles and guidelines for obtaining and gathering the information used in the decision-making process. It links the methods of documentation to the requirements of accountability by outlining what is needed to support the Commission’s decision on whether the client qualifies for or is entitled to benefits. Ultimately, the Commission must be able to show how, why, and on what basis the decision was made. The facts used to support the decision must be clearly indicated.

The policy:

- outlines general principles for fact-finding responsibilities, taking into consideration the complexity of various adjudication issues;

- stresses the importance of comprehensive fact-finding to support each decision affecting whether a client is qualified for or entitled to benefits;

- details the requirements to ensure decisions are properly documented;

- ensures any documents that support a decision for the payment or non-payment of benefits are obtained.

**3. Fact-Finding: the Basis of a Sound Decision**

Fact-finding is an important part in the decision-making process. The ability to obtain detailed information from relevant parties is key to that process. To assist in obtaining the necessary information, the 5 Ws (who, what, where, when, why) should be considered when fact-finding, as this will help develop questions.

Incomplete fact-finding can result in an unsupported or incorrect decision. It can also cause delays in establishing claims, and result in frustration for clients and employers.

Before starting fact-finding, the officer must first be aware of the issues at hand and determine what facts are already on file. Facts needed to render a decision can be obtained, not only from the WI assigned, but also from the EI application, the ROE, client, employer or third-party statements (outlined in section 3.2 ), or any other supporting documentation. Therefore, it is essential to review the entire file in detail before starting fact-finding. Completing a thorough review of all documentation, system applications, uploaded or imaged documents and outstanding WIs is the first step in becoming familiar with the claim. Reviewing all relevant information before conducting fact-finding will ensure the officer is prepared and will help determine what additional questions must be asked.
       [section 3.2](/en/policy/nationalpolicy/national_policy_factfinding.shtml#s3_2)

Facts used to render a decision must be relevant to the issue being adjudicated. Determining what is relevant is a matter of understanding the principles of the EIA and EIR as they apply to a particular issue. Often, information provided may not be relevant to the issue being adjudicated. If it is not clear if the information is relevant, additional fact-finding may be required.

Before the first question is asked, the time should be taken to ensure the client understands what the qualifying and entitlement conditions associated with EI benefits are, why the questions are being asked, and how the information will be used. It should also be explained which other parties will be contacted (the employer) and how Service Canada will proceed if the client wishes to not provide any additional information. Similarly, other interested parties must also be made aware of how the information will be used.

All questions should be asked in an appropriate tone and asked in a manner that is easy to understand.

Entitlement to benefits is determined on the basis of proof. The party who has the burden of proof must provide factual evidence to support its position. Documentary evidence of the facts is crucial in deciding whether the burden of proof has been met. The Commission is ultimately responsible for administering the EI Act. Therefore, in all cases, the Commission is responsible for requesting and documenting the facts upon which the decision is based.

In situations where the client has been dismissed or has voluntarily left their employment, EIA 51 states the employer and the client must have equal opportunity to provide information. Therefore, there must be no allegations on file that have not been presented to the client and the employer for explanation or clarification. Final rebuttal must always be given to the client.
       [EIA 51](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-51.html)

Fact-finding is considered complete when no questions remain unanswered and full understanding of the events or actions that occurred is obtained. Fact-finding is a key function of an officer’s role. If fact-finding is not conducted in a thorough manner, it will lead to incorrect decisions, increased requests for reconsideration and poor client service.

The following questions can be used to determine whether fact-finding is complete:

- Have all interested parties been contacted?

- Have all parties been made aware of the other parties’ statement and been provided the opportunity to rebut the statement?

- Was the client given the final rebuttal?

- Is the timeline of events established?

- Have all gaps in time or information been clarified?

- Does the information lead to a decision that can be supported considering the balance of probabilities?

All of these questions will help answer the 5 Ws (who, what, where, when, why) to ensure complete fact-finding.

Facts and rationales are the key elements in any decision. They show what the decision was based on, as well as why and how the officer reached a specific decision for an issue.

A decision must be based on EI legislation, and the facts to support the decision must be evident. The decision is weak if the facts are not apparent. When the facts are not documented, one may logically conclude they were not obtained in the first place. A decision made without facts is not a sound decision. A decision made in this manner is open to question and interpretation as it is not substantiated with facts. It could raise the appearance of unfair treatment or that the client’s rights were not respected.

**3.1 Fact-Finding Responsibilities**

The level of the officer responsible for conducting fact-finding is based on the complexity of the issue.

Level 1 officers are responsible for conducting fact-finding related to issues that can only lead to one possible and readily apparent conclusion, including decisions that have been delegated to Level 1 as part of the National Policy on Levels of Decision .
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

Level 2 officers are responsible for fact-finding on all issues that cannot be adjudicated at Level 1. Level 2 decisions are complex in nature, require judgement, and involve in-depth fact-finding.

In certain circumstances, the adjudication of a contentious RFS may be deferred when a client requests and qualifies for special benefits or when a benefit period cannot be established (BPNE) for a variety of reasons. In situations for which the adjudication of the RFS is deferred, the fact-finding can also be deferred. The decision to defer the adjudication of the RFS must be documented on the claim, including the reason for the deferral. Deferral of adjudication can occur at both Level 1 and Level 2, depending on the complexity of the substantive issue and the reason for the deferral. Operational policies and procedures are to be consulted to determine if a deferral of adjudication is appropriate.

When reviewing the information and work items, if it is determined an Integrity Services investigation may be required, the responsibility to conduct fact-finding and documentation shifts to Integrity Services. No further fact-finding should be conducted by processing or call centre officers and the issue should be immediately referred to Integrity Services. Any information obtained should be appropriately documented on the claim.

For post-audit claims referred by Integrity Services to processing, officers must return files with incomplete fact-finding to Integrity Services.

**3.2 Client, Employers and Third Parties: Who Can Provide Information?**

**3.2.1 Client**

According to EIA 2(1) , a claimant (client) is defined as a person who has applied for benefits under the EIA. EIA 50(5) stipulates that the Commission may at any time require a client to provide additional information about their claim for benefits. Fact-finding to obtain a client’s version of events must be conducted directly with the client. The exception to the EIA is EIR 27 , which allows for a representative to act on behalf of a client if the person has a mental disability, is incapacitated or is deceased.
       [EIA 2(1)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-2.html) 
       [EIA 50(5)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html) 
       [EIR 27](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-27.html)

A third party may act as an interpreter for a client (e.g. in the case of a language barrier), but the client must be with the third party and all questions must be translated by the third party to the client. Similarly, the client’s response must be translated to the officer. In these situations, the third party cannot provide responses on the client’s behalf. They may only act as an interpreter.

**3.2.2 Employer**

EIA 51 states that employers and clients must be given an opportunity to provide information as to the reasons for the loss of employment. When there is a loss of employment resulting from the client’s misconduct, or if the client voluntarily left employment, the employer must always be given the opportunity to provide information relating to the event.
       [EIA 51](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-51.html)

EIA 126(14) provides the Commission with the lawful authority to obtain EI-related information about a specific person who is applying for, receiving, or has received EI benefits.
       [EIA 126(14)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-126.html)

Under the Personal Information Protection and Electronic Documents Act , when necessary, employers should be informed that the disclosure of personal information without the knowledge or consent of the person can be made to a government institution that has:
       [Personal Information Protection and Electronic Documents Act](/en/policy/nationalpolicy/pipeda_qa.shtml)

- requested the information;

- determined its lawful authority to obtain the information;

- indicated that the disclosure is requested for the purpose of administering any law of Canada.

**3.2.3 Third party (witness)**

Fact-finding can be conducted with a third party (witness) to obtain their version of events if the third party has first-hand knowledge of the situation. The third party’s statement cannot be based on hearsay or the accounts of others who were involved in the event. It must be what the third party directly witnessed.

A third party such as a union representative can also provide first-hand insight into the work environment and the relationships between employees and management. A union representative may also have direct knowledge related to specific issues.

**3.3 Fact-Finding in Cases of Voluntary Leaving for Strictly Personal Reasons**

If the RFS is purely personal, but further information is required to render a decision, officers should call the client first to conduct further fact-finding. Depending on the client’s response, it may not be necessary to contact the employer.

If the employer produces an ROE indicating the client voluntarily left the employment and the client states they did so for strictly personal reasons (e.g. a return to school or a career change), it may not be necessary to contact the employer to confirm these facts, provided both conditions are met:

- the facts are credible and reasonable;

- based on the circumstances, it is unlikely that the employer would have any information in relation to the existence or non-existence of other reasonable alternatives.

The employer’s version of the facts would be required in cases where reasonable alternatives to leaving may have been available. For example, if a client left employment due to childcare issues, fact-finding with the employer would be needed to confirm if the client had requested a temporary leave from that employment or a change in work schedule to accommodate their childcare issues.

**3.4 Fact-Finding in Cases of Sexual Harassment and Other Sensitive Situations**

If the client indicates they have lost their employment because of sexual harassment or other sensitive situations, the officer must adapt the fact-finding to the specific circumstances of the case. The Commission’s responsibility to offer the client, as well as the employer, an opportunity to provide information about the RFS still applies when allegations of sexual harassment are present. However, when the employer is asked to provide information on the RFS, their version is accepted as stated and documented to the claim file. At no time during the fact-finding stage will the statement given by the client be revealed to the employer, unless the client agrees to such disclosure, or the employer specifically mentions it. Digest 6.5.2 should be consulted when adjudicating these types of RFS.
       [6.5.2](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/circumstances-reflected-legislation.html#a6_5_2)

**3.5 Fact-Finding with a minor (person under the age of majority)**

A minor is defined as a person under the age of majority. There is no specific age in Canada at which point a minor is considered mature enough to make decisions that affect them. Each Canadian province and territory is responsible for determining the age of majority in its province or territory. For this policy only, a minor is considered a person under the age of 18.

In this section the term parent can also mean a legal guardian or trusted adult.

When Service Canada initiates contact with the minor to obtain information regarding their EI claim, prior to obtaining any information, an offer to have a parent present during the conversation must be made. If the fact-finding with the minor is regarding a contentious issue, the minor should be strongly encouraged to have a parent present during the discussion.

The minor is not required to have a parent present during discussions with Service Canada., However the offer to have a parent present is to ensure the minor feels safe during these conversations and has a proper understanding of the questions being asked during the interaction. In all cases, the offer to have a parent present and the minor’s response must be documented on an SROC.

**3.6 Attempts Made to Obtain Documentation or to Conduct Fact-Finding**

In some cases, the officer is unable to reach a client.  In other situations, clients or employers are not willing to provide information, even after the impact of not providing the requested information is explained by the officer. In all cases, efforts must be made to obtain the necessary information and these efforts must be documented.

The Commission’s preferred method of fact-finding and communication is the telephone, as it is the most efficient method. A minimum of 2 attempts, 24 hours apart and at different times of day, must be made and the interested party must be given a minimum of 24 hours from the last attempt to return the officer’s call. For a telephone call to be considered a successful attempt, the officer must speak with the interested party or leave a message for the individual. Every attempt must be documented on the file, including if a message was left.

If the officer is unable to reach the client by telephone or leave a message, an email or letter is sent to the client requesting to contact the officer. Clients are given 48 hours to respond to an email and 10 business days to respond to a letter.

If an employer cannot be reached by telephone and a message cannot be left, a letter is sent requesting the employer contact the officer. Employers are given 10 business days to respond to the letter.

If there is no return call, response to the email or letters sent, a decision must be made with the information available on file.

The documentation on file is often used when a client contacts Service Canada to enquire about the status of their claim. The notes allow the officer reviewing the claim to advise the client of what steps have been taken, whether an officer is trying to reach them for additional information and whether any documents are required. If a decision is made without the employer or client statements because they refused to provide information or they could not be reached, it is important to have the documentation on file to show attempts were made to obtain the information. This will further strengthen the decision and demonstrate due care in attempting to obtain the information.

If the employer is contacted but refuses to provide the information requested, the impact must be explained. If the employer does not provide the information requested, the decision must be made without the employer’s input. It is imperative to document the conversation with the employer to ensure it is clear the employer’s rights under EIA 51 were respected. In these cases, the rationale for the decision must indicate the employer failed to provide information after being asked and advised of the consequences of not doing so. The employer’s failure to provide information does not mean benefits should automatically be allowed. The decision must be made using the facts available.
       [EIA 51](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-51.html)

For example, if the client indicates a dismissal due to theft and admits to the theft, but the employer is unreachable or declines to comment, benefits could be denied based upon the client’s statement. All factors must still be considered before making a decision.

EIA 50 provides the authority to request additional information from a client about their EI claim. If a client fails to provide the requested additional information, the client is not entitled to receive benefits and a 15 - Claim Procedure disentitlement (D15) for a failure to supply ROEs or other requested information is imposed until they comply. In this context, a D15 can only be imposed when the client has failed to provide specific additional information requested to prove their entitlement to benefits. A generic disentitlement must not be imposed simply because general fact-finding attempts were unsuccessful, or one or more parties do not wish to provide further information related to an issue that requires adjudication. In these cases, the Commission renders a decision on the substantive issue using the facts available.
       [EIA 50](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-50.html)

A manual action (MA) is a temporary means to avoid an overpayment (OP) on a continuing claim, specifically in situations where there is a strong indication the client may not be entitled to benefits, but further fact-finding is required before a decision can be made. An MA should not be imposed for extended periods of time as no decision has been communicated to the client and no reconsideration rights provided.

**4. Documentation: The Cornerstone of a Sound Decision**

A decision must be well documented to demonstrate that it is based only on relevant facts and is a correct and fair application of the law. By establishing and reinforcing the basic principles of fact-finding and documentation, officers are ensuring all decisions are made in a fair and transparent manner. Decisions must be able to withstand scrutiny in any kind of monitoring, audit, review, reconsideration, appeal process, or court proceedings.

Although clients do not always agree with decisions, in general they are more satisfied if they understand the reasons for a decision and their concerns and explanations were heard and considered. The documentation must show the client was listened to objectively, was provided with the opportunity to rebut information provided by other relevant parties and the decision was made based on the facts and free from any biases.

The principles of natural justice is a term used in the legal community to describe 2 principles that are taken into consideration when making a decision:

- The first principle states a decision made must be made in an impartial manner.

- The second principle highlights that a decision cannot stand unless the person directly affected was given a fair chance to state their case and to respond to the other side’s statement.

The principles of natural justice must be applied in decisions regarding entitlement to EI benefits. This ensures that all decisions are fair and impartial.

As previously mentioned, the Commission is accountable for the payment and non-payment of EI benefits. A lack of documentation leaves room for suspicion that a decision was not based on the evidence presented. It raises doubt that fairness and the principles of natural justice were respected in rendering the decision.

Obtaining supporting documentation is very important as it further supports the decision. For example, if a client is dismissed for not respecting an employer policy, documentation demonstrating the client was aware of the policy should be obtained from the employer as it may further support the decision. If the client has been charged criminally, it is important to obtain a copy of any release conditions as it may impact the client’s employment or availability. Every attempt must be made to obtain all relevant documentation from the client and the employer. If documentation is not available a decision must be made based upon the information gathered from the relevant parties.

Information obtained to support entitlement decisions must be gathered and handled as outlined in the Information Categorization Tool on iService.
       [Information Categorization Tool](https://iservice.prv/eng/is/security/categorization/index.shtml)

**4.1 Essential Claim Elements**

A claim must contain evidence of authority for the payment of benefits. In the broadest terms, this authority means documentation which shows:

- who applied for benefits;

- an EI application authorized by the client, either by electronic signature under EIR 91(2) or other acceptable means of identity verification;
         [EIR 91(2)](https://laws-lois.justice.gc.ca/eng/regulations/SOR-96-332/section-91.html)

- ROEs;

- who authorized the payment or denied the payment of benefits;

- what period was authorized or denied;

- why payments were allowed, denied or reinstated (e.g. evidence and rationale for decisions when required);

- valid documents or statements supporting the type of benefits claimed (e.g. a medical certificate, when required, to support payment of sickness benefits or a voluntary leave for medical reasons).

When the responses provided on the application clearly indicate that the client meets the entitlement conditions, no further documentation is required and no rationale for the decision to allow benefits is necessary. For example, if a client responds No to the question Are you self-employed, other than fishing or farming? on the EI application, no additional fact-finding is required on that issue.

If there is any doubt concerning whether the client qualifies for benefits or meets the entitlement conditions, supplementary information is required.

**4.2 Obtaining and Documenting Information**

Generally, the SROC in NWS is the appropriate form to use when documenting information and statements during the fact-finding process. At times other mediums are used to document information and as such will be specified in operational procedures. The details required depend on the complexity of the decision to be made. The more complex the issue or controversial a decision is, the more detailed fact-finding is required.

Officers usually obtain supplementary information by conducting telephone interviews with clients, employers or other relevant parties as Service Canada primarily uses this method. It is the most efficient manner to obtain detailed information from the relevant parties. If there were unsuccessful attempts to contact the relevant party or the type of information required necessitates a formal document (e.g. medical certificate), other means should be used such as sending a letter or email. National Checklists and Forms for Claims Processing were developed to assist Level 1 officers in gathering the necessary information to render a decision. The use of checklists is encouraged to ensure all appropriate facts are gathered and documented on the claim and ensures information can be easily found when reviewing the claim.
       [National Checklists and Forms for Claims Processing](https://esdc.prv/en/service-canada/ei/reference-material/forms/national_checklists.shtml)

When contacting the client by telephone or receiving a call from a client, the client’s identity must be validated to ensure their privacy is being upheld under Privacy Act 8(1) . The Commission must ensure that no personal information that it holds is disclosed without the client’s consent. This is why the client’s identity must always be validated before disclosing any information. It is imperative the client’s personal information is safeguarded at all times.
       [Privacy Act 8(1)](https://laws-lois.justice.gc.ca/eng/acts/P-21/section-8.html)

When an officer conducts fact-finding, the conversation must be documented in a thorough manner and include the following information:

- the client’s identity was validated;

- who obtained and documented the information;

- who was interviewed, and, if other than the client, their relationship to the client or their name and position if in relation to the employer;

- the date and time of the conversation;

- the purpose of the interview (issue);

- the information obtained (facts).

If there were unsuccessful attempts to reach a client, employer or third party by telephone, the following information must be documented on an SROC:

- the telephone number called;

- the dates and times of the attempts;

- the purpose of the attempt (issue);

- whether a message was left on a voicemail or with a person and the name of the person who took the message.

Records of conversations are to be written objectively, clearly, in a professional tone and free of typographic, spelling or basic grammatical errors. Gender-neutral language and preferred pronouns should be respected. Abbreviations and acronyms should not be used unless spelled out in full at least once within the document. Internal EI jargon should not be used at all. Sentences are not mandatory; point form is acceptable, but not at the expense of content and comprehension. Statements do not have to be word for word, but should clearly and accurately reflect the discussions that took place between the officer and the client, employer or third party. The record of conversation can be written in a narrative, question and answer or statement format, ensuring consistency throughout. It must be easy to read and clear as to who provided the information. It is recommended the written statement be reviewed with the party prior to ending the conversation to ensure it has been accurately documented. This also gives the party an opportunity to provide information they may not have included in their statement. Reviewing the statement with the party lends credibility to the statement if the party later rebuts it.

Each interview should be recorded in a separate SROC, for example, one SROC for one call, 2 SROCs for 2 calls. Different contentious issues (e.g. voluntary leaving or training) are to be documented in separate SROCs because in the event of a request for reconsideration or an appeal to the EI Board of Appeal (EI BOA), only information regarding the issue under reconsideration or appeal must be included. Failure to separate the issues on SROCs results in additional work to redact the information that is not required. It also increases the risk of a privacy breach if information that is not relevant to the request for reconsideration or the appeal is shared with an interested party (e.g. employer).

The SROC should be completed and saved promptly to ensure the documentation is reflective of what the client or employer stated. This also enhances the credibility of the documentation. It is important to note the attempts made to contact the client or employer to demonstrate the Commission’s due care in the event of an audit, a request for reconsideration or appeal of the decision.

Personal opinions or interpretations of the interview made by officers have no place in the fact-finding and documentation process. The credibility of statements is assessed at the decision-making stage and not when information is documented. Conclusions must be left to the responsible officer, once all relevant and required facts have been obtained.

EI entitlement decisions must be based on information provided by the parties involved. Public content sites (e.g. social media sites, newspaper articles) are not to be consulted to determine the client’s entitlement to benefits. If there is publicly available information (e.g. client was dismissed because of comments they made on social media) that is relevant to the decision, the information must be submitted to the Commission as supporting documentation by the client or the employer for consideration, as is the case with any other supporting documentation.

It is necessary to document any correction or amendment made. For example, if an ROE is determined to be incorrect, the correction must be documented because it may affect the outcome of the claim calculation. It must be apparent from the documentation why and how the ROE was corrected, who was contacted to obtain the corrected information and what the outcome of the correction was. In other words, there must be a validation for the correction to provide the link between what appears on the original ROE and the actual decision made in the calculation of the claim. Under no circumstances should Service Canada employees make corrections directly on an original document, as this will compromise the legality of that document.

**4.3 Electronic and Paper Documents**

A number of provisions in the EIA allow the Commission to carry out business electronically. EIA 2(3) confirms that any reference in the EIA to any kind of document includes those in electronic format. For the purpose of this policy, references to documentation include electronic as well as paper documents.
       [EIA 2(3)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-2.html)

The Canada Evidence Act places controls on the form in which records are admissible in legal proceedings. Generally, paper documentation is the most accepted form of evidence. However, if it is not possible or reasonably feasible to produce a paper record, the Canada Evidence Act stipulates what is acceptable.
       [Canada Evidence Act](https://laws-lois.justice.gc.ca/eng/acts/c-5/) 
       [Canada Evidence Act](https://laws-lois.justice.gc.ca/eng/acts/c-5/)

The electronic format is the Commission’s preferred method of collecting and storing documentation. The current processes for EI benefits enable clients to complete their EI application and their claimant’s reports electronically. Documents and statements are documented electronically, and decisions, letters and notices sent to clients are stored electronically.

Service Canada’s systems and software cannot always accommodate the format of the source document received. For example, if an employer sends an electronic document that cannot be opened because the required software is not available or because of restrictions under the ESDC Network Use Directive , efforts should be made to determine if the issue can be solved internally. If not, the sender should be contacted to request the material be sent in a format that will allow Service Canada to access the contents.
       [ESDC Network Use Directive](https://iservice.prv/eng/is/security/tools_and_resources/toolkit/network_use_directive.shtml)

**4.3.1 Transcription of Paper Documentation into an Electronic Format**

Processes and guidelines have been developed to enable the transcription and imaging of paper documentation (medical certificates, ROEs, forms, etc.) to an electronic format. Documents transcribed into electronic format can be used to determine if a client qualifies for or is entitled to benefits. Refer to Section 5 of this Policy for further details on information management and retention of paper documents.
       [Section 5](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s5)

**4.3.2 Electronically Transmitting Documentation**

Safeguarding information is of utmost importance; therefore, the fact-finding functions performed by Service Canada are not done electronically unless approved secure channels are in place.

Fact-finding by email or text message is prohibited . However, an email template can be completed and sent through ACS for the sole purpose of initiating fact-finding by telephone with the client.

The Document upload feature in MSCA allows clients to submit their supporting documentation in a secure and efficient manner to Service Canada. If a client requests to send documentation by email, they should be encouraged to use the Document upload feature instead. Currently, employers are unable to upload documentation to Service Canada. Most employers prefer to submit documents by email rather than submitting them by mail or fax.

At this time, the only secure channels for an employer to submit documentation to Service Canada is by mail or in person at a Service Canada Centre. Employers should be discouraged from using any other method of transmitting the documents. Additional resources can be found on the Departmental Security page regarding the secure transmission of sensitive information.
       [Departmental Security](https://iservice.prv/eng/is/security/index.shtml)

During fact-finding, a relevant party may request that an officer registers to receive secure email messages related to a request for information and documentation. Officers are not permitted to use these secure email services and the ESDC Network Use Directive prohibits officers from using a government email address to register for such services.
       [ESDC Network Use Directive](https://iservice.prv/eng/is/security/tools_and_resources/toolkit/network_use_directive.shtml)

**4.4 Documenting the Decision and Rationale**

Essential documents, adequate fact-finding and appropriate documentation are required to support all decisions.

Decisions vary in their complexity and in the degree to which they must be supported by evidence and by a written rationale. It can at times be unclear as to who is responsible for rendering the decision. However, there is a consistent process to follow for all decisions. The EI Table of Authorities and the National Policy on Levels of Decision provide some direction on that subject. The level of the officer that is to render the decision is based on the officer’s work description, their authority under the EI Table of Authorities and the National Policy on Levels of Decision , their training, and the complexity of the issue.
       [EI Table of Authorities](https://iservice.prv/eng/finance/DELEG/effective/ei/employment_insurance_table_authorities.pdf) 
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml) 
       [EI Table of Authorities](https://iservice.prv/eng/finance/DELEG/effective/ei/employment_insurance_table_authorities.pdf) 
       [National Policy on Levels of Decision](/en/policy/nationalpolicy/levels_decision.shtml)

Level 1 decisions may require a record of decision (ROD). Operational procedures are to be consulted to determine when a Level 1 ROD is required.

Level 2 decisions require a ROD. These decisions are based on information gathered by conducting fact-finding with all involved parties. Once the fact-finding is complete, a decision is rendered by reviewing all information gathered and the credibility of the source of the information, consulting the Digest, interpreting the EIA and EIR, applying jurisprudence, and demonstrating judgment and discretion. Rationales must indicate the issue adjudicated and explain why the decision was made. The ROD must include references to support the decision (EIA, EIR, Digest, etc.). It should also include references to relevant and recent jurisprudence, as well as any other resource material used to render and support the decision.

A rationale must demonstrate the principles of natural justice were respected. The link must be made between the facts and the decision made. Personal feelings, opinions and beliefs are never to be used to justify a decision, as the legislation must support the decision.

Rationales should not be a summary of all the evidence gathered but should include a highlight of the relevant evidence. Rationales, therefore, should be concise, but contain references, if relevant, to benefit of the doubt, credibility and reasonable alternatives, as these are often critical components when rendering a decision.

A separate ROD is required for each individual decision ensuring the heading is specific to the issue, the decision and the employer (when applicable). This allows for better organization of the claim file and increases efficiencies when reviewing the claim. Decisions on all contentious issues must be adjudicated unless otherwise provided for by operational policy and advised in the procedures. As an example, if the client is disqualified because of the RFS and availability is also of concern, then availability also needs to be adjudicated regardless of the outcome of the adjudication of the other contentious issue. This is important in the event the client appeals and gets one of the decisions overturned.

**4.4.1 Discretionary Authority**

Based on the wording in particular sections of the EIA 1 , the Commission has additional obligations to provide a detailed rationale for its decision in some cases. The Federal Court has established that:

- some decisions are made under a discretionary authority, which belongs solely to the Commission;

- the EI BOA cannot cancel or modify decisions that were made by the Commission, using its discretionary authority, unless the Commission has failed to demonstrate that it exercised its discretionary authority in a judicious manner 2 ;

- the test of whether a discretionary authority has been exercised judiciously is based solely on the written rationale for the decision.

A decision rendered under a discretionary authority must meet an even higher standard when documenting the rationale for the decision. The written rationale must explain what factors were used in making the discretionary decision and what, if any, factors were ignored. The rationale must provide a full explanation of how and why, the decision was made.

For example, when misrepresentation is proven, the decision to impose a penalty and the determination of the penalty amount is a discretionary decision. The officer must clearly indicate in a ROD what facts were considered and what facts were excluded in deciding that a penalty is warranted. The officer must also demonstrate how the amount of the penalty was calculated to show the Commission rendered this decision judiciously.

     [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0359.dita) 

**4.5 Notification of the Decision**

EIA 48(3) states that the Commission is required to make a decision related to the client’s initial claim for benefits and to notify the client of that decision. EIA 53 provides that the Commission can notify the person in a manner it considers adequate.
       [EIA 48(3)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html) 
       [EIA 53](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-53.html)

The EIA does not provide for the situations in which the client must be notified verbally or in writing. To ensure consistency in the application of EIA 48(3) , this policy outlines when a client must be notified verbally or in writing of a decision made on their claim and informed of their right to request reconsideration:
       [EIA 48(3)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-48.html)

- A client must be notified both verbally and in writing of a negative Level 2 decision and given the right to reconsideration or appeal. The requirement to provide both verbal and written notification of the decision to the client in this circumstance is to ensure the client has been given the opportunity to provide any facts the client may have previously forgotten to provide that may impact the decision made on their claim. The written notification is to ensure the client is aware of their right to reconsideration and is the Commission’s proof that the decision and reconsideration rights have been given to the client.

- A client must be notified and given their right to reconsideration when a Level 1 decision results in the non-payment of benefits. The notification can be verbal or written. The notification must include the client’s right to reconsideration. If the client is verbally notified of this decision, is advised of their right to reconsideration and agrees with the decision, no letter is required unless specified in procedures. If the client does not understand or agree with the decision rendered, the Level 1 officer sends a written notification to the client. The Commission must be able to demonstrate that the client received notification and in which manner it was delivered. Therefore, it must be readily apparent when reviewing a claim file whether the client received verbal or written notification.

- A client must be notified in writing of the agreement start and end dates and given the right to reconsideration when a client opts in, cancels or terminates the agreement for the benefits for the self-employed.

All attempts to contact a client to provide verbal notification of a negative decision must be documented on an SROC. When it is clear during the Level 2 fact-finding with the client that the contentious issue will not be allowed, the Level 2 officer can document the verbal notification of a negative decision clearly at the end of the same SROC as the fact-finding related to that issue. This is only allowed when the client is notified of the negative decision in the same telephone call as the fact-finding is conducted. In cases where separate telephone calls are made to conduct fact-finding with the client and then to notify the client of the decision, separate SROCs are needed. On an SROC, the Level 2 officer must document the date and time the decision was communicated during the telephone call, and if the client provided any additional information at the time of notification. The SROC must contain detailed information as outlined in section 4.2 of this policy. Leaving a voicemail or a message with a third party is not acceptable and does not constitute verbal communication of the decision. In all cases, written notification must be sent to the client when a contentious issue has not been allowed. To ensure proper interpretation of what is meant by attempts in relation to contacting an interested party, refer to section 3.6 of this policy.
       [section 4.2](https://ort-orl.esdc-edsc.canada.ca/en/policy/nationalpolicy/national_policy_factfinding.shtml#s4_2) 
       [section 3.6](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s3_6)

If employers are considered interested parties, the employers must be notified in writing of the Commission’s decision to pay benefits and of their right to request reconsideration. Employers are considered relevant parties on issues of misconduct and labour disputes, as well as on issues of voluntary leaving and refusal of employment, if the reasons for leaving or refusal are work-related.

**4.6 Official Languages**

Part IV of the Official Languages Act extends rights to any member of the public in Canada to communicate with and to receive available services from federal institutions in the official language of their choice. It also establishes that every federal institution has the duty to ensure any member of the public can communicate with and obtain available services from its head or central office in either official language and has the same duty with respect to any of its other offices or facilities.
       [Part IV of the Official Languages Act](https://laws-lois.justice.gc.ca/eng/acts/O-3.01/page-2.html#h-384282)

Communication with the public in their official language of choice, whether written or oral, takes precedence over an officer’s right to work in the official language of their choice. Officers must document information received from the client in the official language indicated on the claim in the following situations:

- when providing service to a client in person or by telephone;

- when communicating a decision to a client.

The official language of communication chosen by the client must be respected and accommodated. When a client chooses to communicate in an official language other than the one specified on the claim, officers are required to document the client’s statements in the language used by the client when making the statement. This will ensure the Department’s obligations under Part IV of the Official Languages Act and related regulations are upheld.
       [Part IV of the Official Languages Act](https://laws-lois.justice.gc.ca/eng/acts/O-3.01/page-2.html#h-384282)

Statements obtained from other parties (an employer or a person other than the client) must be documented in the official language used by the person providing the information, even if it differs from the official language chosen by the client.

Part V of the Official Languages Act sets out the circumstances in which employees in certain regions have the right to use English or French when working within a federal department (e.g. when they are participating in meetings, receiving instructions or writing internal documents).
       [Part V of the Official Languages Act](https://laws-lois.justice.gc.ca/eng/acts/O-3.01/page-2.html#h-384351)

A ROD for a non-discretionary decision is considered an internal working document created by an officer during the course of their work. The officer indicates and summarizes in the ROD the relevant facts, the jurisprudence, the principles of adjudication and other references used to render the decision. It is not a means of communication used to relay the decision to the client. Therefore, it does not need to be written in the client’s language of choice, or translated, if the client requests a copy of their file under the Privacy Act . If the ROD is for a discretionary decision, it should be written in the language preferred by the client. Additional information on discretionary authority can be found in section 4.4.1 of this policy.
       [Privacy Act](https://laws-lois.justice.gc.ca/eng/acts/p-21/index.html) 
       [section 4.4.1](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/policy/nationalpolicy/national_policy_factfinding#s4_4_1)

**4.7 Confidentiality**

Although EI claim file information is subject to the Privacy Act and the Access to Information Act , these files are not classified as confidential documents, given that in the event of an appeal, the employer may access details provided by a client about an employer and vice versa. Furthermore, claim information is, in fact, potentially available to the public. For example, members of the public can, in certain circumstances, attend EI BOA, Federal Court or Supreme Court hearings.
       [Privacy Act](https://laws.justice.gc.ca/eng/acts/p-21/page-1.html) 
       [Access to Information Act](https://laws.justice.gc.ca/eng/acts/A-1/index.html)

Jurisprudence (SST, EI BOA, Federal and Supreme Court decisions), which often refers to information in the appeal documents, is public information.

Officers must provide these explanations on confidentiality to any person who provides a statement and asks that information they have provided be kept confidential and this is why officers must be careful when writing reports of interviews that include personal information.

In addition, if the client, employer or third party requests the information they provided be kept confidential, officers must advise them that by doing so, the information cannot be taken into consideration when making the decision, except in the situation of voluntary leaving for sexual harassment (refer to section 6.4.4 of the Digest ).
       [section 6.4.4 of the Digest](https://www.canada.ca/en/employment-social-development/programs/ei/ei-list/reports/digest/chapter-6/test-for-cause.html#a6_4_4)

**4.8 Protection of Informants**

When a person, other than the client involved, or a Government of Canada employee provides any information containing an allegation, a suspicion or a fact that a person is involved in misrepresentation or abuse of EI benefits, it is considered a third-party referral.

Third party referrals are protected. Any information that might reveal the identity of an informant must never be divulged and should be kept in such a way that would prevent disclosure. Third party information and all additional information associated to the referral must be documented on paper. It must never be documented on the claim. Service Canada employees should use the Third Party Information (INS5204 ) form.
       [Third Party Information (INS5204](http://forms-formulaires.prv/lc/content/EForms/en/Detail.html?Form=INS5204&login_result=0&ap=1)

**5. Information Management and Retention**

The Commission bears the responsibility to collect the necessary information to support decisions in regard to a claim for EI benefits. However, ESDC is responsible for the retention and disposition of the documentation collected.
       [ESDC](https://iservice.prv/eng/imit/ims/clients/index.shtml)

All information, regardless of its medium or format, must be maintained in a manner that ensures its authenticity, accuracy, integrity, availability and completeness, for as long as it is required. The inability to produce documentation when required could undermine decisions and question credibility. The documentation collected provides the factual basis for reconsideration and appeal purposes, claim audits, or for the resolution of any dispute regarding a decision, whether it is through an internal process, an appeal system or court proceedings.

Documentation collected or received must be identified and maintained in accordance with sound records management practices and principles. Documentation received or created belongs to the department and ultimately to the Government of Canada.

The Policy on Service and Digital as well as the Directive on Service and Digital outline the requirements that must be followed when owning, accessing and safeguarding records. Accountability regarding the decision to destroy records and the timing of the destruction is solely the responsibility of ESDC .
       [Policy on Service and Digital](https://www.tbs-sct.canada.ca/pol/doc-eng.aspx?id=32603) 
       [Directive on Service and Digital](https://www.tbs-sct.gc.ca/pol/doc-eng.aspx?id=32601) 
       [ESDC](https://iservice.prv/eng/imit/ims/clients/index.shtml)

Access to records is granted under the need to know principle. Therefore, employees may have access only to the records they require to perform their work.

**6. Responsibilities**

**6.1 National Headquarters (NHQ)**

NHQ is responsible for developing and applying this policy. It is also responsible for developing and maintaining processes, tools and procedures, as well as developing training for policy implementation.

**6.2 Regions and Call Centres**

Regional EI Processing and Payment Directors and Managers, Regional Integrity Services Directors and Managers and EI Call Centre Directors and Managers are responsible for ensuring implementation of the policy and for ensuring no deviations are made without the express consent of the EI Operational Policy Director. 

### Note

Source topic: `en_EN/common_notes/note_c_0359.dita`

Note:

- Decisions made under EIA 7.1(4) , 28 , 38 , 39 , 41 , 41.1 , 52 , and 111 are considered by the Courts to be made under a discretionary authority. An indication to this effect is that some of these sections stipulate “the Commission may.”
         [EIA 7.1(4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.1.html) 
         [28](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-28.html) 
         [38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html) 
         [39](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-39.html) 
         [41](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.html) 
         [41.1](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html) 
         [52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 
         [111](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-111.html)

- McLean ( FCA A-549-99 ), Chartier ( FCA A-42-90 ).
         [FCA A-549-99](http://www.ei.gc.ca/eng/policy/appeals/Federal-Court/Federal_Court_of_Appeals/A054999.shtml) 
         [FCA A-42-90](https://www.ei.gc.ca/eng/policy/appeals/Federal-Court/Federal_Court_of_Appeals/A004290.shtml)

     [EIA 7.1(4)](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-7.1.html) 
     [28](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-28.html) 
     [38](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-38.html) 
     [39](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-39.html) 
     [41](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.html) 
     [41.1](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-41.1.html) 
     [52](http://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-52.html) 
     [111](https://laws-lois.justice.gc.ca/eng/acts/E-5.6/section-111.html) 
     [FCA A-549-99](http://www.ei.gc.ca/eng/policy/appeals/Federal-Court/Federal_Court_of_Appeals/A054999.shtml) 
     [FCA A-42-90](https://www.ei.gc.ca/eng/policy/appeals/Federal-Court/Federal_Court_of_Appeals/A004290.shtml) 
