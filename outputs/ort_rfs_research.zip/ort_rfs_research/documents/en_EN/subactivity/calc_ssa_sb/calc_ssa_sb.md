# Calculating a claim in SSO

Source map: `en_EN/subactivity/calc_ssa_sb/calc_ssa_sb.ditamap`

## Summary

Source topic: `en_EN/subactivity/calc_ssa_sb/summary.dita`

Summary: Once it is determined that the claim is ready to be calculated, the officer enters SSO and calculates the claim. 

## What you need to know

Source topic: `en_EN/subactivity/calc_ssa_sb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/subactivity/calc_ssa_sb/untitled_section.dita`

[Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0019.dita) 

Pages in SSO are pre-filled with the information provided on the application. In the majority of cases, this information is correct and can be accepted. However, in some cases, the officer must change this information before proceeding with the calculation of the claim.

SSO highlights in yellow some data discrepancies, but there may be additional information that was obtained after the client completed the application in AW which requires changes in SSO. Using the notes taken while determining if a claim is ready for calculation, the officer reviews each SSO screen to correct any errors, make any changes and resolve any omissions so that the information used for the calculation is accurate. 

### What you need to proceed

Source topic: `en_EN/subactivity/calc_ssa_sb/what_you_need_to_proceed.dita`

- the list of items noted while determining if a claim is ready for calculation. 

### How this sub-activity works

Source topic: `en_EN/subactivity/calc_ssa_sb/how_this_sub-activity_works.dita`

The step-by-step of this sub-activity mirrors the organization of the screens displayed once the claim has been accessed in SSO. Each step reviews a page or specific action that must be taken and identifies possible actions that may be required based on the notes taken. If necessary, the officer follows the link to take the appropriate action(s) and then returns to this page to continue to the next screen in SSO. The sequential steps must be respected unless a screen is not displayed in SSO and it is not necessary to manually create it. 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

## Regional considerations

Source topic: `en_EN/subactivity/calc_ssa_sb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/subactivity/calc_ssa_sb/what_you_need_to_look_for.dita`

## Step by step

Source topic: `en_EN/subactivity/calc_ssa_sb/step_by_step.dita`

### Level 1

Source topic: `en_EN/subactivity/calc_ssa_sb/level_1.dita`

#### Untitled section

Source topic: `en_EN/subactivity/calc_ssa_sb/untitled_section_level_1.dita`

- In SSO, review the Name and Address screen:

- Do you need to input the last job code ?
               [input the last job code](/en/procedure/task/calc_calculating/changing_ljc.shtml)

- Do you need to update the mailing and residential address information ?
               [update the mailing and residential address information](/en/procedure/task/calc_calculating/update_mail_resadd.shtml)

- Do you need to input or change the economic region ?
               [input or change the economic region](/en/procedure/task/calc_calculating/entering_cer.shtml)

- Do you need to change the tax deduction ?
               [change the tax deduction](/en/procedure/activity/changing_td.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1306.dita)

- Review the Application Form screen:

- Do you need to modify the last day worked ?
               [modify the last day worked](/en/procedure/task/calc_calculating/changing_fdw_ldw.shtml)

- Do you need to add or modify the pension information ?
               [add or modify the pension information](/en/procedure/task/calc_calculating/add_or_mod_pi.shtml)

- Do you need to modify the self-employment, trainee or farming indicator ?
               [modify the self-employment, trainee or farming indicator](/en/procedure/task/calc_calculating/indicatingssa_se_f_ti.shtml)

- Do you need to indicate that a manual Variable Best Weeks questionnaire is on file ?
               [indicate that a manual Variable Best Weeks questionnaire is on file](/en/procedure/task/calc_calculating/manual_vbw.shtml)

- Do you need to enter an approved antedate ?
               [enter an approved antedate](/en/procedure/task/calc_calculating/input_antedate.shtml)

- If the Annex - Special Benefits screen is displayed, do the following:

- If the client is applying for sickness benefits:

- Do you need to modify the sickness information ?
                   [modify the sickness information](/en/procedure/task/calc_calculating/ent_recdate_ssa_sb.shtml)

- If the client is requesting maternity benefits, is pregnant or has given birth in the last 17 weeks:

- Do you need to modify the maternity information ?
                   [modify the maternity information](/en/procedure/task/modifying_mat_sb_ssa.shtml)

- If the client is requesting parental benefits:

- Do you need to modify the parental information ?
                   [modify the parental information](/en/procedure/task/modifying_pb_sb_ssa.shtml)

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_0027.dita)

- If the client is requesting CCB:

- Do you need to modify the compassionate care information ?
                   [modify the compassionate care information](/en/procedure/task/calc_calculating/entering_ccc_ssa.shtml)

- If the client is requesting FCB:

- Do you need to modify the FCB information ?
                   [modify the FCB information](/en/procedure/task/modifying_pcic_sb_ssa.shtml)

               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1307.dita) 
               [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1308.dita)

- If you have not already done so, in RCM, verify ROEs before calculation .

- In SSO, review the Registration screen. If any required proof is missing, indicate in SSO that outstanding information is due .

- Review the Coding Requirements screen:

- Do you need to change the benefit type ?
               [change the benefit type](/en/procedure/task/calc_calculating/changing_tentative_ct.shtml)

- Have you determined that there is no interruption of earnings ?
               [no interruption of earnings](/en/procedure/task/calc_calculating/no_interruption_earnings.shtml)

- Review the Determination of Earnings screen:

- Do you need to enter a premium reduction code ?
               [enter a premium reduction code](/en/procedure/task/determining_prc_wir.shtml)

- Do you need to input workers’ compensation benefits information ?
               [input workers’ compensation benefits information](/en/procedure/task/calc_calculating/wcb_earnings.shtml)

- Do you need to input or modify the waiting period (WP) waiver ?
               [input or modify the waiting period (WP) waiver](/en/procedure/task/calc_calculating/wwp_sl.shtml)

- Do you need to input supplementary unemployment benefits coding ?
               [input supplementary unemployment benefits coding](/en/procedure/task/calc_calculating/sub_coding.shtml)

- Determine if additional annexes need to be completed:

- Do you need to extend the qualifying period ?
               [extend the qualifying period](/en/procedure/task/calc_calculating/extending_qp.shtml)

- Do you need to extend the benefit period and parental window due to the hospitalization of the child ?
               [extend the benefit period and parental window due to the hospitalization of the child](/en/procedure/task/extending_bp_par_ssa.shtml)

- Do you need to input the Annex - Special Benefits ? When a client has indicated that she is pregnant, gave birth in the last 17 weeks, or is applying for maternity benefits, the annex is required. If the annex is required, select Annex — Special Benefits and return to step 3.

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1309.dita)

- In SSO, from the Calculate menu, do the following:

- Contentious: Select the appropriate option.

- Accept: Select Yes .

- Select Next .

- Action any prompters that are displayed:

- If necessary, refer to Labour force attachment .
               [Labour force attachment](/en/procedure/task/calc_calculating/labour_force.shtml)

           [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1310.dita)

- Determine if a pop-up window displays a message in a Warning box related to variable best weeks:

- If no, go to step 12.

- If yes, on the calculation worksheet, note the warning message that is displayed and select OK . Go to step 12.

- Refer to Reviewing the calculation result . 

#### Note

Source topic: `en_EN/common_notes/note_c_1306.dita`

Note:

When the client has only one name, one of the name fields on the Name and Address screen may be empty or contain a non-alphabetical character. However, SSO does not allow the field to be completed in this way.

When a name field is empty or contains a non-alphabetical character, do the following:

- First name: Type the appropriate option:

- For a male client, type “Mr”.

- For a female client, type “Ms”.

- For a client who selected X as the gender marker, type “NA”.

- Last name: Enter the client’s name.

When the First name field on the Name and Address screen is modified to “NA,” delete the M159 - Name and Address Change / Transfer (M159) transaction generated by the calculation. If an M159 is required, enter a “.” in the First name field before transmitting it. 

#### Note

Source topic: `en_EN/common_notes/note_c_0027.dita`

Note:

If the reason for separation (RFS) on the last ROE is P - Parental and maternity benefits were requested, additional fact-finding is required. The officer contacts the employer first to ensure the RFS on the ROE is correct. If so, the officer then contacts the client to ensure the requested benefit type (BT) is correct. If the client has applied for the wrong BT, the officer refers to Determining during calculation if the client applied for the wrong benefit type .
       [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml)

     [Determining during calculation if the client applied for the wrong benefit type](/en/procedure/task/calc_determining/wrong_bt_requested.shtml) 

#### Note

Source topic: `en_EN/common_notes/note_c_1307.dita`

Note:

If the annex is triggered and is not required, delete it. 

#### Note

Source topic: `en_EN/common_notes/note_c_1308.dita`

Note:

If the Parental - Benefits requested , Compassionate care benefits requested , or Family caregiver - Benefits requested fields indicate Yes and that benefit type is not requested, change the applicable field to No . 

#### Note

Source topic: `en_EN/common_notes/note_c_1309.dita`

Note:

If an annex is triggered that is not required and is blank, delete it. To delete an annex, first select the annex you want to remove, then select Save to complete the deletion. 

#### Note

Source topic: `en_EN/common_notes/note_c_1310.dita`

Note:

If a pop-up window displays a message in an Error box related to a premium reduction code, refer to Determining if a premium reduction code is required and if the WI must be reassigned .
       [Determining if a premium reduction code is required and if the WI must be reassigned](/en/procedure/task/determining_prc_wir.shtml)

     [Determining if a premium reduction code is required and if the WI must be reassigned](/en/procedure/task/determining_prc_wir.shtml) 

## Policy reference

Source topic: `en_EN/subactivity/calc_ssa_sb/policy_reference.dita`

 
