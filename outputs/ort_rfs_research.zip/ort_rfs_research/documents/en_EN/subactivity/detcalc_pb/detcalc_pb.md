# Determining if a claim is ready to be calculated — Parental benefits

Source map: `en_EN/subactivity/detcalc_pb/detcalc_pb.ditamap`

## Summary

Source topic: `en_EN/subactivity/detcalc_pb/summary.dita`

Summary: The officer assigned to calculate the claim must first review the claim to ensure all issues are addressed and all facts required for the calculation are on file. 

## What you need to know

Source topic: `en_EN/subactivity/detcalc_pb/what_you_need_to_know.dita`

### Untitled section

Source topic: `en_EN/subactivity/detcalc_pb/untitled_section.dita`

Review the claim using this section as a guide, making notes as required. You may choose to complete the review in a checklist format. Alternatively, you may prefer to plot and make notes on a calculation worksheet or use the application Summary page.
       [checklist](/resources/ort/documents/checklist_calc_determining.doc) 
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls) 

### Paper applications

Source topic: `en_EN/subactivity/detcalc_pb/paper_applications.dita`

If a client files a paper EI application, the officer must verify in the Social Insurance Registry (SIR) database that there are no restrictions on the client’s SIN record. If there are restrictions, the officer refers this issue to Integrity and must not finalize the EI application until Integrity confirms the client’s identity. 

### Subsequent claims

Source topic: `en_EN/subactivity/detcalc_pb/subsequent_claims.dita`

When a claim is renewed with less than 5 weeks remaining to be paid, the renewal application can be used to establish a subsequent initial claim.

Clients are advised at the time of the renewal that if they work between the date of the renewal application and the date the renewed claim terminates, they must complete a new EI application. For client service purposes however, the officer can use the original renewal application to set-up the subsequent claim if the client can provide the specific details of the employment between the renewal date and the start date of the subsequent claim. An interim ROE can be used, but the officer must also advise the client to provide an ROE.

An EI application received immediately following the end of a prior claim (e.g. no entitlement is left, or the claim end week has been reached) is also considered a subsequent initial claim. The procedure used to determine the BPC of a subsequent claim is different from the procedure used for an initial claim.
       [BPC](/en/procedure/generic/knowledge.shtml#Benefit_period_commencement) 

### Pilot project no. 24: Waiving the waiting period (WP) for BPCs between March 30 andOctober 10, 2026 (w/c 2493 to w/c2572)

Source topic: `en_EN/subactivity/detcalc_pb/pilot_project_no_24_waiving_the_waiting_8da3a05b.dita`

A temporary measure to waive the one-week WP has been implemented to support clients impacted by major changes in economic conditions due to the imposition of tariffs by the United States. The WP is waived for all initial claims with a BPC between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ), regardless of the requested benefit type (BT). If it is advantageous to the client, the client can decide to serve the WP (e.g. the client must serve the WP to receive supplemental unemployment benefits [SUB]).

The WP waiver is automatically applied to all claims except claims for special benefits in which there is a SUB code. The officer must verify and enter the appropriate SUB code if the client is receiving SUB . When recalculating a claim and the only change is adding or removing a SUB plan from the ROE, the calculation result will indicate NCA - No changes to the claim . In this situation, the officer manually enters or removes the WP waiver.

A client who applies, qualifies for and is payable benefits before March 30, 2025 (w/c 2493) cannot request to postdate the start date of their claim solely to benefit from this temporary measure.

A client may request to have their claim start in the week they applied for benefits when both of the following conditions are met:

- The client applied for benefits on or after March 30, 2025 (w/c 2493).

- The Administrative Policy was applied and resulted in a BPC before March 30, 2025 (w/c 2493).

For more information, the officer refers to Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions .
       [Determining the client’s entitlement to the waived waiting period due to Pilot Project No. 24: Measures to respond to major changes in economic conditions](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml) 

### Note

Source topic: `en_EN/common_notes/note_c_0019.dita`

Note:

Unless otherwise noted, references made to calculation also apply to recalculation. 

## Regional considerations

Source topic: `en_EN/subactivity/detcalc_pb/regional_considerations.dita`

## What you need to look for

Source topic: `en_EN/subactivity/detcalc_pb/what_you_need_to_look_for.dita`

### Untitled section

Source topic: `en_EN/subactivity/detcalc_pb/untitled_section.dita`

Review the claim using this section as a guide, making notes as required. You may choose to complete the review in a checklist format. Alternatively, you may prefer to plot and make notes on a calculation worksheet or use the application Summary page.
       [checklist](/resources/ort/documents/checklist_calc_determining.doc) 
       [calculation worksheet](/resources/ort/documents/calc_worksheet.xls) 

### In FTS:

Source topic: `en_EN/subactivity/detcalc_pb/in_fts.dita`

Review the claim status and take notes if necessary:

- Under the Mainframe menu select the information technology centre (ITC) of the region where the client lives.

- What is the claim status (CS)?

- Is it a skeleton claim?

- Is there a prior renewable claim?

- If yes, go to Determining if a prior claim is renewable — Special benefits (other than sickness) .
                 [Determining if a prior claim is renewable — Special benefits (other than sickness)](/en/procedure/subactivity/det_crc_sb.shtml)

- If this is an initial claim, has it already been calculated and finalized?

- If yes, go to Completing a Claim Assessment WI — Initial claim has been calculated and finalized .
                 [Completing a Claim Assessment WI — Initial claim has been calculated and finalized](/en/procedure/task/calc_determining/alreadycalculatedfinalized.shtml)

- If this is a recalculation, was the previous calculation BPNE 2 (N2) or is there an indefinite 15 - Claim Procedure disentitlement (D15)?

- Does the CS indicate the client is deceased? 

### In NWS:

Source topic: `en_EN/subactivity/detcalc_pb/in_nws.dita`

Review the specific details of the calculation WI and take notes if necessary:

- What are the WI specifications?

- Are there any contentious issues?

- Is there an expected RTW date on file (SROCs, pending WIs, imaged or uploaded documents)?

Review processing activities for the Web application and take notes if necessary:

- What is the application date?

- What are the issues detected by ACP (refer to Automated Claims Processing ).
         [Automated Claims Processing](https://esdc.prv/en/service-canada/ei/technologies/acp/index.shtml)

Review the EI application and take notes if necessary:

- If the client applied using AW, what is the information on the Summary screen?

- If the client has indicated that the residential address differs from the mailing address, does the residential address appear valid?

- What are the dates of employment?

- Is there an expected RTW date?

- What is the RFS for all employers listed?

- Did the client delay in applying?

- If yes, is a reason for the delay indicated?

- Has the client received or will the client receive paid sick leave (PSL) or group WLI from the last employer or another source?

- Has the client received or will the client receive WCB?

- Is the client receiving a pension or will the client receive a pension in the next 52 weeks?

- Has the client received or will the client receive any other monies from the last employer or another source?

- Did the client answer Yes to any of the business relationship questions?

- Did the client indicate being pregnant or giving birth in the last 17 weeks?

- Did the client provide the variable best weeks (VBW)?

- During the last 2 years, was the client unable to work for medical reasons?

- During the last 2 years, did the client receive WLI?

- During the last 2 years, was the client on a training course to which the client was referred by a designated authority?

- During the last 2 years, was the client incarcerated?

- During the last 2 years, was the client receiving payment from the Wage Earner Protection Program (WEPP)?

- Are there any additional contentious issues (that were not already noted)?

- Review any electronic questionnaires that are present.

- What type of parental benefits is the client requesting?

- How many weeks of parental benefits is the client requesting?

Review other NWS information and take notes if necessary:

- Review all electronic documents (including any found under External ).

- If any documents have been added externally in error, move them to the correct application.

- Review any electronic questionnaires (e.g. VBW).

- Review documentation (SROCs, Action Item WIs, etc.) for medical information.

- Are there any outstanding actions indicated on the client Note ?

- Is there an issue with the SIR Validation WI (SIR WI)?

- If yes, is there an unresolved SIR WI or an SROC indicating whether the SIR was validated?

- Are there other unresolved WIs?

- If yes, are they related to the claim calculation?

- Is there still information from the application that is missing or needs clarification, but for which there is no WI (other than the calculation WI)?

- Is there new or amended information that affects the calculation (e.g. monies that may be paid or payable on separation)?

- Are there issues that require adjudication but for which there is no WI?

- Has the client provided amounts for the normal weekly earnings (NWE) or the earnings last week worked (ELWW)?

- If this is a recalculation, is there a ROD for an indefinite D15 that was imposed during the previous calculation of the claim?

- Is there information on file indicating the client is deceased? 

### In RCM:

Source topic: `en_EN/subactivity/detcalc_pb/in_rcm.dita`

Review the ROEs and take notes if necessary:

- Do the dates of employment on the ROEs match those on the EI application?

- Does the RFS match the RFS indicated on the EI application?

- Does the ROE confirm that there is an interruption of earnings (I of E) in the QP ?
         [interruption of earnings](/en/procedure/generic/knowledge.shtml) 
         [QP](/en/procedure/generic/knowledge.shtml)

- Does the ROE indicate it was initially issued under a 900-series SIN?

- If this is a recalculation, is there a new ROE?

- Is there an expected RTW date on the most recent ROE?

- Is there an ROE on file for each period of employment indicated on the EI application?

- If yes, determine if the ROE indicates that the client is receiving any of the following benefits after LDW:

- maternity, parental, or sickness

- WLI

- supplementary unemployment benefits (SUB) 

### In Imaging:

Source topic: `en_EN/subactivity/detcalc_pb/in_imaging.dita`

Review the imaged documents and take notes if necessary:

- Is there new or amended information that affects the calculation?(e.g. has the client provided amounts for NWE or ELWW?)

- Is there a medical certificate?

- Are there issues that required adjudication but for which there is no WI?

- Is it a 900-series SIN?

- If yes, note whether the immigration documents are on file.

- Is there information on file indicating the client is deceased? 

## Step by step

Source topic: `en_EN/subactivity/detcalc_pb/step_by_step.dita`

### Level 1

Source topic: `en_EN/subactivity/detcalc_pb/level_1.dita`

#### Untitled section

Source topic: `en_EN/subactivity/detcalc_pb/untitled_section_level_1.dita`

- If this is an initial calculation, has the initial claim already been calculated and finalized ?

- Is there a prior renewable claim ?

- Did the client apply with a paper application ?

- Is there a SIR validation issue ?

- Did the client request the wrong benefit type on the application ?

- Is there a missing ROE ?

- For an initial calculation or recalculation using a missing Government of Canada ROE, refer to ROE issued by the Government of Canada — Instructions .
               [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

- Were issues that could affect calculation found while verifying ROEs or has the client provided amounts for their weekly earnings?

- For an initial calculation or recalculation using a Government of Canada ROE that requires correction, refer to ROE issued by the Government of Canada — Instructions .
               [ROE issued by the Government of Canada — Instructions](/en/procedure/generic/additionalresources/roe-issued-gc-ins.shtml)

- If this is a recalculation, was the claim previously finalized as N2 or with a D15 for a missing ROE ?
               [previously finalized as N2](/en/procedure/task/reviewing_claim_twpfwtlroem.shtml) 
               [with a D15 for a missing ROE](/en/procedure/task/claim_procedure_term_after_roe.shtml)

- Does the client have a 900-series SIN at the start of the benefit period (BP) ?

- Does the client have an I of E ?

- Is the client entitled to have the WP waived for one of the following reasons:

- The client received PSL or QPIP payments .
               [The client received PSL or QPIP payments](/en/procedure/task/determining_ccc_wpwpslqpipp.shtml)

- The claim is impacted by Post-EI ERB measures based on BPC .
               [The claim is impacted by Post-EI ERB measures based on BPC](/en/procedure/task/calc_waiving_wp_bpc.shtml)

- The BPC is between March 30, 2025 (w/c 2493) and October 10 , 2026 (w/c 2572 ) .
               [The BPC is between March 30, 2025 (w/c 2493) andOctober 10, 2026 (w/c2572)](/en/procedure/task/det-adm-client-supp-car-ari-pp-24-det-client-entit-wwp-pp-24.shtml?site=ei-ort)

- Review the following issues:

- If the client indicated being pregnant, having given birth in the last 17 weeks, or is applying for maternity benefits, has the client provided proof of entitlement to maternity benefits ?

- If yes, are external maternity dates required and does the maternity window require an extension ?
                   [Note](D:/Deduplication_Agent/unzipped/ort_new_dita/dita/en_EN/common_notes/note_c_1316.dita) 
                   [external maternity dates required](/en/procedure/task/determining_emdr.shtml) 
                   [maternity window require an extension](/en/procedure/task/determining_extension_mrr.shtml)

               [provided proof of entitlement to maternity benefits](/en/procedure/task/determining_pembr.shtml)

- If the client is requesting parental benefits, has the client provided proof of entitlement to parental benefits ?

- If yes, does the parental window require an extension , is the client requesting a deferral of the WP , is the client entitled to the type of parental benefits requested , and are the number of parental weeks requested available ?
                   [parental window require an extension](/en/procedure/task/determining_epw_cc.shtml) 
                   [requesting a deferral of the WP](/en/procedure/task/determining_dccewpd.shtml) 
                   [is the client entitled to the type of parental benefits requested](/en/procedure/task/determine_type_pb_entitled.shtml) 
                   [number of parental weeks requested available](/en/procedure/task/determining_npwra.shtml)

               [provided proof of entitlement to parental benefits](/en/procedure/task/determining_pepbr.shtml)

- Review the client’s file to determine if there is possible entitlement to other benefits:

- If the client is applying for EI benefits in the maternity window, for EI maternity benefits or EI parental benefits, is the client entitled to QPIP benefits (e.g. the client resides in Quebec or another parent is entitled to receive QPIP)?
               [QPIP benefits](/en/procedure/task/reviewing_bpp_qpip.shtml)

- Is the client potentially entitled to benefits from another source (e.g. PSL, WLI, preventive withdrawal, WCB, motor vehicle accident insurance, or WEPP)?
               [benefits from another source](/en/procedure/task/calc_determining/rev_psl_wli.shtml)

- Is there an insurability issue for which there is no Assessment Issue WI (ASMT) (e.g. there is doubt regarding the status of the client’s employment, there is an arm’s length issue, the client had a 900-series SIN in the QP)?

- Was the client presented with the Delay in filing for EI benefits page when submitting the application, or are there other outstanding issues that require adjudication but for which there is no WI ?

- Are there outstanding WIs that are related to the calculation of the claim ?

- Does the client’s residential address differ from the mailing address ?

- Has the client requested an extension of the QP or are there gaps in employment which require a review for a possible QP extension ?

- Do you have all the information required ?

- The claim is ready to be calculated. Go to Calculating a claim in SSO . 

#### Note

Source topic: `en_EN/common_notes/note_c_1316.dita`

Note:

When a client applies for maternity benefits for a pregnancy that was terminated within the first 19 weeks, process the claim as a sickness claim and refer to Calculating a claim for sickness benefits . If a pregnancy is terminated after the 19th week, process the claim as a maternity claim.
       [Calculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml)

     [Calculating a claim for sickness benefits](/en/procedure/activity/calc_sick.shtml) 

## Policy reference

Source topic: `en_EN/subactivity/detcalc_pb/policy_reference.dita`

- Calculating or recalculating a claim for parental benefits
         [Calculating or recalculating a claim for parental benefits](https://ort-orl.esdc-edsc.canada.ca/en/procedure/activity/calc_par.shtml) 
